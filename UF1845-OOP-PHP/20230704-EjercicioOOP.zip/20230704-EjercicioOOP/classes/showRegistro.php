<?php
    require_once('classes.php'); 

    //Recibir parámetros
    $id = $_GET["id"];
    $tipo = $_GET["tipo"];  //Cliente, Proveedor, Empleado

    //Construir objeto del tipo especificado
    $obj = new $tipo($id);

    $lista = ["titulo"=> $obj->titulo, "ficha"=> $obj->getRegistro()];

    echo json_encode($lista);
?>