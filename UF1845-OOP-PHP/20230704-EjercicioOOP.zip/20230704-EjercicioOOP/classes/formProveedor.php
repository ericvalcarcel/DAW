<br/>
Empresa: <input type='text' id='txtEmpresa' class='form-control' />
<br/>
Nombre: <input type='text' id='txtNombre' class='form-control' />
<br/>
Apellidos: <input type='text' id='txtApellidos' class='form-control' />
<br/>
<button type="button" id="btnAdd" class="btn btn-primary">Añadir Proveedor</button>

<script>
    $("#btnAdd").click(function()
    {
        let empresa = $("#txtEmpresa").val();
        let nombre = $("#txtNombre").val();
        let apellidos = $("#txtApellidos").val();

        $.post("classes/addProveedor.php",
            {"empresa": empresa,
             "nombre": nombre,
             "apellidos": apellidos}, 
            function (data)
            {
                //UI
                //SweetAlert
                alert("Registro dado de alta");

                //Reload
                location.reload();
            });

    });

</script>