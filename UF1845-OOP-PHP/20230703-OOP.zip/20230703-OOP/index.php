<?php
    require('classes/classes.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                
                $pedro = new Usuario("Pedro","Picapiedra");

                $vilma = new Usuario("Vilma","Picapiedra");

                echo $pedro->show();

                $vilma->setIdioma("us_US");
                echo $vilma->show();

                echo $pedro->nombre . "<br/>";
                $pedro->nombre ="Pablo";
                echo $pedro->nombre . "<br/>";

                echo (new Usuario("Betty","Marmol"))->show();

                $clase="Usuario";
                $betty = new $clase("Betty","Marmol");
                echo $betty->show();

                $otroUsuario=null;
                //...
                $otroUsuario = new Usuario("Nombre","App");
                echo $otroUsuario->show();


                $otroUsuario2 = new Usuario("Nombre","App2");
                echo $otroUsuario2->show();
                //...
                $otroUsuario2 = null;
                //...
                //echo $otroUsuario2->show();

                




                ?>
            </div>
            <div class="col">
                <?php
                // Instanciación de un objeto en la clase hija.
                $yo = new UsuarioColor('Olivier', 'Heurtel', 'azul,blanco,rojo');

                // Utilización de métodos:
                // - de la clase madre
                echo "{$yo->show()}<br />"; // existe por herencia

                // - de la clase hija
                echo "{$yo->getColors()}<br />"; // existe en la clase

                echo "{$yo->showAdvanced()}<br />";
                echo $yo->__toString();

                ?>
            </div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
