<header>
    <div class="container">
        <div class="row">
            <div class="col">
                Esto es la cabecera
            </div>
        </div>
    </div>
</header>