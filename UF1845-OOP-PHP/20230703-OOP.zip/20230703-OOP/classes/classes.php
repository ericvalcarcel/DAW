<?php
// Definición de una clase destinada a almacenar información
// sobre un usuario. 
class Usuario
{
    // Definición de las propiedades-atributos
    public $apellido = ""; 
    public $nombre = "";
    protected $idioma = "es_ES"; // idioma del usuario
    private $timestamp = null; // fecha/hora de creación

    //Constructor y destructor
    public function __construct($nombre,$apellido) 
    {
        // Inicializar el apellido y el nombre
        // con los valores parametrados.
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        
        // Inicializar el timestamp con la función time().
        $this->timestamp = time();
    }

    // - método destructor
    public function __destruct() 
    {
        // Basta con mostrar un mensaje.
        echo "<p><b>Eliminación de $this->apellido</b></p>";
    }    
        
    // Definición de los métodos-comportamiento de la clase
    // - método que modifica el idioma del usuario. 
    public function setIdioma($idioma) 
    {
        //Verificaciones para controla que el idioma sea correcto
        //TO_DO        
        $this->idioma = $idioma;
    }

    // - método (privado) que da formato a la fecha/hora
    // de creación del usuario.
    private function getFormatTimestamp() 
    { 
        setlocale(LC_TIME,$this->idioma);
        return strftime('%c', $this->timestamp);
    }
    
    // - método de conversión del objeto en cadena
    public function __toString() 
    {
        // Devuelve el apellido y el nombre.
        return "$this->apellido - $this->nombre";
    }

    // - método que da información sobre el usuario 
    public function show()
    {
        $creacion = $this->getFormatTimestamp(); 
        return "<p>$this->nombre $this->apellido<br/>$creacion</p>";
    }
}

// Definición de una clase que hereda de la primera. 
class UsuarioColor extends Usuario
{
    // Definición de propiedades
    public $colores; // colores preferidos de usuarios


    //Constructor y destructor
    public function __construct($nombre, $apellidos, $colores) 
    {
        // Llamada al constructor de la clase madre
        // para la primera parte de la inicialización.
        parent::__construct($nombre,$apellidos);

        // Inicialización específica complementaria.
        $this->colores = explode(',',$colores);
    }


    // Definición de métodos
    // - lista de los colores preferidos del usuario 
    public function getColors() 
    {
        return implode(',',$this->colores);
    }

    public function showAdvanced()
    {
        return "<p>$this->nombre</p>" . 
            "<p>$this->apellido</p>" . 
            "<p>$this->idioma</p>" . 
            "<p>{$this->getColors()}</p>";
    }

    public function __toString() 
    {
        // Devuelve el apellido y el nombre.
        return parent::__toString() . " - {$this->getColors()}";
        //return "$this->apellido - $this->nombre - {$this->getColors()}";
    }
}

?>
