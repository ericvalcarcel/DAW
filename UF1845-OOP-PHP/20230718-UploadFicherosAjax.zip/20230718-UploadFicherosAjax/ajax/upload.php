<?php
    //Carpeta de destino del fichero
    $dir_subida = '../source/img/usuarios/';

    //Capturar por sesión el idUsuario
    //Parche TO_DO
    $idUsuario = 2;

    //Renombrar el fichero según nuestra lógica
    $fichero = basename($_FILES['file']['name']);
    $lista = explode(".",$fichero);
    $extension= end($lista);
    $nombreArchivo = $idUsuario. "." . $extension;

    //Path final del archivo
    $fichero_subido = $dir_subida . $nombreArchivo;
    
    //Procedemos a mover el archivo subido a su path final
    if (move_uploaded_file($_FILES['file']['tmp_name'], $fichero_subido)) 
    {
        echo $dir_subida . $nombreArchivo;
    } 
    else 
    {
        echo "KO";
    }

?>
