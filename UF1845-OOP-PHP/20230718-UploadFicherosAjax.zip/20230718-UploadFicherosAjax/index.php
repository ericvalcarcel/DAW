<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <h1>Upload de recursos</h1>
                <label for="filAvatar">Avatar</label>
                <input type="file" class="form-control" id="filAvatar" name="filAvatar" accept=".gif, .jpeg, .png" />
                <hr/>
                <button type="button" class="btn btn-primary mb-5" id="btnUpload">Upload avatar</button>
            </div>
            <div class="col-6" id="divImagen">
                <!-- Aquí se mostrará el preview del archivo -->

            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
