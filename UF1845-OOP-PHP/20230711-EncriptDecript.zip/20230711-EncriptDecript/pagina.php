<?php
    //Recuperar el id
    $salt1 = "12345%9876";
    $salt2 = "abcde%zywx";

    $id = $_GET["id"];
    $idDecripted = base64_decode($id);
    $idCorrecto = str_replace($salt1,"",$idDecripted);
    $idCorrecto = str_replace($salt2,"",$idCorrecto);

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Ejemplo encriptado</h1>    
                <p>El id recuperado es <?=$idCorrecto ?>.</p>
            </div>
            <div class="col"></div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
