<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Ejemplo encriptado</h1>
                <?php
                    $id = 10;
                    $salt1 = "12345%9876";
                    $salt2 = "abcde%zywx";
                    $idEncriptado = base64_encode($salt1 . $id . $salt2);
                ?>
                <a href="pagina.php?id=<?=$idEncriptado?>">Más información</a>
            </div>
            <div class="col"></div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
