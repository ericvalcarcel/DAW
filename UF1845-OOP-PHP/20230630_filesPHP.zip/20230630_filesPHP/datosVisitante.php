<?php 
    require("functions/functions.php") ;
    require("functions/setLog.php");
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-6">
                    <section> 
                        <article>
                            <h3>Datos Conexión</h3>
                            <p>
                            <?php
                                echo "<h1>Estaditicas del sitio:</h1>";
                                echo $_SERVER['SERVER_NAME'];
                                
                                //Recuperar informacion del visitante de la variabler globa $_SERVER
                                echo "<h4>nombre de la pagina web actual</h4>";
                                echo $_SERVER['PHP_SELF'];
                                
                                echo "<h4>Pagina web de donde viene el visitante</h4>";
                                echo $_SERVER['HTTP_REFERER'];
                                
                                echo "<h4> Nombre del navegador</h4>";
                                echo $_SERVER['HTTP_USER_AGENT'];
                                
                                echo "<h4>Direccion Ip del visitante</h4>";
                                echo $_SERVER['REMOTE_ADDR'];
                            ?>
                            </p>
                        </article>
                    </section>
                </div>
                <div class="col-6">
                    <section> 
                        <article>
                            <h3>Apartado 3</h3>
                            <p>It's not pining, it's passed on! This parrot is no more! It has ceased to be! It's expired and gone to meet its maker! This is a late parrot! It's a stiff! Bereft of life, it rests in peace! If you hadn't nailed it to the perch, it would be pushing up the daisies! It's metabolic processes are now history! He's off the twig! He's kicked the bucket, he's shuffled off the mortal coil, rung down the curtain and joined the choir invisible. This is an ex-parrot! What is the capital of Assyria?</p>
                        </article>
                    </section>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    include("controls/footer.php") ;
    require("controls/links.php") ;
?>