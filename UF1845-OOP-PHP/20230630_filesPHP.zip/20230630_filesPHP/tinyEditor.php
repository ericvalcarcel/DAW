<?php 
    require("functions/setLog.php");
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>

<div class="container">
    <div class="row">
        <div class="col-10 offset-1 mt-2">
            <div class="input-group mb-1">
                <label class="input-group-text bg-secondary col-2 col-lg-1 text-light">Dest:</label>
                <input id="txtDest" name="txtDest" type="text" class="form-control" placeholder="">
            </div>
                
            <div class="input-group mb-1">
                <label class="input-group-text bg-secondary col-2 col-lg-1 text-light">CC:</label>
                <input id="txtCC" name="txtCC" type="text" class="form-control" placeholder="">
            </div>
            <div class="input-group mb-1">
                <label class="input-group-text bg-secondary col-2 col-lg-1 text-light">CO:</label>
                <input id="txtCO" name="txtCO" type="text" class="form-control" placeholder="">
            </div>
            <div class="input-group mb-1">
                <label class="input-group-text bg-secondary col-2 col-lg-1 text-light">Tema:</label>
                <input id="txtTema" name="txtTema" type="text" class="form-control" placeholder="">
            </div>
            <textarea id="tiny"></textarea>
            <div class="d-flex justify-content-end my-2">
                <button type="button" id="btnGuardar" class="btn btn-secondary me-1">Guardar</button>
                <button type="button" id="btnCargar" class="btn btn-secondary ms-1">Cargar</button>
            </div>
        </div>
    </div>
</div>


<?php 
    include("controls/aside.php") ;
    require("controls/links.php") ;
?>