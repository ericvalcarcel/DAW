<?php
function getDiaSemana($num)
{
    $dia="";
    switch($num)
    {
        case 1:
            $dia="Lunes";
            break;
        case 2:
            $dia="Martes";
            break;
        case 3:
            $dia="Miercoles";
            break;
        case 4:
            $dia="Jueves";
            break;
        case 5:
            $dia="Viernes";
            break;
        case 6:
            $dia="Sabado";
            break;
        case 0:
            $dia="Sabado";
            break;
    }
    return $dia;
}

function getMes($num)
{
    $mes="";
    switch($num)
    {
        case 1:
            $mes="Enero";
            break;
        case 2:
            $mes="Febrero";
            break;
        case 3:
            $mes="Marzo";
            break;
        case 4:
            $mes="Abril";
            break;
        case 5:
            $mes="Mayo";
            break;
        case 6:
            $mes="Junio";
            break;
        case 7:
            $mes="Julio";
            break;
        case 8:
            $mes="Agosto";
            break;
        case 9:
            $mes="Setiembre";
            break;
        case 10:
            $mes="Octubre";
            break;
        case 11:
            $mes="Noviembre";
            break;
        case 12:
            $mes="Diciembre";
            break;
    }
    return $mes;
}

function getBrowser($user_agent)
{
    if(strpos($user_agent, 'MSIE') !== FALSE) 
        return 'Internet explorer';
    elseif(strpos($user_agent, 'Edg') !== FALSE) 
        return 'Microsoft Edge';
    elseif(strpos($user_agent, 'Trident') !== FALSE)
        return 'Internet explorer';
    elseif(strpos($user_agent, 'Opera Mini') !== FALSE)
        return "Opera Mini";
    elseif(strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR') !== FALSE)
        return "Opera";
    elseif(strpos($user_agent, 'Firefox') !== FALSE)
        return 'Mozilla Firefox';
    elseif(strpos($user_agent, 'Chrome') !== FALSE)
        return 'Google Chrome';
    elseif(strpos($user_agent, 'Safari') !== FALSE)
        return "Safari";
    else
        return 'No Detectado';
}

function getIPAddress() 
{  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
    //whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}
?>