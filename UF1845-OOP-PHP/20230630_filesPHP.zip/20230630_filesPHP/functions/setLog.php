<?php
    require_once("functions/utilidades.php") ;
    $array_fecha=getdate();
    $log["time"]=   "[".
                    $array_fecha["hours"].":".
                    $array_fecha["minutes"].":".
                    $array_fecha["seconds"].
                    "]";
    $log["site"]= $_SERVER['PHP_SELF'];
    $log["lang"]= $_SERVER['HTTP_ACCEPT_LANGUAGE'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $log["browser"]= getBrowser($user_agent);
    $log["ip"]= getIPAddress(); 
    $JSON = json_encode($log);
    $file ="log/".date("Ymd").".log";
    file_put_contents($file,$JSON.";\r\n",FILE_APPEND);
?>