<?php
//calcular el promedio de tres numeros de tipo float

function promedio (float $x,float $y,float $z):float
{
    return ($x+$y+$z)/3;
}

function computarArray(array $lista,float &$suma,float &$promedio):bool
{
    $resultado=false;
    foreach($lista as $elemento)
    {
        $suma += $elemento;
        if($elemento>100) $resultado=true;
    }
    $promedio += $suma/count($lista);

    return $resultado;
}
?>