<nav class="navbar navbar-expand-sm navbar-dark bg-secondary">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#opciones">
    <span class="navbar-toggler-icon"></span>
  </button>
  <!-- enlaces -->
  <div class="collapse navbar-collapse" id="opciones">   
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">index</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="datosVisitante.php">Datos Visitante</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="datosVisitante2.php">Datos Visitante2</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="tinyEditor.php">Mail Editor</a>
      </li>            
    </ul>
  </div>
  </nav>