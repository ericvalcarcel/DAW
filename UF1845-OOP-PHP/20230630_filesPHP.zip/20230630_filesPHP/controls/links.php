        <!-- Si utilizamos componentes de Bootstrap que requieran Javascript agregar el siguiente archivo -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
        <!-- Si utilizamos componentes de JQuery agregar el siguiente archivo -->
        <script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>  
        
        <script
          src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js"
          referrerpolicy="origin"
        ></script>
        <script src="https://cdn.jsdelivr.net/npm/@tinymce/tinymce-jquery@2/dist/tinymce-jquery.min.js"></script>
        
        <script>
            
        </script>

        <script src="scripts/scripts.js"></script> 

    </body>
</html>