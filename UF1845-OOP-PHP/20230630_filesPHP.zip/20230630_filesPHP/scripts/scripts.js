var texto="";

$(function()
{  
    $('textarea#tiny').tinymce({
        height: 300,
        menubar: false,
        plugins: [
          'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
          'anchor', 'searchreplace', 'visualblocks', 'fullscreen',
          'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount'
        ],
        toolbar: 'undo redo | blocks | bold italic backcolor | ' +
          'alignleft aligncenter alignright alignjustify | ' +
          'bullist numlist outdent indent | removeformat | help'
    });
    
   $("#btnGuardar").click(function()
    {
       let datos = 
       {
           dest : $("#txtDest").val(),
           cc : $("#txtCC").val(),
           co : $("#txtCO").val(),
           tema : $("#txtTema").val(),
           contenido : $('textarea#tiny').val()
       };
       json = JSON.stringify(datos);
       $.ajax({
                async: true,
                type: "POST",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "ajax/guardarMail.php",
                data: "datos="+json,
                beforeSend: function()
                {
                    let spiner =    
                        "<div class='spinner-border text-light text-center' style='width:1rem;height:1rem;'>"+
                            "<span class='visually-hidden'>Loading...</span>"+
                        "</div>";
                    $("#btnGuardar").html(spiner);
                },
                success: function(data)
                {    
                    
                    $("#btnGuardar").html("Guardar");
                },
                timeout: 5000,
                error: function(error)
                {
                    $("#btnCargar").html("Cargar");
                    console.log(error);
                }
              });
    });
    
    $("#btnCargar").click(function()
    {
        $.ajax({
                async: true,
                type: "POST",
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                url: "ajax/cargarMail.php",
                beforeSend: function()
                {
                    let spiner =    
                        "<div class='spinner-border text-light text-center' style='width: 1rem;height: 1rem;'>"+
                            "<span class='visually-hidden'>Loading...</span>"+
                        "</div>";
                    $("#btnCargar").html(spiner);
                },
                success: function(data)
                {       
                    $("#btnCargar").html("Cargar");
                    $("#txtDest").val(data.dest);
                    $("#txtCC").val(data.cc);
                    $("#txtCO").val(data.co);
                    $("#txtTema").val(data.tema);
                    $('textarea#tiny').val(data.contenido);
                },
                timeout: 5000,
                error: function(error)
                {
                    $("#btnCargar").html("Cargar");
                    console.log(error);
                }
              });
    }); 
});

