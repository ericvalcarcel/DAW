<?php 
    require("functions/functions.php") ;
    require("functions/utilidades.php");
    require("functions/setLog.php");
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-6">
                    <h3>Log visitas</h3>
                    <p>
                        <?php
                            $array_fecha=getdate();
                            echo "time = [".
                                            $array_fecha["hours"].":".
                                            $array_fecha["minutes"].":".
                                            $array_fecha["seconds"].
                                            "]</br>";
                            echo "site = ".$_SERVER['PHP_SELF']."</br>";
                            echo "lang = ".$_SERVER['HTTP_ACCEPT_LANGUAGE']."</br>";
                            $user_agent = $_SERVER['HTTP_USER_AGENT'];
                            echo "browser = ".getBrowser($user_agent)."</br>";
                            echo "ip= ".getIPAddress()."</br>"; 
                        ?>
                    </p>
                </div>
                <div class="col-6">
                    <section> 
                        <article>
                            <h3>Apartado 4</h3>
                            <p>Oh, oh, I see! Running away, eh? You yellow bastards! Come back here and take what's coming to you! I'll bite your legs off! Well, er, yes Mr. Anchovy, but you see your report here says that you are an extremely dull person. You see, our experts describe you as an appallingly dull fellow, unimaginative, timid, lacking in initiative, spineless, easily dominated, no sense of humour, tedious company and irrepressibly drab and awful. And whereas in most professions these would be considerable drawbacks, in chartered accountancy, they're a positive boon. Well, I think I should point out first, Brian, in all fairness, we are not, in fact, the rescue committee. However, I have been asked to read the following prepare statement on behalf of the movement. "We the People's Front of Judea, brackets, officials, end brackets, do hereby convey our sincere fraternal and sisterly greetings to you, Brian, on this, the occasion of your martyrdom."</p>
                        </article>
                    </section>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    include("controls/footer.php") ;
    require("controls/links.php") ;
?>