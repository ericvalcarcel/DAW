<?php 
    require("functions/functions.php") ;
    require("functions/setLog.php");
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-6">
                    <section> 
                        <article>
                            <h3>Aprtado 1</h3>
                            <p>Oh and Jenkins, apparently your mother died this morning. Manacles! Ooooh, my idea of heaven, is to be allowed to be put in manacles. Just for a few hours. They must think the sun shines out your ass, sonny.</p>
                            <p>Hey! Your nose is going to be three foot wide across your face by the time I'm finished with you! I'm not a roman mum, I'm a kike, a yid, a heebie, a hook-nose, I'm kosher mum, I'm a Red Sea pedestrian, and proud of it! Oh, waiter! This conversation isn't very good. And finally, a wafer thin mint. Ah, I see you have the machine that goes ping. This is my favorite. You see we lease it back from the company we sold it to and that way it comes under the monthly current budget and not the capital account.</p>
                            <p>I object to all this sex on the television. I mean, I keep falling off! Oh, king eh? Very nice. And how'd you get that, eh? By exploiting the workers. By hanging on to outdated imperialist dogma which perpetuates the economic and social differences in our society.</p>
                        </article>
                    </section>
                </div>
                <div class="col-6">
                    <section> 
                        <article>
                            <h3>Apartado 2</h3>
                            <p>I cut down trees, I skip and jump, I like to press wildflowers. I put own womens' clothing, and hang around in bars. I'm not a roman mum, I'm a kike, a yid, a heebie, a hook-nose, I'm kosher mum, I'm a Red Sea pedestrian, and proud of it! Shut your festering gob, you tit! Your type really makes me puke you vacuous, toffy-nosed, malodorous pervert! Well, had I got as far as the penis entering the vagina? And finally, a wafer thin mint. What's wrong with a kiss, boy? Hmm? Why not start her off with a nice kiss? You don't have to go leaping straight for the clitoris like a bull at a gate. Give her a kiss, boy.</p>
                            <p>Well, er, yes Mr. Anchovy, but you see your report here says that you are an extremely dull person. You see, our experts describe you as an appallingly dull fellow, unimaginative, timid, lacking in initiative, spineless, easily dominated, no sense of humour, tedious company and irrepressibly drab and awful. And whereas in most professions these would be considerable drawbacks, in chartered accountancy, they're a positive boon. And Dinsdale says 'I hear you've been a naughty boy, Clement', and he splits me nostrils open, saws me leg off and pulls me liver out. And I tell him 'My name's not Clement', and then he loses his temper and nails my head to the floor.</p>
                        </article>
                    </section>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    include("controls/footer.php") ;
    require("controls/links.php") ;
?>