<?php
    $data=$_POST["datos"];
    $file ="../temp/borrador.tmp";
    $respuesta = file_put_contents($file,$data);
    if($respuesta) {echo "ok";} else {echo "ko";}
?>