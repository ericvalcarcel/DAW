<?php
    $file ="../temp/borrador.tmp";
    if(file_exists($file))
    {
        $respuesta = file_get_contents($file);
        echo $respuesta;
    }
    else
    {
        echo "ningun mensaje guardado";
    }
        
?>