<header>
    <div class="container">
        <div class="row">
            <div class="col-6">
                <a href="index.php">Esto es la cabecera</a>
            </div>
            <div class="col-6">
            <?php
                if (isset($_SESSION["idUsuario"]))
                {
                    //Sí que se ha loginado el usuario
            ?>
                <ul class="nav float-end">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#"><img src='source/img/usuarios/<?=$_SESSION["idUsuario"]?>.jpg' 
                        height='50' style='border-radius:25px;'
                        alt='<?=$_SESSION["usuario"]?>' /></a>        
                        <div class="dropdown-menu">
                            <span class="dropdown-item"><b><?=$_SESSION["usuario"]?></b></span>
                            <a class="dropdown-item" href="editarPerfil.php">Editar perfil</a>
                            <a class="dropdown-item" href='javascript:confirmLogout();'>Cerrar sesión</a>
                        </div>
                    </li>
                </ul>
            <?php
                }
                else
                {
                    //No está loginado el usuario
                    echo "Hola visitante";
                }
            ?>
            </div>
        </div>
    </div>
</header>