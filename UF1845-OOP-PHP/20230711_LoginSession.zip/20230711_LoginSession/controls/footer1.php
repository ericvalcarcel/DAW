<footer>
    <div class="container">
        <div class="row">
            <div class="col" style="background-color: silver;">
                <hr/>
                Esto es el footer 1
            </div>
        </div>
    </div>
</footer>