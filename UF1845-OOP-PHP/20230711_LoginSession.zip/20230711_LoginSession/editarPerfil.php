<?php
    //Control de permiso de acceso
    require('functions/functions.php'); 
    if (!testSession()) header("Location: index.php");


    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>
<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h2>Panel de control</h2>
                <p>....</p>
            </div>
        </div>
    </div>
</main>


<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
