<?php
    //Iniciar session
    session_start();

    //Destruir session
    session_destroy();
    
    //Redirigir a login
    header("Location: index.php");
?>
