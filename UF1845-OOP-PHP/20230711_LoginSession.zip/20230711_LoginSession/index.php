<?php
    //Control de permiso de acceso
    require('functions/functions.php'); 
    if (testSession()) header("Location: entrada.php");

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>
<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col text-center gris">
                <h2>Identifícate y podremos mejorar tu experiencia</h2>
                <h3>Navega con tu usuario y contraseña y descubre ofertas exclusivas para ti</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 offset-md-4 login">
                <form>
                    <div class="mb-3 form-floating">        
                        <input type="text" class="form-control" id="txtNif" name="txtNif">        
                        <label for="txtNif" class="form-label">NIF/CIF/NIE</label>
                        <div class="form-text text-end"><a href="#">Utilizar pasaporte</a></div>
                    </div>
                    <div class="mb-3 form-floating">        
                        <input type="password" class="form-control" id="pasContrasena" name="pasContrasena">        
                        <label for="pasContrasena" class="form-label">Contraseña</label>
                        <div class="form-text text-end"><a href="#">He olvidado mi contraseña</a></div>
                    </div>
                    <div class="form-floating mt-3">
                        <select class="form-select" id="cmbTipo" name="cmbTipo">
                            <option value="0">Seleccione...</option>
                            <option value="1">Cliente</option>
                            <option value="2">Empresa</option>
                        </select>
                        <label for="cmbTipo">Tipo de usuario</label>
                    </div>
                    <div class="mt-3">  
                        <button type="button" class="btn btn-success"  id="btnEntrar">Entrar</button>
                    </div>
                    <div class="text-danger" id="divMensaje"></div>
                    <div class="form-check mt-3 text-end end">
                        <input class="form-check-input" type="checkbox" value="" id="chkConectado" name="chkConectado">
                        <label class="form-check-label" for="chkConectado">Mantenerme conectado</label>
                    </div>
                    <div class="clearer"></div>
                    <div class="mt-3 text-end">  
                        <a href="#">Regístrate</a> <i class="fa fa-question-circle" aria-hidden="true"></i>
                    </div>
                    <hr/>
                    <div class="mt-3">  
                        <button type="button" class="btn btn-outline-primary"  id="btnMovil">ACCEDER CON TU MÓVIL</button>
                    </div>                            
                </form>
            </div>
        </div>
    </div>
</main>


<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
