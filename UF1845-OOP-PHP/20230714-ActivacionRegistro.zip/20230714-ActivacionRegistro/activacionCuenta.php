<?php
    include("classes/Database.php");

    $mensaje="";
    //Recuperar parámetro
    $c="";
    if (isset($_GET["c"]))
    {
        $c= $_GET["c"];
    }
    else
    {
        header("location: login.php");
        exit();
    }

    //Recuperar de codigoUsuario
    $db = new Database("localhost","root","","neptuno");
    try
    {
        $db->connect();
        $resultSet = $db->select("codigousuario","idUsuario,fechaLimite","codigo='$c'");
        if (count($resultSet)>0)
        {
            //Verificar que estamos en tiempo (3 días máximo)
            $idUsuario = $resultSet[0]["idUsuario"]; 
            $fechaDeAlta = new DateTime($resultSet[0]["fechaLimite"]); 
            $fechaHoy = new DateTime();

            $diff = $fechaHoy->diff($fechaDeAlta);
            if ($diff->days>3)   //Si es mayor a 3, caducado
            {
                //caducado  -> pasar estado a 2 del usuario
                $db->update("usuario",["estado" => 2],"idUsuario=$idUsuario");

                //borrar de codigousuario
                $db->delete("codigousuario", true, "idUsuario=$idUsuario");

                $mensaje="<p>Su código de activación ha expirado.</p>
                            <p>Por favor, acceda de nuevo a <a href='registro.php'>Registrarse</a></p>";  //???
            }
            else
            {
                //Procedemos a la activación    -> pasar usuario a estado 1
                $db->update("usuario",["estado" => 1],"idUsuario=$idUsuario");

                //borrar de codigousuario
                $db->delete("codigousuario", true, "idUsuario=$idUsuario");

                $mensaje="<p>Código activado con éxito.</p>
                <p><a href='login.php'>Login</a></p>";
            }
        }
        else
        {
            $mensaje="<p>Código inexistente en nuestra base de datos.</p>";
        }
    }
    catch (Exception $e) { }
    finally
    {
        $db->disconnect();
    }


    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?=$mensaje ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
