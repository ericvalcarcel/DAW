<?php

function promedio(float $p1, float $p2, float $p3) : float
{
    return ($p1+$p2+$p3)/3;
}

function computarArray(array $lista, float &$suma, float &$promedio) : bool
{
    $res=false;
    foreach($lista as $item)
    {
        $suma +=$item;
        if ($item>100) $res=true;
    }
    $promedio +=$suma/count($lista);

    return $res;
}

function factorial(int $numero) : float
{
    if ($numero==1)
    {
        return 1;
    }
    else
    {
        return $numero * factorial($numero - 1);
    }
}

function scanDirCompleto(string $directorio, string $tabs) : void
{
    $archivos = scandir($directorio);

    $tabs .="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";

    // Examinar resultado.
    foreach ($archivos as $archivo) 
    { 
        //$archivoSinPath = explode("/",$archivo)[count(explode("/",$archivo))-1];
        if (is_file($directorio . "/" . $archivo))
        {
            //Archivo
            echo $tabs . $archivo,' [A]<br />';
        }
        else
        {
            //Directorio
            if (!($archivo=="." || $archivo==".."))
            {
                echo $tabs . $archivo,' [D]<br />';

                scanDirCompleto($directorio . "/" . $archivo, $tabs);
            }
        }
    }
}



?>