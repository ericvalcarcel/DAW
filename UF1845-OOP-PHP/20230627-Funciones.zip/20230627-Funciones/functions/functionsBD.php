<?php
function conectar($host=null,$userName=null,$pass=null,$db=null)
{
    if(func_num_args()<4)
    {
        //conexión por defecto TO DO
        echo 'Parámetros incorrectos';
    }
    else
    {
        $conexion = mysqli_connect($host, $userName, $pass,$db);
        if(!$conexion)
        {
            //error de conexion
            //echo 'Error de conexión - '.mysqli_error($conexion)." - ".mysqli_connect_errno($conexion);
            exit("no se pudo conectar a la base de datos.");
        }
        else
        {
            //echo 'Conexión OK - '.mysqli_get_host_info($conexión)." - ".
            mysqli_get_server_info($conexion)."</br>";

        }
        return $conexion;
    }
}
function desconectar($conexión)
{
    if($conexión)
    {
        $ok = mysqli_close($conexión);
        if ($ok)
        {
           //echo "Desconexion con exito</br>";
        }
        else
        {
            echo "Error en la desconexion</br>";
        }
    }
    
}

function mostrarMatriz($matriz)
{
    $html="<table class='table'>";

    //Recorre las filas de la matriz
    for($i=0; $i < count($matriz); $i++)
    {
        $html .="<tr>";
        for($j=0; $j < count($matriz[$i]); $j++)
        {
            $html .="<td>" . $matriz[$i][$j] . "</td>";
        }
        $html .="</tr>";
    }

    $html .="</table>";

    return $html;
}

?>