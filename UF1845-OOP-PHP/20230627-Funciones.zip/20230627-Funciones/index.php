<?php
    require('functions/functions.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    echo promedio(3, 2, 2) . "<br/>";

                    echo "<hr/>";

                    $lista = [1,3,8,23,6,8,101];
                    $suma = 0.0;
                    $promedio = 0.0;
                    $res = computarArray($lista, $suma, $promedio);

                    echo (($res) ? "Existe" : "No existe") . "<br/>";
                    echo $suma . "<br/>";
                    echo $promedio . "<br/>";
                ?>
            </div>
            <div class="col">
                <?php
                    echo "Factorial de 50:" . factorial(50) . "<br/>";
                    //echo "Factorial de 50:" . 50! .  "<br/>";
                    echo "" . 6 ** 3 . "<br/>";

                ?>
            </div>
            <div class="col">
                <?php
                    scanDirCompleto("../../UF1844", "");
                ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
