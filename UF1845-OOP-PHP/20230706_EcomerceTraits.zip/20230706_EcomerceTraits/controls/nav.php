<nav class="navbar navbar-expand-sm navbar-dark bg-secondary text-center">
  <button class="navbar-toggler text-center" type="button" data-bs-toggle="collapse" data-bs-target="#opciones">
    <span class="navbar-toggler-icon"></span>
  </button>
  <!-- enlaces -->
  <div class="collapse navbar-collapse" id="opciones">   
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Opción 1</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Opción 2</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Opción 3</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Opción 4</a>
      </li>            
    </ul>
  </div>
  </nav>