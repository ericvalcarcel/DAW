<?php
//Crea una interfaz ICrud que tenga los métodos create, read, update y delete.
interface ICrud
{
    public function create(array $params,?Producto $nombreObj );
    public function read(?Producto $nombreObj );
    public function update(array $params,?Producto $nombreObj );
    public function delete(?Producto $nombreObj );
}
?>