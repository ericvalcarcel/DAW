<?php
//Crea una clase abstracta Usuario con propiedades username, email y métodos login, logout.
require_once("interfaces.php");
require_once("traits.php");

$productos=[];

abstract class Usuario
{
    protected string $username="";
    protected string $email="";
    protected bool $loged=false;

    public function __construct(string $username="", string $email="") 
    {
        $this-> username = $username;
        $this-> email = $email;
        
        $clase = ($this instanceof Administrador)?"Administrador ":"Cliente ";
        echo "Se ha creado el $clase $this->username.<br/>";
    }

    function login()
    {
        if(!$this->loged)
        {
            $this->loged=true;
            echo $this->username." login<br/>";
        }
        else
        {
            echo $this->username." ya estaba loginado<br/>";
        }
        
    }
    function logout() : void
    {
        if($this->loged)
        {
            $this->loged=false;
            echo $this->username." logout<br/>";
        }
        else
        {
            echo $this->username." NO estaba loginado<br/>";
        }
    }
}

//Crea una clase Producto que tenga propiedades nombre, precio, descripción y que implemente ICrud.

class Producto implements ICrud
{
    private string $nombre="";
    private int $precio=0;
    private string $descripcion="";
    
   public function create(array $params,?Producto $nombreObj=null  )
    {
        //$params = [string $nombre,int $precio,string $descripcion] -- ?Producto $nombreObj = null
        $this->nombre = $params[0];
        $this->precio = $params[1];
        $this->descripcion = $params[2];
        echo "Creado $this->nombre.<br/>";
    }
    public function read(?Producto $nombreObj=null )
    {
        //?Producto $nombreObj = null
        echo "Leido:<br/>";
        echo $this->nombre . "--" . $this->precio . "¤--<b>Descripción:</b> " . $this->descripcion . "<br/>";
    }
    public function update(array $params,?Producto $nombreObj=null )
    {
        //$params = [?string $nombre,?int $precio,?string $descripcion] -- ?Producto $nombreObj = null
        echo "Editado $this->nombre<br/>";
        if ($params[0]) $this->nombre = $params[0];
        if ($params[1]) $this->precio = $params[1];
        if ($params[2]) $this->descripcion = $params[2];
    }
    public function delete(?Producto $nombreObj=null )
    {
        //?Producto $nombreObj = null
        echo "Destruido $this->nombre<br/>";
        $this->nombre="";
        $this->precio = 0;
        $this->descripcion = "";
    }
    public function getNombre():string
    {
        return $this->nombre;
    }
}

//Crea la clase Administrador que herede de Usuario e implemente ICrud.

class Administrador extends Usuario implements ICrud
{
    public function create(array $params,?Producto $nombreObj )
    {
        //$params = [string $nombre,int $precio,string $descripcion] -- ?string $nombreObj
        echo $this->username." ha "; 
        $nombreObj->create($params);
        
    }
    public function read(?Producto $nombreObj )
    {
        echo $this->username." ha "; 
        $nombreObj->read();        
    }
    public function update(array $params,?Producto $nombreObj )
    {
        echo $this->username." ha "; 
        $nombreObj->update($params);
    }
    public function delete(?Producto $nombreObj )
    {
        echo $this->username." ha "; 
        $nombreObj->delete();
    }
}

//Crea la clase Cliente que herede de Usuario y utilice el Rasgo TRevisable.
class Cliente extends Usuario
{
    use TRevisable;
}

?>