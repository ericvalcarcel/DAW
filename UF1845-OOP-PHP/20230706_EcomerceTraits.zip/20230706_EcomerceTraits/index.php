<?php 
    require("classes/classes.php") ;
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-md-12">
                    <section> 
                        <article>
                            <h3>Ecomerce trait</h3>
                            <p>
                            <?php
                                $Roque = new Administrador("Roque Rocadura","Rrocadura@pangea.old");
                                $Pedro = new Cliente("Pedro Picapiedra","PPicapiedra@pangea.old");
                                $Pablo = new Cliente("Pablo Marmol","PMarmol@pangea.old");
                                $Roque->login();
                                $Roque->login();
                                $Pablo->logout();
                                $Roque->logout();
                                
                                $HuevoAstegosaurio = new Producto();
                                $HuevoAstegosaurio->create(["Huevo Astegosaurio",25,"Manda Huevos"]);
                                $HuevoAstegosaurio->read();
                                
                                $HuevoAstegosaurio->update(["Huevo Astegosaurio",30,"Manda Más Huevos"]);
                                $HuevoAstegosaurio->read();

                                $HuevoPterodactilo = new Producto();
                                $Roque->create(["Huevo Pterodáctilo",30,"Huevos  Voladores"],$HuevoPterodactilo);
                                $Roque->read($HuevoPterodactilo);
                                $Roque->update(["Huevo Pterodáctilo",100,"Más Huevos  Voladores"],$HuevoPterodactilo);
                                $Roque->read($HuevoPterodactilo);
                                
                                $Pedro->darOpinion("Mmmm.. Riquisimos!!",$HuevoAstegosaurio);
                                $Pablo->darOpinion("No vale la pena pagar tanto.",$HuevoPterodactilo);
                                
                                $HuevoAstegosaurio->delete();
                                $Roque->delete($HuevoPterodactilo);
                                
                                
                                
                            ?>
                            </p> 
                        </article>
                    </section>
                </div>
                
            </div>
        </div>
    </main>

<?php 
    //include("controls/aside.php") ;
    //include("controls/footer.php") ;
    require("controls/links.php") ;
?>