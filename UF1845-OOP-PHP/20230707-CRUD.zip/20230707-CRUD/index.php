<?php
    require('classes/Database.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                $db = new Database("localhost","root","","neptuno");
                if ($db->connect())
                {
                    $result = $db->select("producto");
                    $db->disconnect();
                    foreach($result as $item)
                    {
                        echo $item["NombreProducto"] . " - " . $item["PrecioUnidad"] . "<br/>";                        
                    }
                }
                else
                {
                    echo "FIN";
                }

            ?>
            </div>
            <div class="col">
            <?php
                $db = new Database("localhost","root","","neptuno");
                if ($db->connect())
                {
                    if ($db->insert("producto",["Coca cola light 2L",18.20],"NombreProducto,PrecioUnidad"))
                    {
                        echo "Producto insertado";
                    }
                    else
                    {
                        echo "Error en la inserción";
                    }
                    $db->disconnect();
                }
                else
                {
                    echo "FIN";
                }
            ?>
            </div>
            <div class="col">
            <?php
                $db = new Database("localhost","root","","neptuno");
                if ($db->connect())
                {
                    if ($db->delete("producto"))
                    {
                        echo "Productos borrados";
                    }
                    else
                    {
                        echo "Error en el borrado de productos";
                    }
                    $db->disconnect();
                }
                else
                {
                    echo "FIN";
                }
            ?>
            </div>
            <div class="col">
            <?php
                $db = new Database("localhost","root","","neptuno");
                if ($db->connect())
                {
                    if ($db->update("producto",["PrecioUnidad"=>20,"UnidadesEnExistencia"=>100],"NombreProducto='Coca cola light 2L'"))
                    {
                        echo "Productos actualizados";
                    }
                    else
                    {
                        echo "Error en la actualización de productos";
                    }
                    $db->disconnect();
                }
                else
                {
                    echo "FIN";
                }
            ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
