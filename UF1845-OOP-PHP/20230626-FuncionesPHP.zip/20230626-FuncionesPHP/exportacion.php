<?php
    require('functions/functionsBD.php'); 
    require('functions/utilidades.php'); 

    //Exportación
    //Crear SQL
    $sql="SELECT p.IdProducto, 
                    p.NombreProducto,
                    c.NombreCategoria,
                    p.CantidadPorUnidad,
                    p.PrecioUnidad,
                    p.UnidadesEnExistencia,
                    p.UnidadesEnPedido,
                    p.Suspendido
          FROM producto p INNER JOIN categoria c
            ON p.idCategoria = c.idCategoria
          ORDER BY 2";

    //Crear la conexión
    $conexion = conectar("localhost","root","","neptuno");
                
    //Lanzar SQL y recuperar datos
    $resultSet = mysqli_query($conexion,$sql);

    //Template de cada fila
    $fila ='<producto id="[idProducto]">
                <nombre>[Nombre]</nombre>
                <categoria>[Categoria]</categoria>
                <descripcion>[Descripcion]</descripcion>
                <precio>[Precio]</precio>
                <stock>
                    <activo>[StockActivo]</activo>
                    <pendiente>[StockPendiente]</pendiente>
                </stock>
                <estado>[Estado]</estado>
            </producto>';

    //Apertura del fichero XML de salida
    $f = fopen("docs/productos.xml", "ab");

    fwrite($f,'<?xml version="1.0" encoding="UTF-8" ?>');
    fwrite($f,'<productos>');

    while (true)
    {
        $linea = mysqli_fetch_object($resultSet);
        if ($linea==null) break;

        $xml = $fila;
        $xml = str_replace("[idProducto]",$linea->IdProducto, $xml);
        $xml = str_replace("[Nombre]",$linea->NombreProducto, $xml);
        $xml = str_replace("[Categoria]",$linea->NombreCategoria, $xml);
        $xml = str_replace("[Descripcion]",$linea->CantidadPorUnidad, $xml);
        $xml = str_replace("[Precio]",$linea->PrecioUnidad, $xml);
        $xml = str_replace("[StockActivo]",$linea->UnidadesEnExistencia, $xml);
        $xml = str_replace("[StockPendiente]",$linea->UnidadesEnPedido, $xml);
        $xml = str_replace("[Estado]",$linea->Suspendido, $xml);

        fwrite($f,$xml);

    }
    //Cerrar la conexión
    desconectar($conexion);

    fwrite($f,'</productos>');

    //Cerrar e lfichero
    fclose($f);

    $mensaje="la exportación se realizó correctamente";

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?= $mensaje ?>
            </div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
