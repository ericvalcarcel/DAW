<?php
    require('functions/functionsBD.php'); 
    require('functions/utilidades.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    //Generar un documento html en temporal
                    $f = fopen('temp/test.html','wb');

                    // Escribir en el archivo.
                    fwrite($f, "<p>Archivo de test</p><p>Fin del archivo</p>");

                    // Cerrar el archivo.
                    fclose($f);

                    echo "Fin de grabación del archivo.<br/>";

                    echo "<hr/>";

                    // Abrir un archivo en lectura.
                    $f = fopen('temp/test.html','rb');

                    // Leer en el archivo.
                    $texto = fread($f, filesize('temp/test.html'));

                    // Cerrar el archivo.
                    fclose($f);

                    // Mostrar la información leída 
                    echo $texto,'<br />';

                    echo "<hr/>";
                    $texto = file_get_contents('temp/test.html');
                    echo $texto,'<br />';

                    echo "<hr/>";
                    echo file_get_contents('docs/cmbPaises.html');

                    //Añadir contenido a un archivo
                    echo "<hr/>";
                    $f = fopen('temp/test.html','ab');
                    fwrite($f, "<p>Más contenido en el archivo</p>");
                    fclose($f);
                    echo "Fin de adición de texto al archivo.<br/>";
                    

                ?>
            </div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
