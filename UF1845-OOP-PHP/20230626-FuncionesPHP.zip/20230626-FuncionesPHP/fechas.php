<?php
    require('functions/functionsBD.php'); 
    require('functions/utilidades.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    //Formato de la Fecha
                    //Día de la semana, día de mes de año (hh:mm:ss)
                    $fecha = date("l jS \of F Y h:i:s A");
                    echo "$fecha<br/>";

                    echo "<hr/>";

                    //setlocale(LC_ALL,'es_ES');
                    $arrayFecha = getdate();

                    echo getDiaSemana($arrayFecha["wday"]) . ", " . 
                            $arrayFecha["mday"] . " de " . 
                            getMes($arrayFecha["mon"]) . " de " . 
                            $arrayFecha["year"] . " " .
                            "(" .  $arrayFecha["hours"] . ":" .
                            $arrayFecha["minutes"] . ":" .
                            $arrayFecha["seconds"] . ")";


                    echo "<hr/>";

                    $unico1 = uniqid(rand());
                    $unico2 = uniqid(rand());
                    echo $unico1,'<br />'; 
                    echo md5($unico1),'<br />'; 
                    echo $unico2,'<br />'; 
                    echo md5($unico2),'<br />';

                    //...

                    echo md5($unico1),'<br />'; 


                    

                ?>
            </div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
