<?php
namespace contabilidad\existencias;

class Stock
{
    public function __construct()
    {
        echo "Se ha creado un objeto Stock.<br/>";
    }

    
}

class Otra
{
    public function __construct()
    {
        echo "Se ha creado un objeto Otra.<br/>";
    }

    
}


?>