<?php
namespace facturacion;

class Balance
{
    public function __construct()
    {
        echo "Se ha creado un Balance de facturación.<br/>";
    }

    
}


?>