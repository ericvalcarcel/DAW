<?php
    //Zona de using
    use contabilidad\Balance as Balance;
    use contabilidad\existencias\Stock as Stock;
    use facturacion\Balance as FBalance;

    //Zona de require de clases
    require('classes/contabilidad/Balance.php'); 
    require('classes/contabilidad/existencias/classes.php'); 
    require('classes/facturacion/Balance.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                $bc = new Balance();
            
                $bf = new FBalance();

                $stock = new Stock();

                $otra = new contabilidad\existencias\Otra();

            ?>
            </div>
            <div class="col"></div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
