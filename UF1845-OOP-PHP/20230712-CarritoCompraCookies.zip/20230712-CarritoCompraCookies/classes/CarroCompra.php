<?php

class CarroCompra
{
    //Atributos
    
    //Constructor
    public function __construct()
    {
        if (!isset($_COOKIE['lista'])) 
        {
            $emptyLista = [];
            setcookie('lista', serialize($emptyLista), time() + 30 * 24 * 3600);
            $_COOKIE['lista'] = serialize($emptyLista); // Actualizar la superglobal $_COOKIE
        }
    }

    private function getArray() : array 
    {
        if (isset($_COOKIE['lista'])) 
        {
            return unserialize($_COOKIE['lista']);
        } 
        else 
        {
            return [];
        }
    }

    private function guardarArray($array) : void
    {
        setcookie('lista', serialize($array), time() + 30 * 24 * 3600);
        $_COOKIE['lista'] = serialize($array); // Actualizar la superglobal $_COOKIE
    }

    //Comportamiento
    public function add(Producto $p, int $cantidad)
    {
        $array = $this->getArray();
        array_push($array,serialize([$p,$cantidad]));
        $this->guardarArray($array);

        echo "Producto " . $p->getNombre() . " añadido a la cesta de la compra.<br/>";
    }

    public function remove(int $posicion)
    {
        $array = $this->getArray();

        $elemento = unserialize($array[$posicion]);
        $p = $elemento[0];
        echo "Producto " . $p->getNombre() . " borrado de la cesta de la compra.<br/>";

        unset($array[$posicion]);

        //Reposicionar los elementos del array a offset = 0

        $this->guardarArray($array);

    }

    public function list()
    {
        echo "<table class='table'>
                <tr><th>Producto</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Importe</th>
                <th>Acción</th></tr>";

        $importeTotal = 0.0;
        $contador=0;
        $array = $this->getArray();
        foreach($array as $item)
        {
            $elemento = unserialize($item);

            $importe = $elemento[1] * $elemento[0]->getPrecio();
            $importeTotal += $importe;

            echo "<tr><td>{$elemento[0]->getNombre()}</td>
            <td>{$elemento[0]->getDescripcion()}</td>
            <td>{$elemento[1]}</td>
            <td>{$elemento[0]->getPrecio()}</td>
            <td>$importe</td>
            <td><a href='borrarItem.php?pos=$contador'>Borrar</a></td></tr>";

            $contador++;
        }

        //Última fila con importe total
        $iva = $importeTotal * 0.1;
        $total = $importeTotal * 1.1;

        echo "<tr><td colspan='4'>Subtotal</td><td>$importeTotal</td><td></td></tr>";
        echo "<tr><td colspan='4'>IVA (10%)</td><td>$iva</td><td></td></tr>";
        echo "<tr><td colspan='4'>Total</td><td>$total</td><td></td></tr>";

        echo "</table>";
    }

    public function finalizarCompra()
    {
        //Finalizar el pedido
        echo "FINALIZAR COMPRA<br/>";
        
    }

    public function pagar()
    {
        //Pagar el pedido
        echo "PAGAR<br/>";
    }

}

?>