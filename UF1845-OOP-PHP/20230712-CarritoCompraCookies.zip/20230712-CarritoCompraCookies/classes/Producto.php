<?php

class Producto
{
    private string $nombre="";
    private string $descripcion="";
    private float $precio=0.0;

    public function __construct(string $nombre, string $descripcion, float $precio)
    {
        $this->nombre = $nombre;
        $this->descripcion = $descripcion;
        $this->precio = $precio;
    }

    //Comportamiento
    public function getNombre(): string { return $this->nombre; }

    public function getDescripcion(): string { return $this->descripcion; }

    public function getPrecio(): float { return $this->precio; }
    
}

class ProductoModel
{
    //TO_DO
    
}


?>