<?php
    require('classes/Producto.php'); 
    require('classes/CarroCompra.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                $carro = new CarroCompra();

                //Escaparate de productos
                $p1 = new Producto("Coca Cola", "Pack de 6 botellas de 2L", 18.20);
                $p2 = new Producto("Pan bimbo", "Paquete de 12 panes", 21.10);
                $p3 = new Producto("Queso cabrales", "Queso horroroso", 12.10);

                //Proceso de compra de los producto
                $carro->add($p1,2);
                $carro->add($p2,3);
                $carro->add($p3,1);

                //Ver el contenido del carro
                $carro->list();

                //Eliminar elementos del carro
                $carro->remove(1);
                $carro->remove(0);

                //Volver a listar el carro
                $carro->list();

                //Finalizar la compra
                $carro->finalizarCompra();

                //Pagar
                $carro->pagar();


            ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
