<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                // Destinatarios.
                $destinatarios = 'envios@asteralia.com';
                // Asunto.
                $asunto = '¡Hola!';

                // -> origen del mensaje
                $encabezados = "From: \"Asteralia\" <envios@asteralia.com>\r\n";

                // -> mensaje en formato Multipart MIME
                $encabezados .= "MIME-Version: 1.0\r\n";
                $encabezados .= "Content-Type: multipart/mixed; ";
                $encabezados .= "boundary=\"__________\"\r\n";
                // Mensaje.
                $mensaje = '';                

                // -> primera parte del mensaje (texto propiamente dicho)
                // -> encabezado de la parte
                $mensaje .= "--__________\r\n";
                $mensaje .= "Content-Type: text/html; ";
                $mensaje .= "charset=utf-8\r\n ";
                $mensaje .= "Content-Transfer-Encoding: base64\r\n";
                $mensaje .= "\r\n"; // Línea en blanco
                // -> datos de la parte
                
                // Mensaje (HTML).
                $mensaje .= "<html>\n";
                $mensaje .= "<head><title>¡Hola!</title></head>\n";
                $mensaje .= "<body>\n";
                $mensaje .= "<h1>Mail de tipo HTML</h1>\n";
                $mensaje .= "<p>lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. <span style='color: red;'>lorem ipsum</span>. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum.</p>\n";
                $mensaje .="<p><img src='http://localhost/UF1845/20230714-Mails/source/img/2.jpg' height='100' alt='Pedro Picapiedra' /></p>";

                $mensaje .= "</body>\n";
                $mensaje .= "</html>\n";
                $mensaje .= "\r\n"; // línea en blanco

                //Adjunto
                $mensaje .= "--__________\r\n";
                $mensaje .= "Content-Type: application/octet-stream; ";
                $mensaje .= "name=\"php-09-1.pdf\"\r\n";
                $mensaje .= "Content-Transfer-Encoding: base64\r\n";
                $mensaje .= "Content-Disposition: attachment; ";
                $mensaje .= "filename=\"php-09-1.pdf\"\r\n";
                $mensaje .= "\r\n"; // línea en blanco
                $datos = file_get_contents('docs/php-09-1.pdf');

                // -> cifrado y corte de los datos
                $datos = chunk_split(base64_encode($datos));

                // -> datos de la parte (integración en el mensaje)
                $mensaje .= "$datos\r\n";

                $mensaje .= "\r\n"; // línea en blanco

                // Delimitador de fin del mensaje.
                $mensaje .= "--__________--\r\n";

                // Envío
                if (mail($destinatarios,$asunto,$mensaje, $encabezados))
                {
                    echo "Mail enviado correctamente";
                }
                else
                {
                    echo "No se ha podido enviar el mail";
                }
            ?>

            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
