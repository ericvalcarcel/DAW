<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                // Destinatarios.
                $destinatarios = 'envios@asteralia.com';
                // Asunto.
                $asunto = '¡Hola!';
                // Encabezados adicionales.
                $encabezados = '';
                $encabezados = "From: \"Asteralia\" <envios@asteralia.com>\n";
                $encabezados .= "MIME-Version: 1.0\n";
                $encabezados .= "Content-Type: text/html; charset=utf-8\n";
                $encabezados .= "Content-Transfer-Encoding: base64\n";

                // Mensaje (HTML).
                $mensaje = '';
                $mensaje .= "<html>\n";
                $mensaje .= "<head><title>¡Hola!</title></head>\n";
                $mensaje .= "<body>\n";
                $mensaje .= "<h1>Mail de tipo HTML</h1>\n";
                $mensaje .= "<p>lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. <span style='color: red;'>lorem ipsum</span>. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum. lorem ipsum.</p>\n";
                $mensaje .="<p><img src='http://localhost/UF1845/20230714-Mails/source/img/2.jpg' height='100' alt='Pedro Picapiedra' /></p>";

                $mensaje .= "</body>\n";
                $mensaje .= "</html>\n";

                // Cifrado de corte.
                $mensaje = chunk_split(base64_encode($mensaje));

                // Envío
                if (mail($destinatarios,$asunto,$mensaje, $encabezados))
                {
                    echo "Mail enviado correctamente";
                }
                else
                {
                    echo "No se ha podido enviar el mail";
                }
            ?>

            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
