<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                // Destinatario.
                $destinatario = 'envios@asteralia.com,lsoler@nioxlan.com';
                
                // Asunto.
                $asunto = 'Mail más complejo de Lluis';
                
                // Mensaje.
                $mensaje = 'Señor Heurtel,
                Gracias por su registro en nuestro sitio miSitio.com.
                Esperamos que este sitio cumpla con sus expectativas. El webmaster.';
                
                // encabezados adicionales.
                $encabezados['From'] = '"Asteralia" <envios@asteralia.com>';
                $encabezados['Reply-To'] = '"Asteralia" <envios@asteralia.com>';
                $encabezados['X-Priority'] = '1';                

                // Envío.
                if (mail($destinatario,$asunto,$mensaje, $encabezados))
                {
                    echo "Mail enviado correctamente";
                }
                else
                {
                    echo "No se ha podido enviar el mail";
                }
            ?>

            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
