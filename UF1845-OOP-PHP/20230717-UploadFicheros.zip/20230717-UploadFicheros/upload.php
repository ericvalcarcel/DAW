<?php
    //Carpeta de destino del fichero
    $dir_subida = 'source/img/usuarios/';

    //Capturar por sesión el idUsuario
    //Parche TO_DO
    $idUsuario = 2;

    //Renombrar el fichero según nuestra lógica
    $fichero = basename($_FILES['filAvatar']['name']);
    $lista = explode(".",$fichero);
    $extension= end($lista);
    $nombreArchivo = $idUsuario. "." . $extension;

    //Path final del archivo
    $fichero_subido = $dir_subida . $nombreArchivo;

    //Procedemos a mover el archivo subido a su path final
    if (move_uploaded_file($_FILES['filAvatar']['tmp_name'], $fichero_subido)) 
    {
        $mensaje = "El fichero es válido y se subió con éxito.";
        $mensaje .="<p><img src='source/img/usuarios/".$nombreArchivo."' height='100' alt='Avatar' style='border-radius:50px;' /></p>";
    } 
    else 
    {
        $mensaje = "Problema de upload del fichero";
    }

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Upload de recursos</h1>
                <?= $mensaje ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
