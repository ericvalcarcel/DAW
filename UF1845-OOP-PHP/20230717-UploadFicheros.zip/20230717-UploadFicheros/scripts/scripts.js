$(function()
{
    $("#btnUpload").click(function()
    {
        //Validar que está lleno
        //if ($("#filAvatar")[0].files.length == 0)
        if ($("#filAvatar").val()=="")
        {
            alert("Seleccione un fichero");
        }
        else
        {
            $("#frmAvatar").submit();
        }
    });


});