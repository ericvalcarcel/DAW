<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Upload de recursos</h1>
                <form action="upload.php" method="post" enctype="multipart/form-data" id="frmAvatar">
                    <label for="filAvatar">Avatar</label>
                    <input type="file" class="form-control" id="filAvatar" name="filAvatar" accept=".gif, .jpeg, .png" />
                    <hr/>
                    <button type="button" class="btn btn-primary mb-5" id="btnUpload">Upload avatar</button>
                </form>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
