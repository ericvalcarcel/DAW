<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
            <?php
                //Conexión
                $fuente = 'mysql:host=localhost;dbname=neptuno';
                $usuario = 'root';
                $contrasenna = '';

                $sql_select = 'SELECT * FROM producto ORDER BY idProducto';
                $sql_insert = 'INSERT INTO producto 
                    (NombreProducto,PrecioUnidad) VALUES (:p1,:p2)';

                try
                {
                    $db = new PDO($fuente, $usuario, $contrasenna);

                    //Inserción
                    $st = $db->prepare($sql_insert);
                    $st->bindParam(':p1',$nombre);
                    $st->bindParam(':p2',$precio);
                    $nombre = 'Manzanas';
                    $precio = 30.5;

                    $st->execute();

                    //Selección
                    $st = $db->prepare($sql_select);
                    $st->execute();
                    while ($linea = $st->fetch()) 
                    {
                        echo "$linea[0] - $linea[1] - $linea[2] - {$linea["PrecioUnidad"]}<br />";
                        $c = 1/0;
                    }
                    $st = null;
                    $db = null;
                }
                catch(PDOException $e)
                {
                    echo "PDO: " . $e->getCode() . " - " .$e->getMessage();
                }
                catch(ArithmeticError $e)
                {
                    echo "DBZE: " . $e->getCode() . " - " .$e->getMessage();
                }
                catch(Throwable $e)
                {

                    echo $e->getCode() . " - " .$e->getMessage();
                }
            
            


            ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
