<?php 
    require("classes/classes.php") ;
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-md-4">
                    <h3>Entrada itemsBiblioteca</h3>
                    <div class="input-group mb-3">
                        <span class="input-group-text">Nom</span>
                        <input id="txtNomItem" type="text" class="form-control" placeholder="Nom del ItemBiblioteca">
                    </div>
                    <select  id="cmbCategoria" class="form-control mb-3">
                        <?php
                            echo Biblioteca::optionCategories();
                        ?>
                    </select>
                    <select id="cmbBiblioteca" class="form-control mb-3">
                        <?php
                            echo Biblioteca::optionBiblioteques();
                        ?>
                    </select>
                    <div class="d-flex flex-row-reverse mb-3">
                        <button id="btnAltaItem" class="btn btn-secondary">Donar d'Alta</button>
                    </div>
                    <div id="resultMessage"></div>
                </div>
                <div class="col-md-8">
                    <div class="col-6 offset-3">
                        <select  id="cmbMostrarItemsBiblioteca" class="form-control mb-3">
                            <?php
                                echo Biblioteca::optionBiblioteques();
                            ?>
                        </select>
                    </div>
                    <section id="resultMostrarItems"> 
                    </section>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    include("controls/footer.php") ;
    require("controls/links.php") ;
?>