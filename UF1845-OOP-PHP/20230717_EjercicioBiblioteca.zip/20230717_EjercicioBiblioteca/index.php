<?php 
    require("classes/classes.php") ;
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-md-6">
                    <section> 
                        <article>
                            <?php
                            
                                Biblioteca::mostrar();
                            ?>
                        </article>
                    </section>
                </div>
                <div class="col-md-6">
                    <section> 
                        <article>
                            <h3>Creació objecte Bibioteca desde BD</h3>
                            <?php
                                
                                $id=2;
                                $b1=Biblioteca::setObj($id);
                                if($b1) 
                                {
                                    echo $b1->getId(),"<br/>";
                                    echo $b1->getNombre(),"<br/>";
                                    print_r($b1->getItems());
                                    echo "<br/>";
                                }
                                else
                                {
                                    echo "La biblioteca amb id = $id no és a la BD.<br/>";
                                }
                            ?>
                        </article>
                    </section>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    include("controls/footer.php") ;
    require("controls/links.php") ;
?>