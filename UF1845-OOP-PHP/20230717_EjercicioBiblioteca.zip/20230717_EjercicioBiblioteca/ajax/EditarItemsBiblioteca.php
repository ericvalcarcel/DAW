<?php
    require("../classes/classes.php");
    //Recoger parámetros enviados por POST
    $id = $_POST["id"];
    echo ItemBiblioteca::read($id);
?>