<?php
    require("../classes/classes.php");
    //Recoger parámetros enviados por POST
    $nom = $_POST["nom"];
    $categoria = $_POST["categoria"];
    $biblioteca = $_POST["biblioteca"];

    ItemBiblioteca::create($nom,$categoria,$biblioteca);
    echo "<p>$nom Creat amb èxit</p>"
?>