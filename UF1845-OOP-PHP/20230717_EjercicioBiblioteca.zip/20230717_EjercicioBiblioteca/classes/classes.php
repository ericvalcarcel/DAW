<?php
    require("classesDB.php");
    require("traits.php");
    require("interfaces.php");

    class Biblioteca
    {
        //atributos
        private int $id=0;
        private string $nombre="";
        private array $items=[];
        //costructor-destructor
        public function __construct(int $id,string $nombre,array $items)
        {
            $this->id = $id;
            $this->nombre=$nombre;
            $this->items=$items;
            echo "creado $this->nombre","<br/>";
            
        }
        //métodos
        public function getId()
        {
            return $this->id;
        }
        public function getNombre()
        {
            return $this->nombre;
        }
        public function getItems()
        {
           return $this->items;
        }
        public static function mostrar()
        {
            echo "<h3>Llistat de Biblioteques</h3>";
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $result = $db->select("biblioteques","IdBiblioteca,NomBiblioteca");
                $db->disconnect();
                foreach($result as $item)
                {
                    echo $item["IdBiblioteca"] . " - " . $item["NomBiblioteca"] . "<br/>";                        
                }
            }
            else
            {
                echo "ko";
            }
        }
        public static function mostrarItems($id)
        {
            
            /*
            SELECT bi.NomBiblioteca, i.IdItem,ci.NomCategoria,i.NomItem,i.dataDevolucio 
            FROM itemsbiblioteca AS i 
            INNER JOIN items_biblioteques AS ib ON i.IdItem=ib.IdItem 
            INNER JOIN categoriesitems AS ci ON i.IdCategoria=ci.IdCategoria 
            INNER JOIN biblioteques AS bi ON ib.IdBiblioteca=bi.IdBiblioteca 
            WHERE ib.IdBiblioteca=1
            ORDER BY 3;
            
            */
            $table= " itemsbiblioteca AS i 
                    INNER JOIN items_biblioteques AS ib ON i.IdItem=ib.IdItem 
                    INNER JOIN categoriesitems AS ci ON i.IdCategoria=ci.IdCategoria 
                    INNER JOIN biblioteques AS bi ON ib.IdBiblioteca=bi.IdBiblioteca ";
            
            $columns="bi.NomBiblioteca, i.IdItem,ci.NomCategoria,i.NomItem,i.dataDevolucio";
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $result = $db->select($table,$columns,"ib.IdBiblioteca=$id","ci.NomCategoria,i.NomItem");
                $db->disconnect();
                if ($result)
                {
                    echo "<h3 class='text-center'>Llistat d'itemsBiblioteca de la<br/>{$result[0]["NomBiblioteca"]}</h3>";
                    $missatge =     "<table id='tablaResultado' class='table table-condensed table-hover'>
                                        <thead>
                                            <tr>
                                                <th>id</th>
                                                <th>Categoria</th>
                                                <th>Nom</th>
                                                <th>Data Devolució</th>
                                                <th>Accions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>";
                    foreach($result as $item)
                    {
                        $missatge .=       "<tr>
                                                <td>[id]</td>
                                                <td>[Categoria]</td>
                                                <td>[Nom]</td>
                                                <td>[DataDevolucio]</td>
                                                <td>[Accions]</td>
                                            </tr>";
                        $missatge = str_replace("[id]",$item["IdItem"],$missatge);
                        $missatge = str_replace("[Categoria]",$item["NomCategoria"],$missatge);
                        $missatge = str_replace("[Nom]",$item["NomItem"],$missatge);
                        $dataDevolucio = $item["dataDevolucio"]?$item["dataDevolucio"]:"null";
                        $missatge = str_replace("[DataDevolucio]",$dataDevolucio,$missatge);
                        $icons = "<a href='javascript:readItem({$item["IdItem"]});' class='ms-1 bi bi-pencil-square'></a>";
                        $icons .= "<a href='javascript:deleteItem({$item["IdItem"]});' class='ms-1 bi bi-trash3'></a>";
                        $missatge = str_replace("[Accions]",$icons,$missatge);
                    }
                    $missatge .=       "</tbody>
                                    </table>
                                    <!-- Modal ItemsBiblioteca-->
                                    <div class='modal fade' id='modalItem' data-bs-backdrop='static' data-bs-keyboard='false' tabindex='-1' aria-labelledby='modalEmpleadosLabel' aria-hidden='true'>
                                        <div class='modal-dialog modal-lg'>
                                            <div class='modal-content'>
                                            <div class='modal-header'>
                                                <h5 class='modal-title' id='modalItemLabel'>Detalles</h5>
                                                <button type='button' title='Cerrar' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                            </div>
                                            <div id='bdyDetallesItem' class='modal-body'>

                                            </div>
                                            <div id='modalItemFooter' class='modal-footer'>
                                                <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                                            </div>
                                        </div>
                                    </div>";
                    echo $missatge;
                }
                else
                {
                    echo "<h3 class='text-center'>No hi ha resultats</h3>";
                }
                
            }
            else
            {
                echo "ko";
            }
        }
        public static function setObj($id):?Biblioteca
        {
            $table= "items_biblioteques AS ib
                     INNER JOIN biblioteques AS bi ON ib.IdBiblioteca=bi.IdBiblioteca";
            
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $array=[];
                $result = $db->select($table,"NomBiblioteca,IdItem","ib.IdBiblioteca=$id");
                $db->disconnect();
                if ($result)
                {
                    foreach($result as $item)
                    {
                        array_push($array,$item["IdItem"]);
                    }
                    $biblio = new Biblioteca($id,$result[0]["NomBiblioteca"],$array);  
                }
                else
                {
                    $biblio = null;    
                }
                
            }
            else
            {
                $biblio = null;
            }
            return $biblio;
        }
        public static function optionCategories():string
        {
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $select =   "<option value='0'>Seleccionar Categoria...</option>";
    
                $result = $db->select("categoriesitems","IdCategoria,NomCategoria");
                $db->disconnect();
                if($result)
                {
                  foreach($result as $item)
                    {
                        $select.= "<option value='{$item["IdCategoria"]}'>{$item["NomCategoria"]}</option>"; 
                    }
                }
            }
            return $select;
        }
        public static function optionBiblioteques():string
        {
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $select =   "<option value='0'>Seleccionar Biblioteca...</option>";
    
                $result = $db->select("biblioteques","IdBiblioteca,NomBiblioteca");
                $db->disconnect();
                if($result)
                {
                  foreach($result as $item)
                    {
                        $select.= "<option value='{$item["IdBiblioteca"]}'>{$item["NomBiblioteca"]}</option>"; 
                    }
                }
            }
            return $select;
        }
    }


    abstract class ItemBiblioteca
    {
        use TPrestable;
        //atributos
        protected int $IdItem = 0;	
        protected string $NomItem = "";	
        protected int $IdCategoria = 0;	
        protected string $dataDevolucio = "";
        
        //costructor-destructor
        public function __construct($nomItem,$idCategoria,$idBiblioteca)
        {
            $this->IdItem = $IdItem;
            $this->NomItem = $nomItem;
            $this->idCategoria = $idCategoria;
            $this->idBiblioteca = $idBiblioteca;
        }
        //métodos
        public static function create($nomItem,$idCategoria,$idBiblioteca)
        {
            
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $result = $db->insert("itemsBiblioteca",["$nomItem","$idCategoria"],"NomItem,IdCategoria");
                $result = $db->select("itemsBiblioteca","IdItem","NomItem='$nomItem'");
                $result = $db->insert("items_biblioteques",[$idBiblioteca,$result[0]["IdItem"]],"IdBiblioteca,IdItem");
                
                $db->disconnect();
                
                //if($result) echo "Item $nomItem afegit a la BD";
            }
            else
            {
                echo "ko";
            }
        }
        public static function read($id)
        {
            $db=new Database("localhost","root","","xarxabibiloteques");
            if($db->connect())
            {
                $result = $db->select("itemsBiblioteca",
                                      "IdItem,NomItem,IdCategoria,urlItem,dataDevolucio",
                                      "IdItem='$id'");
                
                $db->disconnect();
                $item=$result[0];
                $resultado = "  <input type='hidden' value='$id'/>
                                <div class='mb-3 form-floating'> 
                                    <input type='text' class='form-control' id='NomItem' name='NomItem' placeholder='NomItem' value=\"{$item["NomItem"]}\"/>        
                                    <label for='NomItem' class='form-label'>Nom Item:</label>
                                </div>
                                <select  id='cmbCategoriaForm' class='form-control mb-3'>";
                                
                $resultado .= Biblioteca::optionCategories();
                                
                $resultado .= "</select>
                            <script>$('#cmbCategoriaForm').val('{$item["IdCategoria"]}')</script>
                            <div class='mb-3 form-floating'>        
                                <input type='text' class='form-control' id='urlItem' name='urlItem' placeholder='urlItem' value='{$item["urlItem"]}'>        
                                <label for='urlItem' class='form-label'>url Item:</label>
                            </div>
                            <div class='mb-3 form-floating'>        
                                <input type='date' class='form-control' id='dataDevolucio' name='dataDevolucio' placeholder='dataDevolucio' value='{$item["dataDevolucio"]}'>        
                                <label for='dataDevolucio' class='form-label'>data Devolucio:</label>
                            </div>";
                echo $resultado;
            }
            else
            {
                echo "ko";
            }
        }
        public function update()
        {}
        public function delete()
        {}
    }

    class Libro extends ItemBiblioteca implements Ilegible
    {
        //atributos
        private string $urlLibro="";
        
        //costructor-destructor
        public function __construct($nomItem,$idBiblioteca,$urlLibro)
        {
            parent::__construct($nomItem,1,$idBiblioteca);
            $this->urlLibro = $urlLibro;
        }
        //métodos
        public function leer():string
        {
            return $this->urlLibro; 
        }
    }

    class Revista extends ItemBiblioteca
    {
        //atributos
        private ?Sumario $sumario=null;
        
        //costructor-destructor
        public function __construct(string $nomItem,int $idBiblioteca,Sumario $sumario)
        {
            parent::__construct($nomItem,2,$idBiblioteca);
            $this->sumario = $sumario;
        }
        //métodos
    }


    class Sumario implements Ilegible
    {
        //atributos
        private array $articulos=[];
        //costructor-destructor
        public function __construct(array $articulos)
        {
            $this->articulos = $articulos;
        }
        //métodos
        public function leer():string
        {
            foreach($this->articulos as $articulo)
            {
                $articulo->leer();
            }
        }
    }

    class Articulo implements Ilegible
    {
        //atributos
        private string $nombreArticulo="";
        private string $urlArticulo="";   
        //costructor-destructor
        public function __construct(string $nombreArticulo,string $urlArticulo)
        {
            $this->nombreArticulo = $nombreArticulo;
            $this->urlArticulo = $urlArticulo;
        }
        //métodos
        public function leer():string
        {
            return "<a href='$urlArticulo'>$nombreArticulo</a>";
        }
    }


?>