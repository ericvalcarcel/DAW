<?php
//TPrestable -> prestar(), devolver()
trait TPrestable
{
    public function prestar():bool
    {
        $db=new Database("localhost","root","","xarxabibiloteques");
        try
        {
            $db->connect();
            $result = $db->select("itemsBiblioteca","dataDevolucio","IdItem='$this->id'");
            if(!$result[0]["dataDevolucio"])
            {
                $data = new DateTime();
                $data->add(new DateInterval('P7D'));
                $result = $db->update("itemsBiblioteca",["dataDevolucio=$data"],"IdItem='$this->id'");
                return true;
            }
            else
            {
                //el libro ya està prestado
                return false;
            }
        }
        catch(Exception $e)
        {
            return false;;
        }
        finally
        {
            $db->disconnect(); 
        }
    }
    public function devolver():bool
    {
        $db=new Database("localhost","root","","xarxabibiloteques");
        try
        {
            $data = new DateTime();
            $db->connect();
            $result = $db->select("itemsBiblioteca","dataDevolucio","IdItem='$this->id'");
            if($result[0]["dataDevolucio"]>=$data )
            {
                //Devuelto a tiempo
                $result = $db->update("itemsBiblioteca",["dataDevolucio=null"],"IdItem='$this->id'");
                return true;
            }
            else
            {
                //Devuelto tarde
                //TO_DO poner recargo
                $result = $db->update("itemsBiblioteca",["dataDevolucio=null"],"IdItem='$this->id'");
                return true;
            }
        }
        catch(Exception $e)
        {
            return false;;
        }
        finally
        {
            $db->disconnect(); 
        }
    }
}
?>