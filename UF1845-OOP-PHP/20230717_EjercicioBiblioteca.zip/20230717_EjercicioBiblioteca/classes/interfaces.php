<?php
    //ILegible -> leer()
    interface Ilegible
    {
        public function leer():string;
    }
?>