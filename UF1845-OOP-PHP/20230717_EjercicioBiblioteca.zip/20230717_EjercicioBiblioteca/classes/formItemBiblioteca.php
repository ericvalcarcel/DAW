<div class="mb-3 form-floating">        
    <input type="text" class="form-control bg-light" id="txtEmpresa" name="txtEmpresa" placeholder="Nombre Empresa">        
    <label for="txtEmpresa" class="form-label">Nombre Empresa</label>
</div>
<div class="mb-3 form-floating">        
    <input type="text" class="form-control bg-light" id="txtNombre" name="txtNombre" placeholder="Nombre Contacto">        
    <label for="txtNombre" class="form-label">Nombre Contacto:</label>
</div>
<div class="mb-3 form-floating">        
    <input type="text" class="form-control bg-light" id="txtApellido" name="txtApellido" placeholder="Apellido Contacto">        
    <label for="txtApellido" class="form-label">Apellido Contacto:</label>
</div>

<button id="btnAddProveedor" type="button" class="btn btn-secondary">Añadir Proveedor</button>

<script>
    $("#btnAddProveedor").click(function()
    {
        
        let empresa=$("#txtEmpresa").val();
        let nombre=$("#txtNombre").val();
        let apellido=$("#txtApellido").val();
        
        $.post("classes/addProveedor.php",
        {"empresa":empresa,"nombre":nombre,"apellido":apellido},
        function (data)
        {
            alert("Registro Dado de Alta");
            location.reload(); //actualizar página para mostrar el nuevo registro
        });
    });
</script>
<?php
?>