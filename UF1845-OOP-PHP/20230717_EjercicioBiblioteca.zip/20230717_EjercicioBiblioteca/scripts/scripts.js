flag=false;

$(function()
{
    $('#cmbMostrarItemsBiblioteca').change(function()
    {
        
        id=$("#cmbMostrarItemsBiblioteca").val();
        if(id!=0)
        {
            $.post("ajax/MostrarItemsBiblioteca.php",
            {
            id: id
            },
            function(resp)
            {
                //console.log(resp);
                $("#resultMostrarItems").html(resp);
            });   
        }

    });
    
    $('#btnAltaItem').click(function()
     {
        nom=$("#txtNomItem").val();
        categoria=$("#cmbCategoria option:selected").val();
        biblioteca=$("#cmbBiblioteca option:selected").val();
        
        $("#cmbMostrarItemsBiblioteca option[value='"+biblioteca+"']").attr("selected", true);
        $.post("ajax/crearItemsBiblioteca.php",
        {
            nom: nom,
            categoria: categoria,
            biblioteca: biblioteca,
        },
        function(resp)
        {
            $("#resultMessage").html(resp);
            
            $.post("ajax/MostrarItemsBiblioteca.php",
            {
                id: biblioteca
            },
            function(resp1)
            {
                $("#cmbMostrarItemsBiblioteca").val(biblioteca);
                console.log(resp);
                $("#resultMostrarItems").html(resp1);
                $("#txtNomItem").val("");
                $("#cmbCategoria").val("0");
                $("#cmbBiblioteca").val("0");
                flag=true;

            });
        });
    });
    
    $("#txtNomItem").focus(function()
    {
        if(flag) $("#resultMessage").html("");
    });
});
function readItem(id)
{
    if(id!=0)
    {
        $.post("ajax/EditarItemsBiblioteca.php",
        {
        id: id
        },
        function(resp)
        {
            console.log(resp);
            $('#modalItemLabel').html("Item id= "+id);
            $('#bdyDetallesItem').html(resp);
            $('#modalItem').modal('show');
            
        });   
    }
}