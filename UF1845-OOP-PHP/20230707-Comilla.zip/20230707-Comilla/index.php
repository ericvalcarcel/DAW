<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    try
                    {
                        $conexion = new mysqli("localhost", "root", "", "Neptuno");
                        
                        $nombre = mysqli_real_escape_string($conexion,"B's Beverages");
                        //$nombre ="Alfreds Futterkiste";
                        
                        $sql = "Select * from Cliente where NombreEmpresa = '$nombre'";
                        
                        $resultSet = $conexion->query($sql);
                        while(true)
                        {
                            $linea = $resultSet->fetch_object();
                            
                            if ($linea == null){break;}
                            
                            echo $linea->IdCliente . " - " . $linea->NombreEmpresa . "<br/>";
                        }
                        echo "FIN";
                        $conexion->close();
                    }
                    catch (Throwable $e)
                    {
                        echo $e->getCode() . " - " . $e->getMessage();
                        die();
                    }

                ?>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
