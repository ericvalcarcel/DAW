<footer>
    <div class="container">
        <div class="row">
            <div class="col" style="background-color: black;color: white;">
                <hr/>
                Esto es el footer
            </div>
        </div>
    </div>
</footer>