<?php

interface ILectura
{
    function getRegistro() : string;
    static function getAllRegistros(string $fuente="");
}

interface IEscritura
{
    static function insertRegistro(array $data): bool;
    function updateRegistro(array $data): bool;
    function deleteRegistro(): bool;
}

?>