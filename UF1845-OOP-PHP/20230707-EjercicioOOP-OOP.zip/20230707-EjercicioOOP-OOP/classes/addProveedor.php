<?php
    require_once('classes.php');

    //Recoger parametros
    $empresa = $_POST['empresa']; 
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];

    //Llamar al método insertRegistro de la clase proveedor
    $resultado = Proveedor::insertRegistro([$empresa,$nombre,$apellidos]);

    //Devolver
    echo ($resultado) ? "OK":"KO"; 
?>