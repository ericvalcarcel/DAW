<?php
require('interfaces.php'); 

abstract class Neptuno
{
    //Atributos

    //Constructor

    //Comportamiento
    static public function conectar(?string $host, ?string $userName, ?string $pass, ?string $db)
    {
        try
        {
            $conexion = new mysqli($host, $userName, $pass,$db);
            return $conexion;
        }
        catch (Throwable $e)
        {
            echo $e->getCode() . " - " . $e->getMessage();
            die();
        }
    }

    static public function desconectar($conexion)
    {
        try
        {
            $ok = $conexion->close();
        }
        catch (Throwable $e)
        {
            echo $e->getCode() . " - " . $e->getMessage();
        }
    }
}

abstract class Contacto extends Neptuno implements ILectura
{
    //Atributos
    protected string $id="";
    protected ?string $nombre="";
    protected ?string $apellidos="";
    protected ?string $cargo="";
    protected ?string $direccion="";
    protected ?string $ciudad="";
    protected ?string $telefono="";
    protected string $tipo=""; //C=Cliente; E=Empleado; P=Proveedor

    public string $titulo="";    //Título del modal emergente

    //Constructor
    public function __construct(string $id)
    {
        $this->id= $id;
    }

    //Comportamiento
    abstract public function getRegistro() :string;

    static public function getAllRegistros(string $fuente="")
    {
        //Datatable de contactos
        $html = "<table id='tblContactos' class='table compact hover'>
                    <thead>
                        <tr>
                            <th>#Id</th>
                            <th>Nombre</th>
                            <th>Cargo</th>
                            <th>Dirección</th>
                            <th>Ciudad</th>
                            <th>Teléfono</th>
                            <th>Tipo</th>
                            <th>Información</th>
                        </tr>
                    </thead>
                    <tbody>
                        [filas]
                    </tbody>
                    </table>
                    <div class='modal fade' id='staticBackdrop' data-bs-backdrop='static' data-bs-keyboard='false' tabindex='-1' aria-labelledby='staticBackdropLabel' aria-hidden='true'>
                        <div class='modal-dialog modal-xl'>
                            <div class='modal-content'>
                                <div class='modal-header'>
                                    <h5 class='modal-title' id='staticBackdropLabel'></h5>
                                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                </div>
                                <div class='modal-body' id='modalBody'>
                                </div>
                                <div class='modal-footer'>
                                    <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cerrar</button>
                                </div>
                            </div>
                        </div>
                    </div>";

        $filaTemplate = "<tr>
                            <td>[id]</td>
                            <td>[nombre]</td>
                            <td>[cargo]</td>
                            <td>[dirección]</td>
                            <td>[ciudad]</td>
                            <td>[teléfono]</td>
                            <td>[tipo]</td>
                            <td class='text-center'>[información]</td>
                        </tr>";

        $filas="";

        //SQL para obtener los datos
        $sqlCliente = "SELECT IdCliente, NombreContacto, CargoContacto, Direccion, Ciudad, Telefono,  'Cliente' FROM Cliente";
        
        $sqlProveedor = "SELECT IdProveedor, NombreContacto, CargoContacto, Direccion, Ciudad, Telefono,  'Proveedor' FROM Proveedor";

        $sqlEmpleado ="SELECT IdEmpleado, CONCAT(Nombre,' ',Apellidos), Cargo, Direccion, Ciudad, TelDomicilio,  'Empleado'
        FROM Empleado";

        $sql="";
        switch ($fuente)
        {
            case "":
                $sql= "$sqlCliente UNION $sqlProveedor UNION $sqlEmpleado";
                break;

            case "Proveedor": $sql= $sqlProveedor; break;
            case "Empleado": $sql= $sqlEmpleado; break;
            case "Cliente": $sql= $sqlCliente; break;
        }

        $conexion = Neptuno::conectar("localhost","root","","neptuno");
        $resultSet = $conexion->query($sql);
        while(true)
        {
            $linea = $resultSet->fetch_array();

            if ($linea == null){break;}

            $filas .= $filaTemplate;
            $filas = str_replace("[nombre]",$linea[1],$filas);
            $filas = str_replace("[cargo]",$linea[2],$filas);
            $filas = str_replace("[dirección]",$linea[3],$filas);
            $filas = str_replace("[ciudad]",$linea[4],$filas);
            $filas = str_replace("[teléfono]",$linea[5],$filas);
            $filas = str_replace("[información]","<a href='javascript:getRegistro(\"[id]\",\"[tipo]\")'><i class='bi bi-search'></i></a>",$filas);

            $filas = str_replace("[id]",$linea[0],$filas);
            $filas = str_replace("[tipo]",$linea[6],$filas);

        }
        Neptuno::desconectar($conexion);

        $html = str_replace("[filas]", $filas, $html);

        //Añadir el script del datatable a manopla
        $html .="<script>
                    window.addEventListener('load', (event) => 
                    {
                        let table = new DataTable('#tblContactos',
                        {
                            order: [1, 'asc'],
                            'initComplete': function(settings, json) 
                            {
                                $('#tblContactos_filter').
                                prepend('<a href=\"\"><i class=\"bi bi-person-badge\" title=\"Cliente\" style=\"font-size:1.25em;margin-right:10px;\"></i></a> <a href=\"javascript:addProveedor();\"><i class=\"bi bi-person-bounding-box\" title=\"Proveedor\" style=\"font-size:1.25em;margin-right:10px;\"></i></a> <a href=\"\"><i class=\"bi bi-person-check-fill\" title=\"Empleado\" style=\"font-size:1.25em;margin-right:10px;\"></i></a> ');
                            }
                        });

                    });

                    function getRegistro(id,tipo)
                    {
                        $.ajax(
                        {
                            async: true,
                            type: 'GET',
                            dataType: 'json',
                            contentType: 'application/x-www-form-urlencoded',
                            url: 'classes/showRegistro.php',
                            data: 'id='+id+'&tipo='+tipo,
                            success: function(data)
                            {
                                //UI
                                $('#staticBackdropLabel').html(data.titulo);
                                $('#modalBody').html(data.ficha);
                                $('#staticBackdrop').modal('show');
                            },
                            timeout: 5000,
                            error: function(error) { }
                        });
                    }

                    function addProveedor()
                    {
                        $('#staticBackdropLabel').html('Alta del proveedor');
                        $('#modalBody').load('classes/formProveedor.php');
                        $('#staticBackdrop').modal('show');
                    }
                </script>";
        
        echo  $html;
    }
}

class Proveedor extends Contacto implements IEscritura
{
    //Atributos
    private ?string $nombreEmpresa="";
    private ?string $region="";
    private ?string $codPostal="";
    private ?string $pais="";
    private ?string $paginaPrincipal="";

    //Constructor
    public function __construct($id)
    {
        parent::__construct($id);

        $this->titulo ="Ficha del proveedor";

        //Consultar la BD para rellenar datos
        $sql = "SELECT * FROM Proveedor WHERE idProveedor=" . $this->id;

        $conexion = Neptuno::conectar("localhost","root","","neptuno");
        $resultSet = $conexion->query($sql);
        while(true)
        {
            $linea = $resultSet->fetch_object();

            if ($linea == null){break;}

            $this->nombre= explode(" ",$linea->NombreContacto)[0];
            $this->apellidos= explode(" ",$linea->NombreContacto)[1];
            $this->cargo= $linea->CargoContacto;
            $this->direccion= $linea->Direccion;
            $this->ciudad= $linea->Ciudad;
            $this->telefono= $linea->Telefono;

            $this->nombreEmpresa= $linea->NombreEmpresa;
            $this->region= $linea->Region;
            $this->codPostal= $linea->CodPostal;
            $this->pais= $linea->Pais;
            $this->paginaPrincipal= $linea->PaginaPrincipal;
        }
        Neptuno::desconectar($conexion);

    }

    //Comportamiento
    public function getRegistro() : string
    {
        //Montar la ficha
        return "<p><b>Empresa:</b> " . $this->nombreEmpresa . "</p>
        <p><b>Nombre:</b> " . $this->nombre . "</p>
        <p><b>Apellidos:</b> " . $this->apellidos . "</p>
        <p><b>Cargo:</b> " . $this->cargo . "</p>
        <p><b>Dirección:</b> " . $this->direccion . "</p>
        <p><b>Ciudad:</b> " . $this->ciudad . "</p>
        <p><b>CP:</b> " . $this->codPostal . "</p>
        <p><b>Región:</b> " . $this->region . "</p>
        <p><b>País:</b> " . $this->pais . "</p>
        <p><b>Teléfono:</b> " . $this->telefono . "</p>
        <p><b>URL:</b> " . $this->paginaPrincipal . "</p>";
    }

    static public function getAllRegistros(string $fuente="")
    {
        if ($fuente=="Proveedor" || $fuente=="")
        {
            Contacto::getAllRegistros('Proveedor');
        }
        else
        {
            echo "Error de uso!!!!";
        }

    }

    static public function insertRegistro(array $data): bool
    {
        //Añadir registro a la tabla Proveedores
        $sql="INSERT INTO Proveedor 
            (NombreEmpresa,NombreContacto)
            VALUES
            ('$data[0]','$data[1] $data[2]')";

        $conexion = Neptuno::conectar("localhost","root","","neptuno");
        $numRowsAffected = $conexion->query($sql);
        Neptuno::desconectar($conexion);        

        return ($numRowsAffected==1) ? true : false;
    }

    public function updateRegistro(array $data): bool
    {
        //TO_DO
        return true;
    }

    public function deleteRegistro(): bool
    {
        //TO_DO
        return true;
    }
}

class Cliente extends Contacto implements IEscritura
{
    //Atributos

    //Constructor
    public function __construct($id)
    {
        parent::__construct($id);

        $this->titulo ="Ficha del cliente";

        //TO_DO
    }


    //Comportamiento
    public function getRegistro() : string
    {
        //TO_DO
        return "";
    }

    static public function insertRegistro(array $data): bool
    {
        //TO_DO
        return true;
    }

    public function updateRegistro(array $data): bool
    {
        //TO_DO
        return true;
    }

    function deleteRegistro(): bool
    {
        //TO_DO
        return true;
    }
}

class Empleado extends Contacto implements IEscritura
{
    //Atributos

    //Constructor
    public function __construct($id)
    {
        parent::__construct($id);

        $this->titulo ="Ficha del empleado";

        //TO_DO
    }

    //Comportamiento
    public function getRegistro() : string
    {
        //TO_DO
        return "";
    }

    static public function insertRegistro(array $data): bool
    {
        //TO_DO
        return true;
    }

    public function updateRegistro(array $data): bool
    {
        //TO_DO
        return true;
    }

    public function deleteRegistro(): bool
    {
        //TO_DO
        return true;
    }
}

?>
