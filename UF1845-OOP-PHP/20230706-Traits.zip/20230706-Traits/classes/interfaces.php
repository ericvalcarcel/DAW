<?php
require_once("classes.php");

interface IGestionable
{
    public function promocionar(Empleado $p);
    public function degradar(Empleado $p);

}

?>