<?php
require_once("interfaces.php");
require_once("traits.php");

abstract class Empleado
{
    protected string $nombre="";
    protected string $codigo="";
    protected string $posicion="";

    public function __construct($nombre, $codigo, $posicion)
    {
        $this->nombre = $nombre;
        $this->codigo = $codigo;
        $this->posicion = $posicion;
    }

    public function trabajar()
    {
        echo "<p>{$this->nombre} está trabajando.</p>";
    }

    public function descansar()
    {
        echo "<p>{$this->nombre} está descansando.</p>";
    }

    public function getNombre(): string
    {
        return $this->nombre;
    }
}

class Gerente extends Empleado implements IGestionable
{
    use TVacaciones;

    public function __construct($nombre, $codigo, $posicion, $antiguedad)
    {
        parent::__construct($nombre,$codigo,$posicion);
        $this->antiguedad = $antiguedad;
    }

    public function promocionar(Empleado $p)
    {
        echo "<p>{$this->nombre} está promocionando a {$p->getNombre()}</p>";

    }
    public function degradar(Empleado $p)
    {
        echo "<p>{$this->nombre} está degradando a {$p->getNombre()}</p>";
    }
}

class Personal extends Empleado
{
    use TVacaciones;

    public function __construct($nombre, $codigo, $posicion, $antiguedad)
    {
        parent::__construct($nombre,$codigo,$posicion);
        $this->antiguedad = $antiguedad;
    }
}

?>