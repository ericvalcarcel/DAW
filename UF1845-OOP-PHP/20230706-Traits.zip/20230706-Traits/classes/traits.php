<?php

trait TVacaciones
{
    public int $antiguedad=0;

    public function calcularDiasVacaciones()
    {
        echo "<p>{$this->nombre} tiene de vacaciones: " . (10 + $this->antiguedad) . " días.</p>";
    }
}

?>