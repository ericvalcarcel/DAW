<?php
    require_once("classes/classes.php");

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    $p1 = new Personal("Pedro Picapiedra","123","Operario",5);

                    $p2 = new Personal("Pablo Mármol","987","Operario",3);

                    $p1->trabajar();
                    $p1->descansar();
                    $p2->trabajar();
                    $p2->descansar();

                    $p1->calcularDiasVacaciones();
                    $p2->calcularDiasVacaciones();

                    $g1 = new Gerente("Vilma Picapiedra","555","CEO",10);
                    $g1->promocionar($p2);
                    $g1->degradar($p1);

                ?>
            </div>
            <div class="col"></div>
            <div class="col"></div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
