<?php 
    require("classes/classes.php") ;
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col-md-12">
                    <section> 
                        <article>
                            <h3>Ecomerce trait</h3>
                            <p>
                            <?php
                                $roque = new Administrador(10);
                                $roque->read();

                                $pedro = new Cliente(135);
                                $pablo = new Cliente(243);

                                $pablo->logout();
                                $roque->logout();
                                
                                Producto::create(["Huevo Astegosaurio",25,"Manda Huevos"]);
                                $HuevoAstegosaurio = new Producto(123);
                                $HuevoAstegosaurio->read();
                                $HuevoAstegosaurio->update(["Huevo Astegosaurio",30,"Manda Más Huevos"]);

                                $pedro->darOpinion("Mmmm.. Riquisimos!!",$HuevoAstegosaurio);
                                $pablo->darOpinion("No vale la pena pagar tanto.",$HuevoAstegosaurio);
                                
                                $HuevoAstegosaurio->delete();
                                
                            ?>
                            </p> 
                        </article>
                    </section>
                </div>
                
            </div>
        </div>
    </main>

<?php 
    //include("controls/aside.php") ;
    //include("controls/footer.php") ;
    require("controls/links.php") ;
?>