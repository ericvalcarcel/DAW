<header>
    <div class="container">
        <div class="row my-1">
            <div class="col-12 text-center">
                <h1>Header</h1>
            </div>
        </div>
    </div>
</header>

        