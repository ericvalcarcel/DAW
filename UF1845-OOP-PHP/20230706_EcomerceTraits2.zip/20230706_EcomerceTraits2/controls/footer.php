<footer>
    <div class="container-fluid">
        <div class="row bg-secondary text-light text-center">
            <div class="col-md-4 my-md-4 my-1">
                <h5>FooterSeccion1</h5>
            </div>
            <div class="col-md-4 my-md-4 my-1 d-md-block d-none">
                <h5>FooterSeccion2</h5>
            </div>
            <div class="col-md-4 my-md-4 my-1 d-md-block d-none">
                <h5>FooterSeccion3</h5>
            </div>
        </div>
    </div>
</footer>
