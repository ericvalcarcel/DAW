<?php
//Crea una interfaz ICrud que tenga los métodos create, read, update y delete.
interface ICrud
{
    public static function create(array $params);
    public function read();
    public function update(array $params);
    public function delete();
}
?>