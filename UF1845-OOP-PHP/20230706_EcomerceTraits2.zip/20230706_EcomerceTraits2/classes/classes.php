<?php
//Crea una clase abstracta Usuario con propiedades username, email y métodos login, logout.
require_once("interfaces.php");
require_once("traits.php");

$productos=[];

abstract class Usuario
{
    protected int $id=0;
    protected string $username="";
    protected string $email="";
 

    public function __construct(int $id) 
    {
        $this->id = $id;
        //...BD

        //Se rellena $username y $email

        echo "Se ha creado $this->username.<br/>";
    }

    function login($email, $password) : void
    {
        if($this->id==0)
        {
            $sql = "SELECT idUsuario FROM Usuario 
                WHERE login='$email' AND pass='$password'";
            //...BD
            $id=25;

            //Suponer que logina
            $this->id = $id;        //Session

            echo $this->email." login<br/>";
        }
        else
        {
            echo $this->email." ya estaba loginado<br/>";
        }
        
    }
    function logout() : void
    {
        if($this->id!=0)
        {
            $this->id=0;
            echo $this->email." logout<br/>";
        }
        else
        {
            echo "NO estaba loginado<br/>";
        }
    }
}

//Crea una clase Producto que tenga propiedades nombre, precio, descripción y que implemente ICrud.

class Producto implements ICrud
{
    private int $id=0;
    private string $nombre="";
    private int $precio=0;
    private string $descripcion="";

    public function __construct(int $id) 
    {
        $this->id = $id;

        echo "Construido el producto $id.<br/>";
    }

    public static function create(array $params)
    {
        //Alta en base de datos a partir del array
        $sql = "INSERT INTO Producto (nombre,precio,descripcion) 
        VALUES ('$params[0]',$params[1],'$params[2]')";
        //...BD
        
        echo "Creado $params[0].<br/>";
    }
    
    public function read()
    {
        //BD y rellenamos el producto
        $sql = "SELECT * FROM Producto WHERE idProducto=$this->id"; 
        //...BD

        echo "Leído el producto $this->id.<br/>";
    }
    public function update(array $params)
    {
        //BD y rellenamos el producto
        $sql = "UPDATE FROM Producto 
            SET nombre='$params[0]',
                precio=$params[1],
                descripcion='$params[2]'
            WHERE idProducto=$this->id"; 
        //...BD

        echo "producto $params[0] actualizado.<br/>";
    }

    public function delete()
    {
        $sql = "DELETE FROM Producto WHERE idProducto=$this->id"; 
        //...BD

        echo "Borrado el producto $this->id.<br/>";
    }

    public function getNombre()
    {
        return $this->nombre;
    }

}

//Crea la clase Administrador que herede de Usuario e implemente ICrud.

class Administrador extends Usuario implements ICrud
{
   
    public function __construct(int $id) 
    {
        $this->id = $id;

        echo "Construido el administrador $id.<br/>";
    }

    public static function create(array $params)
    {
        //Alta en base de datos a partir del array
        $sql = "INSERT INTO Usuario (username,email) 
        VALUES ('$params[0]','$params[1]')";
        //...BD
        
        echo "Creado $params[0].<br/>";
    }
    
    public function read()
    {
        //BD y rellenamos el producto
        $sql = "SELECT * FROM Usuario WHERE idUsuario=$this->id"; 
        //...BD

        echo "Leído el Administrador $this->id.<br/>";
    }

    public function update(array $params)
    {
        //BD y rellenamos el producto
        $sql = "UPDATE FROM Usuario 
            SET username='$params[0]',
                email='$params[1]'
            WHERE idUsuario=$this->id"; 
        //...BD

        echo "Administrador $params[0] actualizado.<br/>";
    }

    public function delete()
    {
        $sql = "DELETE FROM Usuario WHERE idUsuario=$this->id"; 
        //...BD

        echo "Borrado el administrador $this->id.<br/>";
    }
}

//Crea la clase Cliente que herede de Usuario y utilice el Rasgo TRevisable.
class Cliente extends Usuario
{
    use TRevisable;

    public function __construct(int $id) 
    {
        parent::__construct($id);
    }
}

?>