<?php
//Crea un Rasgo TRevisable que tenga un método darOpinion para dejar un comentario sobre un Producto.
trait TRevisable
{
    public function darOpinion(string $opinion,Producto $p)
    {
        echo "$this->username ha dado su opinión sobre el producto {$p->getNombre()}<br/>-<b>Opinión:</b> $opinion.<br/>";
    }
}
?>