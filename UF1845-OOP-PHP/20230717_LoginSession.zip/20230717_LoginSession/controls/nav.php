<nav class="navbar navbar-expand-sm container">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="presentacion.php">Presentación</a>
        </li>
        <?php
            if (isset($_SESSION["idUsuario"]))
            {
        ?>
            <li class="nav-item">
                <a class="nav-link" href="entrada.php">Panel de control</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="clientes.php">Clientes</a>
            </li>
        <?php 
            }
        ?>
    </ul>
</nav>
