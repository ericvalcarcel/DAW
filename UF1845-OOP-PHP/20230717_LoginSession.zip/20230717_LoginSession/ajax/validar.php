<?php
session_start();

require("../classes/Database.php");

//Recoger parámetros enviados por POST
$nif = $_POST["n"];
$pass = $_POST["p"];    //en MD5

//Validar credenciales contra BD
$db = new Database("localhost","root","","neptuno");

if ($db->connect())
{
    $result = $db->select("usuario","idUsuario,usuario","login='$nif' AND pass='$pass' AND Estado=1");
    $db->disconnect();
    if (count($result) > 0)
    {
        //TO_DO
        //Gestionar la sesión
        $_SESSION["idUsuario"]=$result[0]["idUsuario"];
        $_SESSION["usuario"]=$result[0]["usuario"];
        
        echo "ok";
    }
    else
    {
        echo "ko";    
    }
}
else
{
    echo "ko";
}

?>