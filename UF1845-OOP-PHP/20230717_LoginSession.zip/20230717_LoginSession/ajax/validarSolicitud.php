<?php
require("../classes/Database.php");

//recoger email
$email = $_POST['email'];

//Comprobar que el mail existe y que está activo
$db = new Database("localhost","root","","neptuno");

if ($db->connect())
{
    $resultSet = $db->select("usuario","idUsuario, usuario","login='$email' AND Estado=1");

    if (count($resultSet) > 0)
    {
        $idUsuario = $resultSet[0]["idUsuario"];
        $usuario = $resultSet[0]["usuario"];

        //Generar un codigoUsuario
        $codigo = md5($idUsuario);
        $fecha = (new DateTime())->format('Y-m-d H:i:s');

        try
        {
            $db->insert("codigoUsuario",
                [$idUsuario,$codigo,$fecha],
                "idUsuario,codigo,fechaLimite");

            //Enviar correo para cambiar contraseña
            //	.../cambiarContrasenna.php?c=XXXXXXXXXXXXXXXXXX        
            // Asunto.
            $destinatarios = $email;

            $asunto = 'Recuperación de contraseña en misitio.com (Lluis)';
                                    
            // Encabezados adicionales.
            $encabezados = '';
            $encabezados = "From: \"misitio.com\" <registro@misitio.com>\n";
            $encabezados .= "MIME-Version: 1.0\n";
            $encabezados .= "Content-Type: text/html; charset=utf-8\n";
            $encabezados .= "Content-Transfer-Encoding: base64\n";

            // Mensaje (HTML).
            $mensaje = '';
            $mensaje .= "<html>\n";
            $mensaje .= "<head><title>Recuperación de contraseña</title></head>\n";
            $mensaje .= "<body>\n";
            $mensaje .= "<h1>Recuperación de contraseña</h1>\n";
            $mensaje .= "<p>Acceda al siguiente enlace para restablecer su contraseña</p>\n";
            $mensaje .="<p><a href='http://localhost/UF1845/20230717_LoginSession/cambiarContrasenna.php?c=$codigo' style='color:blue; text-decoration:underline;'>Recuperar contraseña</a></p>";

            $mensaje .="<p>MiSitio.com</p>";
            $mensaje .="<p>webmaster@misitio.com</p>";
            $mensaje .= "</body>\n";
            $mensaje .= "</html>\n";

            // Cifrado de corte.
            $mensaje = chunk_split(base64_encode($mensaje));

            // Envío
            mail($destinatarios,$asunto,$mensaje, $encabezados);

            echo "Se le ha enviado un email a su cuenta de correo para restablecer la contraseña.";
        }
        catch (Exception $e)
        {

        }
        finally
        {
            $db->disconnect();
        }
    }
    else
    {
        echo "No existe el usuario en la base de datos";
    }
}
else
{
    echo "Error al conectarse a la base de datos";
}


?>