<?php
session_start();
function testSession() : bool
{
    $flag = true;
    if (!isset($_SESSION["idUsuario"]))
    {
        //cosillas
        //...
        $flag=false;
    }
    return $flag;
}


?>