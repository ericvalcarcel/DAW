<?php
    //Control de permiso de acceso
    require('functions/functions.php'); 
    if (!testSession()) header("Location: index.php");

    //sql capturar los datos del usuario en sesión
    //SELECT * FROM usuario WHERE idUsuario = $_SESSION["idUsuario"]

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>
<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h2>Editar perfil de <?= $_SESSION["usuario"] ?></h2>
                <p>Formulario con el el resto de datos</p>
            </div>
        </div>
    </div>
</main>


<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
