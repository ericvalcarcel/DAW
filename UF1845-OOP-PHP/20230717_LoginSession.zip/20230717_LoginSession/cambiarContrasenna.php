<?php

    require("classes/Database.php");

    //Recuperar parámetro
    $c="";
    if (isset($_GET["c"]))
    {
        $c= $_GET["c"];
    }
    else
    {
        header("location: login.php");
        exit();
    }

    //Recuperar de codigoUsuario
    $db = new Database("localhost","root","","neptuno");
    try
    {
        $db->connect();
        $resultSet = $db->select("codigousuario","idUsuario,fechaLimite","codigo='$c'");
        if (count($resultSet)>0)
        {
            //Verificar que estamos en tiempo (3 días máximo)
            $idUsuario = $resultSet[0]["idUsuario"]; 
            $fechaDeAlta = new DateTime($resultSet[0]["fechaLimite"]); 
            $fechaHoy = new DateTime();

            $diff = $fechaHoy->diff($fechaDeAlta);
            if ($diff->days>3)   //Si es mayor a 3, caducado
            {
                //caducado  -> pasar estado a 2 del usuario

                //borrar de codigousuario
                $db->delete("codigousuario", true, "idUsuario=$idUsuario");

                header("Location: recordarContrasenna.php");  //OJO
                exit();
            }
        }
        else
        {
            header("Location: recordarContrasenna.php");  //OJO
            exit();
        }
    }
    catch (Exception $e) 
    { 
        header("Location: recordarContrasenna.php");  //OJO
        exit();
    }
    finally
    {
        $db->disconnect();
    }

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>
<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col text-center gris">
                <h2>Restablecer contraseña</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 offset-md-4 login">
                <input type="hidden" id="idUsuario" value="<?= $idUsuario ?>" />
                <div class="mb-3">        
                    <p>
                        <label for="password">Password:</label>
                        <input type="password" name="password" id="password" />
                        <i class="bi bi-eye-slash" id="togglePassword"></i>
                    </p>
                </div>
                <div class="mb-3">        
                    <p>
                        <label for="password1">Confirmar:</label>
                        <input type="password" name="password1" id="password1" />
                        <i class="bi bi-eye-slash" id="togglePassword1"></i>
                    </p>
                </div>
                <hr/>
                <div class="mt-3 mb-3">  
                    <button type="button" class="btn btn-outline-primary" id="btnCambiar">Cambiar contraseña</button>
                </div>
                <div class="text-danger mb-3" id="divMensaje"></div>
            </div>
        </div>
    </div>
</main>


<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
