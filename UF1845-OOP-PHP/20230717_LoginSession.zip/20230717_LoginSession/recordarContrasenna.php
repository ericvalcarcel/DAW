<?php
    require("classes/Database.php");

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>
<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col text-center gris">
                <h2>Recordar contraseña</h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 offset-md-4 login">
                <div class="mb-3 form-floating">        
                    <input type="email" class="form-control" id="txtEmail" name="txtEmail" required>
                    <label for="txtEmail" class="form-label">Email</label>
                </div>
                <hr/>
                <div class="mt-3 mb-3">  
                    <button type="button" class="btn btn-outline-primary" id="btnEnviar">Enviar solicitud de cambio de contraseña</button>
                </div>
                <div class="text-danger mb-3" id="divMensaje"></div>
            </div>
        </div>
    </div>
</main>


<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
