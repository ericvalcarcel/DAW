//Datatables.net
let table = new DataTable('#tblFacturas');


function modificarEstado(id)
{
    //Poner spinner el elemento que toque
    $("#fact_"+id).html("<div class='spinner-border' role='status'><span class='sr-only'></span></div>");

    //Lamada ajax a PHP que actualiza la factura
    $.get("actualizarFactura.php?id="+id, function(resp)
    {
        //Update UI
        if(resp == "ok")
        {
            //Actualizamos literal
            $("#fact_"+id).html("Cobrada");

            //Quitar el enlace
            $("#fact_"+id).removeAttr("href");
        }
        else
        {
            //Alert de aviso
            alert("Error al actualizar la factura");
            $("#fact_"+id).html("Pendiente");
        }
    });

}