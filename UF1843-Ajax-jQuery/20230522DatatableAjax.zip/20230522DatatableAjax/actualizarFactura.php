<?php
//Recogemos el id de la factura a actualizar
$id = $_GET["id"];

//Actualizamos la BD
//TO_DO
sleep(3);

//Devolvemos ok / ko
echo "ok";

?>