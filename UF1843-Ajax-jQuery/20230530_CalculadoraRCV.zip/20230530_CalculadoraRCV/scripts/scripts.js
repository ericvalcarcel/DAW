$(function()
{
    var puntos = 0;

    $("#btnPaso1Si").click(function()
    {
        puntos +=10;
        irPasoN(2);
    });
    $("#btnPaso1No").click(function()
    {
        puntos +=0;
        irPasoN(2);
    });
    $("#btnPaso2Si").click(function()
    {
        puntos +=6;
        irPasoN(3);
    });
    $("#btnPaso2No").click(function()
    {
        puntos +=0;
        irPasoN(3);
    });
    $("#btnPaso3Si").click(function()
    {
        puntos +=9;
        irPasoN(4);
    });
    $("#btnPaso3No").click(function()
    {
        puntos +=0;
        irPasoN(4);
    });
    $("#btnPaso4Si").click(function()
    {
        puntos +=6;
        irPasoN(5);

        //Mostrar resultado
        mostrar(puntos);
    });
    $("#btnPaso4No").click(function()
    {
        puntos +=0;
        irPasoN(5);

        //Mostrar resultado
        mostrar(puntos);
    });
});

function irPasoN(paso)
{
    $("#btnPaso"+(paso-1)+"Si").prop("disabled",true);
    $("#btnPaso"+(paso-1)+"No").prop("disabled",true);
    $("#opcion"+(paso-1)).removeClass("show");
    $("#opcion"+(paso-1)).removeClass("active");
    $("#linkOpcion"+(paso-1)).removeClass("active");
    $("#opcion"+paso).addClass("show");
    $("#opcion"+paso).addClass("active");
    $("#linkOpcion"+paso).addClass("active");
}

function mostrar(puntos)
{
    let mensaje ="";
    if (puntos<=5)
    {
        mensaje="Riesgo bajo";
    }
    else if (puntos<=15)
    {
        mensaje="Riesgo medio";
    }
    else if (puntos<=30)
    {
        mensaje="Riesgo alto";
    }
    else
    {
        mensaje="Riesgo muy alto";
    }

    $("#opcion5").html(mensaje);

}