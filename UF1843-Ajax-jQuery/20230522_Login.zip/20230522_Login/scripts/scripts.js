$(function()
{
    $("#btnEntrar").click(function()
    {
        //Recoger NIF y passwords y validarlos
        let nif = $("#txtNif").val();
        let pass = $("#pasContrasena").val();

        //Validación por javascript
        if(nif == "" || pass == "")
        {
            $("#divMensaje").html("Debe introducir datos válidos.");
        }
        else
        {
            //Ajax para validar credenciales
            $.post("validar.php",
            {
                n: nif,
                p: pass
            },
            function(resp)
            {
                //Update UI
                if(resp == "ok")
                {
                    //Credenciales válidas
                    location.href="entrada.php";
                }
                else
                {
                    //Credenciales inválidas
                    $("#divMensaje").html("Credenciales incorrectas.");
                    $("#txtNif").val("");
                    $("#pasContrasena").val("");
                    $("#txtNif").focus();
                }
            });

        }


    });


});