$(function()
{
    //Ajax para cargar provincias
    //TO_DO

    $("#cmbProvincias").change(function()
    {
        let provincia = $(this).val();
        if (provincia!="0")
        {
            //Lanzar AJAX
            $.ajax({
                async: true,
                type: "GET",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "obtenerCiudades.php",
                data: "cod=" + provincia,
                beforeSend: function() 
                {
                    $("#divCiudades").html("<div class='spinner-border' role='status'><span class='sr-only'></span></div>");
                },
                success: function(data)
                {
                    $("#divCiudades").html(data);
                },
                timeout: 5000,
                error: function(error)
                {
                    console.log("Error de servidor: " + error);
                }
            });
        }
        else
        {
            $("#divCiudades").html("<select class='form-control' id='cmbCiudades'><option value='0'>Seleccionar ciudad</option></select>");
        }
    });
});