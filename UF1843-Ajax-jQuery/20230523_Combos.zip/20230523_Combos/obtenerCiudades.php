<?php

//Obtener los valores de parámetros enviados
$cadena = $_GET["cod"];


//Acceder a BD y obtener los datos
//TO_DO
sleep(2);

//Formatear los datos 
$html="";
switch ($cadena)
{
    case "1":
        $html = "<select class='form-control' id='cmbCiudades'>
                    <option value='0'>Seleccionar ciudad</option>
                    <option value='1'>Barcelona</option>
                    <option value='2'>Mataró</option>
                    <option value='3'>Calella</option>
                </select>";
            break;

    case "2":
        $html = "<select class='form-control' id='cmbCiudades'>
                    <option value='0'>Seleccionar ciudad</option>
                    <option value='1'>Tarragona</option>
                    <option value='2'>Roda de Bará</option>
                    <option value='3'>L'Atmella</option>
                </select>";
            break;

        case "3":
            $html = "<select class='form-control' id='cmbCiudades'>
                        <option value='0'>Seleccionar ciudad</option>
                        <option value='1'>Lleida</option>
                        <option value='2'>Balaguer</option>
                        <option value='3'>Mollerussa</option>
                    </select>";
                break;


        case "4":
            $html = "<select class='form-control' id='cmbCiudades'>
                        <option value='0'>Seleccionar ciudad</option>
                        <option value='1'>Girona</option>
                        <option value='2'>L'Escala</option>
                        <option value='3'>Cadaqués</option>
                    </select>";
                break;
    }

//Enviar datos a javascript
echo $html;

?>