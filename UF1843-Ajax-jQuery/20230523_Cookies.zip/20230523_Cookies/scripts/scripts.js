$(function()
{
    $("#btnGuardar").click(function()
    {
        setCookie("Prueba",$("#txtCookie").val(),365);

        setCookie("Otra","Esto es otro texto",365);

        alert("Cookie almacenada");
    });

    $("#btnRecuperar").click(function()
    {
        var cookie = getCookie("Prueba");
        alert(cookie);
    });
})