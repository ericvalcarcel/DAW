$(function()
{
    var map=null;
    var latUsuario=0;
    var lonUsuario=0;
    $("#obtener").click(function()
    {
        navigator.geolocation.getCurrentPosition(
        function(posicion)
        {

            $("#divResultado").html("Latitud: " + posicion.coords.latitude + "<br>Longitud: " + posicion.coords.longitude + 
            "<br>Exactitud: " + posicion.coords.accuracy + "mts.<br>");

            //Pintar un mapa

            //Posicionar el mapa
            map = L.map('mapa').setView([posicion.coords.latitude, posicion.coords.longitude], 13);

            //Ponemos el fondo del mapa
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', 
            {
                maxZoom: 19,
                attribution: 'Curso Web'
            }).addTo(map);  

            //Marker
            let marker = L.marker([posicion.coords.latitude, posicion.coords.longitude]).addTo(map);
            latUsuario = posicion.coords.latitude;
            lonUsuario = posicion.coords.longitude;

            marker.bindPopup("<b>Hello world!</b><br>Mi ubicuación actual.").openPopup();

        },
        function(error)
        {
            $("#divResultado").html("Error: " + error.code + " " + error.message);
        });
    });

    $("#btnMostrarMapa").click(function()
    {
        let address = $("#txtUbicacion").val();

        // Realizar solicitud de geocodificación a Nominatim
        fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(address))
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.length > 0) {
            var lat = parseFloat(data[0].lat);
            var lon = parseFloat(data[0].lon);

            // Centrar el mapa en las coordenadas geográficas encontradas
            map.setView([lat, lon], 13);

            // Agregar un marcador en la ubicación encontrada
            let texto = address + "<br/><a href='pagina.php' target='_blank'>pagina.php</a>";

            L.marker([lat, lon]).addTo(map).bindPopup(texto).openPopup();

            



            } 
            else 
            {
                alert('No se encontraron resultados para la dirección ingresada.');
            }
        })
        .catch(function(error) {
            console.log('Error:', error);
            alert('Ocurrió un error al realizar la solicitud de geocodificación.');
        });
    });

    $("#btnMostrarRuta").click(function()
    {
        let address = $("#txtUbicacion").val();

        // Realizar solicitud de geocodificación a Nominatim
        fetch('https://nominatim.openstreetmap.org/search?format=json&q=' + encodeURIComponent(address))
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.length > 0) 
            {
                var lat = parseFloat(data[0].lat);
                var lon = parseFloat(data[0].lon);

                // Centrar el mapa en las coordenadas geográficas encontradas
                map.setView([lat, lon], 13);

                // Agregar un marcador en la ubicación encontrada
                let texto = address + "<br/><a href='pagina.php' target='_blank'>pagina.php</a>";

                L.marker([lat, lon]).addTo(map).bindPopup(texto).openPopup();

                //Mostrar la ruta
                var destination = L.latLng(lat, lon); // Coordenadas de destino
                L.Routing.control({
                waypoints: [
                  L.latLng(latUsuario , lonUsuario ), // Ubicación del usuario
                  destination  
                    ]
                }).addTo(map);              

            } 
            else 
            {
                alert('No se encontraron resultados para la dirección ingresada.');
            }
        })
        .catch(function(error) {
            console.log('Error:', error);
            alert('Ocurrió un error al realizar la solicitud de geocodificación.');
        });
    });

    

});
