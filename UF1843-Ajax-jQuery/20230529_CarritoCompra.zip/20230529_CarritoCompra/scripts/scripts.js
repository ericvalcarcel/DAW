$(function()
{
    //Cargar funcionalidad de cada botón o producto
    $("#btnProducto1").click(function()
    {
        addItem("Coca cola de 2 L", 3.90);
    });
    $("#btnProducto2").click(function()
    {
        addItem("Pan Bimbo", 2.85);
    });
    $("#btnProducto3").click(function()
    {
        addItem("Caja de tomates", 1.85);
    });

    //Mostrar el carrito
    mostrarCarrito();

});

function addItem(nombre, precio)
{
    //Crear nuevo producto
    let cartItem = 
    {
        name: nombre,
        price: precio
    };

     //Deserializar el SessionStorage de JSON a Array
    let items = (sessionStorage["cartItems"] != null) ? JSON.parse(sessionStorage["cartItems"]) : [];
        
    //Añadimos el ítem seleccionado a la colección de items
    items.push(cartItem);

    //Serializar y guardar en la sesión storage
    sessionStorage["cartItems"] = JSON.stringify(items);

    mostrarCarrito();

}

function mostrarCarrito()
{
    //Deserializar
    let items = (sessionStorage["cartItems"] != null) ? JSON.parse(sessionStorage["cartItems"]) : [];

    //Iterar
    $("#cartItems").html("");
    let importeTotal = 0;
    items.forEach(function(item)
    {
       /*
        let li = document.createElement("li");
        li.innerHTML = item.name + " - " + item.price;
        document.getElementById("cartItems").appendChild(li);
       */

        //Mostrar la lista de items en el ul
        $("#cartItems").append("<li>" + item.name + " - " + item.price + "</li>");

        importeTotal += item.price;
    });

    //Mostrar total del carrito
    $("#divImporte").html(importeTotal + " €");
}