window.addEventListener("load",function()
{
    let btnMenos = document.getElementById("btnMenos");
    btnMenos.addEventListener("click", function()
    {
        document.getElementById("divMensaje").innerHTML="";

        let txtCantidad = document.getElementById("txtCantidad");
        txtCantidad.value = parseInt(txtCantidad.value) - 1;
        if(txtCantidad.value < 0) txtCantidad.value="0";

        doAjax(txtCantidad);
    });

    let btnMas = document.getElementById("btnMas");
    btnMas.addEventListener("click", function()
    {
        document.getElementById("divMensaje").innerHTML="";

        let txtCantidad = document.getElementById("txtCantidad");
        txtCantidad.value = "" + (parseInt(txtCantidad.value) + 1);

        doAjax(txtCantidad);
    });
});

function doAjax( obj )
{
    //Verificar que existe stock
    //Verifica por AJAX
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() 
    {
        if (this.readyState == 4 && this.status == 200) 
        {
            //Update UI
            let stock = parseInt(xhttp.responseText);
            if (stock < parseInt(obj.value))
            {
                //Correcciones
                obj.value = stock;
                document.getElementById("divMensaje").innerHTML = "Se ha superado el stock disponible";
            }
        }
    };
    //Simular que el producto es el idProducto=222;
    xhttp.open("GET", "obtenerStock.php?idProducto=222", true);
    xhttp.send();

}