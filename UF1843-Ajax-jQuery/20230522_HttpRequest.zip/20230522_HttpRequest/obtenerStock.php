<?php
    //Recoger idProducto
    $idProducto = $_GET["idProducto"];

    //Consultar el stock en la BD
    //TO_DO
    sleep(0.25);
    $stock = 2;

    //Devolver el stock
    echo $stock;

?>