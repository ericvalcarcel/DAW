$(function()
{
    $("#grabar").click(function()
    {
        sessionStorage[$("#clave").val()] = $("#texto").val();
        mostrar($("#clave").val());

        $("#clave").val("");
        $("#texto").val("");
    });

    $("#recuperar").click(function()
    {
        $("#texto").val(sessionStorage[$("#clave").val()]);
    });

});

function mostrar(clave)
{
    $("#cajadatos").html("<div>" + clave + " - " + sessionStorage[clave] + "</div>");
}