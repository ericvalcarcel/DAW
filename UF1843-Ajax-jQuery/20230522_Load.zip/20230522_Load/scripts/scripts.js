var urlBase = "http://localhost/UF1843/20230522_Load/";
$(function()
{
    /*
    let html = $(body).html();
    //Parsear y cambiar

    $(body).html(html);
    */

    //Cargar el header
    $("header").load("header.html");

    //...

    //Cargar el nav
    $("nav").load("nav.html");

    //Cargar el footer
    let urlActual = location.href;
    urlActual = urlActual.replace(urlBase,"");
    switch (urlActual)
    {
        case "":
        //case "index.html":
            $("footer").load("footer1.html");
            break;

        case "empresa.html":
            $("footer").load("footer2.html");
            break;

        case "servicios.html":
            $("footer").load("footer2.html");
            break;
    }

    //...
});