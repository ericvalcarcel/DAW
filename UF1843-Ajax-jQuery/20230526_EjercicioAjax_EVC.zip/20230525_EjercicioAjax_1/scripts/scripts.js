var table=null;
$(function(){
   
    $.ajax({
                async: true,
                type: "GET",
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                url: "https://randomuser.me/api/",
                data: "results=1001",
                beforeSend: function()
                {
                    let spiner =    "<div class='spinner-border text-primary text-center m-2'>"+
                                    "<span class='visually-hidden'>Loading...</span>"+
                                    "</div>";
                    $("#divResultado").html(spiner);
                },
                success: function(data)
                {       
                    $("#divResultado").html("");
                    let usuarios = data.results;
                    usuarios.forEach(function(usuario)
                    {
                        //console.log(usuario);
                        let nombre = usuario.name.first + " " + usuario.name.last;
                        let nombreUsuario = usuario.login.username;
                        let direccion = usuario.location.street.name + " nº: " +  usuario.location.street.number + " " + "</br>(" + usuario.location.postcode + ") " + usuario.location.city+ ", " + usuario.location.state + ", " + usuario.location.country;
                        let email = usuario.email;
                        let telefono = usuario.phone;
                        $("#divResultado").append("<tr><td>" + nombre +"</td><td>" + direccion +"</td><td>" + email +"</td><td>" + telefono +"</td><td>" + nombreUsuario +"</td></tr>");
                    } );
                    
                    //datatables.net
                    //table = new DataTable('#tblUsuarios');
                    $('#tblUsuarios').DataTable(); 
                },
                timeout: 5000,
                error: function(error)
                {
                    console.log(error);
                }
              });
    
});