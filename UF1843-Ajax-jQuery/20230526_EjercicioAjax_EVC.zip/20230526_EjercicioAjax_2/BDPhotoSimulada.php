<?php
// obtener valoes enviados
$id=$_GET["id"];
// acceder BD i obtener datos
sleep(1.2);
// formatear datos
switch($id)
{
    case "1":
        $photo = "<img id='photo".$id."' title='Catalunya en Miniatura' src='./source/img/cat.jpg' height=300>";
        break;
    case "2":
        $photo = "<img id='photo".$id."' title='Mazinger Z Tarragoní' src='./source/img/mazinger_z.png' height=300>";
        break;
    case "3":
        $photo = "<img id='photo".$id."' title='Wok&Park a Roses' src='./source/img/woknpark.jpg' height=300>";
        break;
    case "4":
        $photo = "<img id='photo".$id."' title='Bosc de Can Ginebreda' src='./source/img/penisalbosc.jpg' height=300>";
        break;
    case "5":
        $photo = "<img id='photo".$id."' title='Grafitis de Penelles' src='./source/img/Penelles-1.jpg' height=300>";
        break;
    default:
        $photo = "";
            break;
}
// enviar datos
echo $photo;
?>


