
const boton = "<button id='botonPonerFavoritos' class='btn btn-success'>Afegir a Escollits</button>";
const botof = "<button id='botonQuitarFavoritos' class='btn btn-danger'>Treure d'Escollits</button>";
const numLoc =5;
var marker=[];
var map = null;

$(function()
{
    //Icono Rojo Vd és aquí
    var myIcon = L.icon(
    {
        iconUrl: './source/img/markerRojo.png',
        iconSize: [25, 41],
        iconAnchor: [12.5,41],
        popupAnchor: [0, -35],
        shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
        shadowSize: null,
        shadowAnchor: [12.5,41]
    });

    //Geolocalitzem la posició
    navigator.geolocation.getCurrentPosition(
    function(posicion)
    {            
    //Pintar mapa
        
        //Posicionar mapa
        map = L.map('mapa').setView([posicion.coords.latitude+1, posicion.coords.longitude], 7);
        
        //Añadir listener a los popups y centrarlos, en el mapa, al abrirlos
        map.on("popupopen",function(e)
        {
            //Centrar popUp en el mapa
            map.panTo([e.popup._latlng.lat+1,e.popup._latlng.lng]);
            
            //Añadir listener al thumbnail del popUp
            $(".thb").parent().click(function()
                                     
            {   //Buscar la foto segun el id del thumbnail ($(".thb").parent().prop("id").slice(-1))
                buscarFoto($(".thb").parent().prop("id").replace("thb",""));
                
                //Cerrar el popUp
                map.closePopup();
            });
        });
        
        //añadir el title (fondo del mapa)
        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', 
        {
            maxZoom:17,
            attribution: 'Llocs curiosos de Catalunya..|'
        }).addTo(map);

        //consultas a la BD para poner los markers
        for (let i=1;i<=numLoc;i++)
        {
            $.ajax(
            {
                async: true,
                type: "GET",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "BDsimulada.php",
                data: "id="+i,
                beforeSend: function()
                {
                    //poner spiner
                    let spiner =    "<div class='spinner-border text-primary text-center m-2'>"+
                                    "<span class='visually-hidden'>Loading...</span>"+
                                    "</div>";
                    $("#divResultado").html(spiner);
                },
                success: function(resultado)
                {   
                    //quitar spiner
                    $("#divResultado").html("");
                    
                    //Preparar datos
                    let data=[];
                    data = resultado.split(",");

                    //montar marker
                    marker[i] =  L.marker([data[0],data[1]]).bindTooltip(data[2]).bindPopup("<h5>"+data[2]+"</h5>"+data[3]).addTo(map);
                    
                    //Buscar cookie
                    if(cookieExists("photo"+i))
                    {
                        let texto = getCookie("photo"+i);
                        
                        //añadir al listado de favoritos
                        $("#divFavoritos ul").append("<li id='pphoto"+i+"' class='txtFoto list-group-item text-center p-0' title='Veure la foto' >" + texto +"</li");
                        
                        //añadir listener al elemento
                        $("#pphoto"+i).click(function(e)
                        {
                            //Abrimos popUp del marker
                            marker[i].openPopup();
                            
                            //Lo centramos en el mapa
                            map.panTo([marker[i].getLatLng().lat+1,marker[i].getLatLng().lng]);
                            
                            //buscamos la foto
                            buscarFoto(i);
                        });
                    }
                },
                timeout: 5000,
                error: function(error)
                {
                    //error del Ajax
                    $("#divResultado").html(error);
                }
            });
        }
        //poner marker 0
        marker[0] = L.marker([posicion.coords.latitude, posicion.coords.longitude],{icon: myIcon},{title:'Vostè és aquí'}).bindTooltip('Vostè és aquí',{offset:[12.5, -20.5],direction:"right"}).addTo(map);
    },
    function(error)
    {
        // error del geolocation.getCurrentPosition
            $("#divResultado").html("Error: " + error.code + " " + error.message); 
    });
});

function buscarFoto(index)
{
    $.ajax(
    {
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: "BDPhotoSimulada.php",
        data: "id="+index,
        beforeSend: function()
        {
            //poner spiner
            let spiner =    "<div class='spinner-grow text-success text-center m-5'>"+
                            "<span class='visually-hidden'>Loading...</span>"+
                            "</div>";
            $("#divResultado").html(spiner);
            $('#divBotones').html("");
        },
        success: function(resultado)
        {   
        //quitar spiner
        $("#divResultado").html("");

        //Datos recibidos desde la BD
        let data = resultado;

        //Ponems Foto en divResultado
        $("#divResultado").html(data);


        if(!cookieExists($("#divResultado img").prop("id"))) 
        {
            //Si no està la cookie ponemos boton para añadir a favoritos
            $('#divBotones').html(boton); 
            //listener botón poner en favoritos    
            $('#botonPonerFavoritos').click(ponerFavoritos);            
        }
        else
        {
            //Si està la cookie ponemos boton para quitar de favoritos
            $('#divBotones').html(botof);  
            //listener botón quitar de favoritos     
            $('#botonQuitarFavoritos').click(quitarFavoritos);
        }
        },
        timeout: 5000,
        error: function(error)
        {
            //error del Ajax
            $("#divResultado").html(error);
        }
    });
}

function ponerFavoritos()
{
    //cogemos el numero de imagen $("#divResultado img").prop("id").slice(-1)
    let i = ( $("#divResultado img").prop("id").replace("photo",""));
    
    //Ponemos la cookie setCookie(id de la imagen,titulo de la imagen,365)
    setCookie($("#divResultado img").prop("id"), $("#divResultado img").prop("title"), 365);
    
    //añadimos al listado de favoritos
    $("#divFavoritos ul").append("<li id='p"+$("#divResultado img").prop("id")+"' title='Veure la foto' class='txtFoto list-group-item text-center p-0'>" +$("#divResultado img").prop("title")+"</li");
    
    //listener para el elemento del listado
    $("#pphoto"+i).click(function()
    {
        //Abrimos popUp del marker
        marker[i].openPopup();
        //Lo centramos en el mapa
        map.panTo([marker[i].getLatLng().lat+1,marker[i].getLatLng().lng],{});
        //buscamos la foto
        buscarFoto(i);
    });
    
    //ponemos boton para quitar de favoritos
    $("#divBotones").html(botof); 
    
    //listener botón quitar en favoritos   
    $('#botonQuitarFavoritos').click(quitarFavoritos);
}

function quitarFavoritos()
{
    //Cerramos el popUp
    map.closePopup();
    
    //quitamos del listado de favoritos
    $("#p"+$("#divResultado img").prop("id")).remove();
    
    //quitamos la cookie
    deleteCookie($("#divResultado img").prop("id"));

    //ponemos boton para añadir a favoritos
    $("#divBotones").html(boton); 
    
    //listener botón poner en favoritos   
    $('#botonPonerFavoritos').click(ponerFavoritos);     
}



