<?php
// obtener valoes enviados
$id=$_GET["id"];
// acceder BD i obtener datos
sleep(2);
// formatear datos
switch($id)
{
    case "1":
        $loc = "41.35932713606717,1.9860516229019127,Catalunya en miniatura,<a id='thb".$id."'><img class='thb' title='Obrir la foto' src='./source/img/catalunya_miniatura_thumb.png' width=80% height=80%></a>";
        break;
    case "2":
        $loc = "41.38303276976599,1.3290814247249827,Mazinger a Tarragona,<a id='thb".$id."'><img class='thb' title='Obrir la foto'  src='./source/img/mazinguer_thumb.png' width=80% height=80%></a>";
        break;
    case "3":
        $loc = "42.26813800894782, 3.1609853129961283,Wok&Park Roses,<a id='thb".$id."'><img  class='thb' title='Obrir la foto'  src='./source/img/woknpark_thumb.png' width=80% height=80%></a>";
        break;
    case "4":
        $loc = "42.123336412147964,2.709281883031475,Bosc de Can Ginebreda,<a id='thb".$id."'><img class='thb' title='Obrir la foto'  src='./source/img/can_ginebreda_thumb.png' width=80% height=80%></a>";
        break;
    case "5":
        $loc = "41.75970420831613,0.9666839020264267,Poble de Penelles,<a id='thb".$id."'><img class='thb' title='Obrir la foto'  src='./source/img/Panelles_thumb.png' width=80% height=80%></a>";
        break;
    default:
        $loc = "";
            break;
}
// enviar datos
echo $loc;
?>