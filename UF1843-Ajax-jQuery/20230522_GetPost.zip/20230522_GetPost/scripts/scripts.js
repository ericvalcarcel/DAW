var urlBase = "http://localhost/UF1843/20230522_GetPost/";
$(function()
{
    //Cargar el header
    $.get("header.html",function(resp)
    {
        $("header").html(resp);
    });

    //Cargar el nav
    $.get("nav.html",function(resp)
    {
        $("nav").html(resp);
        
        //Actualizar la opción activa
        let urlActual="";
        if (location.href==urlBase)
        {
            urlActual = urlBase;
        }
        else
        {
            urlActual = location.href.replace(urlBase,""); 
        }
        $("nav ul li a[href='" + urlActual + "']").addClass("active");
        
    });

    //Cargar el footer
    let urlActual = location.href;
    urlActual = urlActual.replace(urlBase,"");
    switch (urlActual)
    {
        case "":
        //case "index.html":
            $("footer").load("footer1.html");
            break;

        case "empresa.html":
            $("footer").load("footer2.html");
            break;

        case "servicios.html":
            $("footer").load("footer2.html");
            break;
    }

    //...
});