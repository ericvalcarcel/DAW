$(function()
{
    //Cargar funcionalidad de cada botón o producto
    $("#btnAddTarea").click(function()
    {
        addTarea();
    });

    $("#btnRemoveAll").click(function()
    {
        localStorage.clear();
        mostrarTareas();
    });

    //Mostrar tareas
    mostrarTareas();

});

function addTarea()
{
    //Crear nuevo producto
    let tarea = 
    {
        name: $("#txtNombreTarea").val(),
        description: $("#txtTarea").val(),
        tiempo: $("#txtTiempoTarea").val()
    };

     //Deserializar el LocalStorage de JSON a Array
    let tareas = (localStorage["tareasItems"] != null) ? JSON.parse(localStorage["tareasItems"]) : [];
        
    //Añadimos el ítem seleccionado a la colección de items
    tareas.push(tarea);

    //Serializar y guardar en la localstorage
    localStorage["tareasItems"] = JSON.stringify(tareas);

    mostrarTareas();

}

function mostrarTareas()
{
    //Deserializar
    let tareas = (localStorage["tareasItems"] != null) ? JSON.parse(localStorage["tareasItems"]) : [];

    //Iterar
    $("#tbodyTareas").html("");
    let tiempoTotal = 0;
    let contador=0;
    tareas.forEach(function(tarea)
    {

        //Mostrar la tabla
        $("#tbodyTareas").append("<tr><td>" + tarea.name + "</td><td>" + tarea.description + "</td><td>" + tarea.tiempo+ "</td><td><a href='javascript:borrarTarea("+contador+");'>Borrar</a></td></tr>");

        tiempoTotal += parseFloat(tarea.tiempo.replace(",","."));

        contador++;
    });

    //Mostrar total de las tareas
    $("#tbodyTareas").append("<tr><td colspan='3' style='text-align:right;'>" + tiempoTotal + " h</td></tr>");

}

function borrarTarea(item)
{
    //Deserializar
    let tareas = (localStorage["tareasItems"] != null) ? JSON.parse(localStorage["tareasItems"]) : [];

    //Eliminar del array
    let nuevasTareas= [];
    for (let i=0; i<tareas.length; i++)
    {
        if (i!=item)
        {
            nuevasTareas.push(tareas[i]);
        }
    }

    //Serializar
    localStorage["tareasItems"] = JSON.stringify(nuevasTareas);

    //Mostrar
    mostrarTareas();
}