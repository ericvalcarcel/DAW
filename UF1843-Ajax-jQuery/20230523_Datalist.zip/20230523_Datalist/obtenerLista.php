<?php

//Obtener los valores de parámetros enviados
$cadena = $_GET["cad"];


//Acceder a BD y obtener los datos
//TO_DO
sleep(0.1);

//Formatear los datos 
$html="";
switch ($cadena)
{
    case "A":
        $html = "<option value='Fanta'>" .
                "<option value='Coca cola'>" .
                "<option value='Almendras'>" .
                "<option value='Helado'>" .
                "<option value='Pan de molde'>";
            break;

    case "B":
        $html = "<option value='Pan bimbo'>" .
                "<option value='Boquerones'>" .
                "<option value='Batido'>" .
                "<option value='Gominolas Jaribo'>";
                
        break;

    default:
        $html = "<option value='Pan bimbo'>" .
                "<option value='Boquerones'>" .
                "<option value='Batido'>" .
                "<option value='Gominolas Jaribo'>" .
                "<option value='Fanta'>" .
                "<option value='Coca cola'>" .
                "<option value='Almendras'>" .
                "<option value='Helado'>" .
                "<option value='Pan de molde'>";
        break;
}

//Enviar datos a javascript
echo $html;

?>