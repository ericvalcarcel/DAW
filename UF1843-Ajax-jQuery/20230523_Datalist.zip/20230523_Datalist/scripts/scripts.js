$(function()
{
    $("#txtProducto").keyup(function()
    {
        //AJAX para rellenar datalist
        //Capturar el valor de la caja
        let cadena = $("#txtProducto").val();
        if (cadena!="")
        {
            //Lanzar AJAX
            $.ajax({
                async: true,
                type: "GET",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "obtenerLista.php",
                data: "cad=" + cadena,
                //beforeSend: function() {},
                success: function(data)
                {
                    $("#datProducto").html(data);
                },
                timeout: 1000,
                error: function(error)
                {
                    console.log("Error de servidor: " + error);
                }
            });
        }
        else
        {
            //Limpiar el datalist
            $("#datProducto").html("");
        }
    });

});