function procesar()
{
    //Recoger la nota introducida por el usuario
    var txtNota = document.getElementById("txtNota");
    var nota = parseFloat(txtNota.value);

    //Calcular el mensaje a mostrar
    var mensaje="";
    if (nota>=5)
    {
        //Aprobar
        mensaje = "<p style='color: darkgreen;'>APROBADO :-)</p>";
    }
    else
    {
        //Suspender
        mensaje = "<p style='color: red;'>SUSPENDIDO :-(</p>";
    }

    //Obtener el objeto div donde se mostrará la nota
    var divNota = document.getElementById("divNota");

    //Mostrar la nota
    divNota.innerHTML = mensaje;

}

function mostrarNota()
{
    //Recoger la nota introducida por el usuario
    var txtNota = document.getElementById("txtNota");
    var nota = parseFloat(txtNota.value);

    //Calcular el mensaje a mostrar
    var mensaje="";
    if (nota>=9)
    {
        mensaje = "<p'>SOBRESALIENTE</p>";
    }
    else if (nota>=7)
    {
        mensaje = "<p'>NOTABLE</p>";
    }
    else if (nota>=6)
    {
        mensaje = "<p'>BIEN</p>";
    }
    else if (nota>=5)
    {
        mensaje = "<p'>SUFICIENTE</p>";
    }
    else
    {
        mensaje = "<p'>INSUFICIENTE</p>";
    }

    //Obtener el objeto div donde se mostrará la nota
    var divNota = document.getElementById("divNota");

    //Mostrar la nota
    divNota.innerHTML = mensaje;

}

function obtenerPeaje(tipoVehiculo) //Variable numérica
{
    var peaje = 0;
    switch (tipoVehiculo)
    {
        case 1:   //Motocicleta
            peaje = 1.5;
            break;

        case 2:   //Coche
            peaje = 5;
            break;

        case 3:   //Camión
            peaje = 8.75;
            break;

        case 4:   //Autobus
            peaje = 12,50;
            break;
          
        default:   //Cosa rara
            peaje = null;
            break;
    }

    
    var divNota = document.getElementById("divNota");
    if (peaje != null)
    {
        //Mostrar peaje
        divNota.innerHTML = "A pagar: " + peaje + " €";
    }
    else
    {
        alert("Cosa rara");
        divNota.innerHTML = "";
    }
}
