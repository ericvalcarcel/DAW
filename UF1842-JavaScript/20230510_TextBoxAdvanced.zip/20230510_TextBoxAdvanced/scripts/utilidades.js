/*Utilidades de fechas*/
function getFecha(fecha, tipo)
{
    //Formato 1: dd/mm/yyyy
    //Formato 2: dd/mes/yyyy
    //Formato 3: d de mescompleto de yyyy
    //Formato 4: diasemana, d de mescompleto de yyyy
    //Formato 5: dd/mescompleto/yyyy

    var resultado = "";
    
    switch(tipo)
    {
        case 1:
            resultado = fecha.getDate().toString().padStart(2,"0") + "/" +
                        (fecha.getMonth()+1).toString().padStart(2,"0") + "/" +
                        fecha.getFullYear();
            break;

        case 2:
            resultado = fecha.getDate().toString().padStart(2,"0") + "/" +
                        getMes(fecha.getMonth(),2) + "/" +
                        fecha.getFullYear();
            break;

        case 3:
            resultado = fecha.getDate() + " de " +
                        getMes(fecha.getMonth(),1) + " de " +
                        fecha.getFullYear();
            break;

        case 4:
            resultado = getDiaSemana(fecha.getDay(),1) + ", " + 
                        fecha.getDate () + " de " +
                        getMes(fecha.getMonth(),1) + " de " +
                        fecha.getFullYear();
            break;
    }
 
    return resultado;
}

function getMes(mes,tipo)       // 2, 1
{
    var meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
                    "Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
    var resultado = "";

    resultado = (tipo==1) ? meses[mes] : meses[mes].substring(0,3);

    return resultado;
}

function getDiaSemana(dia,tipo)
{
    //1 - Día completo
    //2 - Día con 3 letras
    //3 - Día con 1 letra  OJO Miércoles

    var dias = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
    var resultado = "";

    switch(tipo)
    {
        case 1:
            resultado = dias[dia];
            break;

        case 2:
            resultado = dias[dia].substring(0,3);
            break;

        case 3:
            resultado = (dia==2) ? "X" : dias[dia].substring(0,1);
            break;
    }

    return resultado;
}


/*Utilidades de Element*/

/*Utilidades de TextBox */
window.addEventListener("load", function()
{
    let elements = this.document.querySelectorAll(".txt-numerico");

    elements.forEach(function(item)
    {
        item.addEventListener("keypress",textNumerico);
    });
});

//Uso de la clase "txt-numerico" en inputs
function textNumerico(evt)
{
    //Identificar qué textbox es el responsable del evento
    let elemento = evt.target;

    //Identificar qué tecla es pulsada
    let tecla = evt.keyCode;
    //console.log(tecla);

    //Admitir o no la tecla pulsada
    let admitir = false;

    //Admitimos numeros
    if(tecla >= 48 && tecla <= 57)
    {
        //No haya un cero en posición cero si en posición 1 hay otro número
        if (elemento.value.substring(0,1)=="0" && elemento.value.length==1)
        {
            //Eliminar el cero en posición cero
            elemento.value="";
        }
        admitir = true;
    }
    else if (tecla==8)
    {
        //Backspace
        admitir = true;
    }
    else if (tecla==45)
    {
        //Admitimos el signo - solo al principio
        if (elemento.value.length==0)
        {
            admitir =true;
        }
    }
    else if (tecla==44)
    {
        //Admitimos la coma una sola vez
        if (elemento.value.indexOf(",")==-1)
        {
            admitir =true;
        }
    }
    else if (tecla==46)
    {
        //Admitimos el punto, pero lo convertimos en coma
        if (elemento.value.indexOf(",")==-1)
        {
            admitir =false;
            elemento.value +=",";
        }
    }

    if (!admitir)
    {
        //No admitir el caracter
        //Cancelar el evento producido
        evt.preventDefault();
        //console.log("cancelado: "+ tecla);
    }
}
