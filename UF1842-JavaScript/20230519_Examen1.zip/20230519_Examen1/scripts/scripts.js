window.addEventListener("load",cargar);

function cargar()
{

    let persona1 = new Persona("Javier Perez Diaz","38875679-S", false);

    persona1.mostrar();
   
    let banco1 = new Banco ("BBVA", 8734);

    let cuenta = new CuentaBancaria ("ES453765428976554", persona1, banco1, 0, true);

    cuenta.mostrar(); 
    cuenta.depositar(500);
    cuenta.depositar(150);
    cuenta.mostrar();
    cuenta.retirar(300);
    cuenta.retirar(400);
    cuenta.mostrar();

    cuenta.darBaja();
    cuenta.mostrar();


}