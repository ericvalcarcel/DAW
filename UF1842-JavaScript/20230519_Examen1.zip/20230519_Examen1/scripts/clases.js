class Banco
{
    nombre = "";
    codigo = 0;

    constructor(nombre,codigo)
    {
        this.nombre = nombre;
        this.codigo = codigo;
    }

    mostrar()
    {
        alert("Nombre del banco: " + this.nombre + "Código del banco: " + this.codigo);
    }
}

class Persona
{
    nombre = "";
    dni = "";
    tieneCuentaBanco = false;

    constructor(nombre,dni, tieneCuentaBanco)
    {
        this.nombre = nombre;
        this.dni = dni;
        this.tieneCuentaBanco = tieneCuentaBanco;
    }

    mostrar()
    {
        alert("Nombre: "+ this.nombre + "Dni:" + this.dni + "¿tiene cuenta en el banco? " + this.tieneCuentaBanco)

    }
}

class CuentaBancaria
{
    iban = "";
    titular = null;
    banco = null;
    saldo = 0;
    estado = false;

    constructor(iban,titular,banco, saldo, estado)
    {
        this.iban = iban;
        this.titular = titular;
        this.titular.tieneCuentaBanco = true;  //Ponemos que la persona tiene cuenta de banco
        
        this.banco = banco;
        this.saldo = saldo;
        this.estado = estado;
    }

    depositar(cantidad)
    {
        if(cantidad > 0 && this.estado)
        {
            this.saldo +=cantidad;
            alert("Se han ingresado: " + cantidad + "€");
        }

    }

    retirar(cantidad)
    {
        if (cantidad <= this.saldo && this.estado)
        {
            this.saldo -= cantidad;
            alert("Se han retirado" + cantidad + "€");
        }
        else
        {
            alert("No se puede retirar la cantidad requerida");
        }

    }

    darBaja()
    {
        if (!this.estado)
        {
            alert("La cuenta ya está dada de baja")
            return;
        }

        if (this.saldo>0)
        {
            this.retirar(this.saldo);
        }
        else if (this.saldo<0)
        {
            this.depositar(this.saldo);
        }
        this.estado=false;
    }

    mostrar()
    {
      alert("IBAN:" + this.iban + "\n" + "Titular: " + this.titular.nombre +"\n"+ "Entidad: " +  this.banco.nombre + "\n" + "Saldo: "+ this.saldo + "€" + "\n" + "Estado de la cuenta: " + ((this.estado)? "Activa" : "Inactiva"));
    }
}