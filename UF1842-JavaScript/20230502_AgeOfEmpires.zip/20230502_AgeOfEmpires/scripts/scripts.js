//Zona global
var recolector;

function nacerRecolector()
{
    recolector =
    {
        //Atributos
        nombre: "Aldeano",
        energia: 100,
        capacidad: 50,
        estado: true,

        //Metodos
        caminar: function()
        {
            var accion = this.nombre + " está caminando";
            this.energia -=10;
            return accion;
        },
        comer: function(objeto)
        {
            if (objeto.estado)
            {
                this.energia +=objeto.energia;
            }
        },
        mostrar: function()
        {
            var datos="<p>" + this.nombre + "</p>" +
                "<p>Energía: " + this.energia + "</p>" +
                "<p>Capacidad: " + this.capacidad + "</p>" +
                "<p>Estado: " + ((this.estado) ? "Vivo": "Muerto") + "</p>";
            return datos;
        }
    }

    //Mensaje de que ha nacido el recolector
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML = recolector.mostrar();

}

function comer()
{
    var vegetal =
    {
        //Atributos
        tipo: "Fruta",
        nombre: "Manzana",
        energia: 50,
        estado: true,

        //Comportamiento
    }

    recolector.comer(vegetal);
    vegetal.estado=false;   //Comido
    //vegetal.energia=0;
    recolector.comer(vegetal);

    //Mensaje del estado actual del recolector
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML += "<hr/>" + recolector.mostrar();

    //recolector.comer(recolector);
    //recolector.estado=false;   //Comido
}

function caminar()
{
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML += "<hr/>" + recolector.caminar();

    divResultado.innerHTML += "<hr/>" + recolector.caminar();

    divResultado.innerHTML += "<hr/>" + recolector.mostrar();

}