function hacer()
{
    //Crear el objeto de la caja de texto
    var txtFrase = document.getElementById("txtFrase"); //objeto input

    //Leer la frase de la caja de texto
    var frase = txtFrase.value;

    //Crear el objeto del h1
    var titulo = document.getElementById("titulo"); //Objeto h1

    //Leer el contenido del h1
    var texto = titulo.innerHTML;

    //Crear el objeto donde se debe mostrar el resultado
    var divResultado = document.getElementById("divResultado");  //Objeto div

    //Escribir la frase
    divResultado.innerHTML = frase + " ("+ frase.length+")";

    //Escribir el contenido del h1 todo en mayúsculas
    titulo.innerHTML = texto.toUpperCase();
}

function convertir(modo)
{
    //Crear el objeto de la caja de texto
    var txtFrase = document.getElementById("txtFrase"); //objeto input

    //Leer la frase de la caja de texto
    var frase = txtFrase.value;

     //Crear el objeto donde se debe mostrar el resultado
     var divResultado = document.getElementById("divResultado");  //Objeto div
 
    //Escribir la frase
    //modo 1=minusculas
    //modo 2=mayusculas
    //modo 3=subrayado
    switch (modo)
    {
        case 1:
            divResultado.innerHTML = frase.toLowerCase();
            break;
        
        case 2:
            divResultado.innerHTML = frase.toUpperCase();
            break;

        case 3:
            divResultado.innerHTML = "<span style='text-decoration:underline;'>" + frase + "</span>";
            break;

        case 4:
            divResultado.innerHTML = "<span style='text-decoration:underline;'>" + frase.toUpperCase() + "</span>";
            break;

        case 5:
                divResultado.innerHTML = "<span style='text-decoration:underline;'>" + frase.toUpperCase().replace("O","X") + "</span>";
                break;


    }
 
}