function testAnimales()
{
    var p1 = new Persona("Pedro Picapiedra",53,"12345678","en-US");
    p1.show();

    p1.respirar();
    p1.comer();
    p1.hablar();
    p1.morir();

    p1.show();

    var perro1 = new Perro("Duna",3,"98-2345","Galgo");
    perro1.show();

    perro1.respirar();
    perro1.comer();
    perro1.ladrar();
    //p1.morir();

    perro1.show();


    if (p1 instanceof Persona)
    {
        alert("p1 es una Persona");
    }

    if (p1 instanceof Animal)
    {
        alert("p1 es una Animal");
    }

    if (!(p1 instanceof Perro))
    {
        alert("p1 no es un Perro");
    }

    var listaAnimales = [p1, perro1];
    for(var i=0;i<listaAnimales.length;i++)
    {
        listaAnimales[i].respirar();
        if (listaAnimales[i] instanceof Persona)
        {
            listaAnimales[i].hablar();
        }
    }




}