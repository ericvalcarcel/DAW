class Animal
{
    //Atributos
    nombre="";
    edad=0;
    estado=true;

    //Constructor
    constructor(nombre,edad)
    {
        this.nombre=nombre;
        this.edad=edad;
    }

    //Métodos
    respirar()
    {
        alert(this.nombre + " está respirando");
    }

    comer()
    {
        alert(this.nombre + " está comiendo");
    }
    
    morir()
    {
        this.estado=false;
        alert(this.nombre + " ha muerto");
    }
    
    show()
    {
        alert("POR ANIMAL:\r\n" +
                "Nombre: " + this.nombre + "\r\n" + 
                "Edad: " + this.edad + "\r\n" + 
                "Estado: " + ((this.estado) ? "Vivo": "Muerto"));
    }
}

class Persona extends Animal
{
    //Atributos
    dni="";
    idioma="";

    //Constructor
    constructor(nombre,edad, dni, idioma)
    {
        super(nombre,edad);
        this.dni=dni;
        this.idioma=idioma;
    }

    //Métodos
    hablar()
    {
        alert(this.nombre + " está hablando");
    }
    
    show()
    {
        super.show();

        alert("POR PERSONA:\r\n" +
            "DNI: " + this.dni + "\r\n" + 
            "Idioma: " + this.idioma); 
    }

}

class Perro extends Animal
{
    //Atributos
    chip="";
    raza="";

    //Constructor
    constructor(nombre,edad, chip, raza)
    {
        super(nombre,edad);
        this.chip=chip;
        this.raza=raza;
    }

    //Métodos
    ladrar()
    {
        alert(this.nombre + " está ladrando");
    }

    show()
    {
        super.show();

        alert("POR PERRO:\r\n" +
            "Chip: " + this.chip + "\r\n" + 
            "Raza: " + this.raza); 
    }
}