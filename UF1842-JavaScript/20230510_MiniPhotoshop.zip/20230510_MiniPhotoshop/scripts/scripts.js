//Global
var x1=0;
var y1=0;
var modoLineaRecta=false;
var modoLineaContinua=false;

window.addEventListener("load", cargarEventos);

function cargarEventos()
{
    let canvas = document.getElementById("canvas");
    canvas.addEventListener("mousedown",getDatos);
    canvas.addEventListener("mousemove",pintarLineaContinua);
    canvas.addEventListener("mouseup", function()
    {
        modoLineaContinua = false;
    });

    let cmbFormas = document.getElementById("cmbFormas");
    cmbFormas.addEventListener("change",function()
    {
        modoLineaRecta = false;
        modoLineaContinua = false;
    });
}

function getDatos(evt)
{
    let divResultado = document.getElementById("divResultado");

    divResultado.innerHTML +="Punto: "+evt.clientX +","+evt.clientY + "<br/>";
    divResultado.innerHTML +="Ctrl: "+evt.ctrlKey + "<br/>";
    divResultado.innerHTML +="Shift: "+evt.shiftKey + "<br/>";
    divResultado.innerHTML +="Alt: "+evt.altKey + "<br/>";
    divResultado.innerHTML +="Meta: "+evt.metaKey + "<br/>";

    //Crear un contexto para pintar
    let canvas = document.getElementById("canvas");
    let ctx = canvas.getContext("2d");

    if (evt.altKey)
    {
        //Borrar todo
        ctx.clearRect(0, 0, canvas.width,canvas.height);
    }
    else
    {
        //Dibujar
        //Mirar el color seleccionado
        let cmbColores = document.getElementById("cmbColores");
        let color = cmbColores.value;
        ctx.fillStyle = color;
        ctx.strokeStyle = color;

        // Mirar la Forma seleccionada
        let cmbFormas = document.getElementById("cmbFormas");
        let forma = cmbFormas.value;

        switch (forma)
        {
            case "cuadrado":
                let txtLado = document.getElementById("txtLado");
                let lado = parseInt(txtLado.value);
                ctx.fillRect(evt.clientX, evt.clientY, lado,lado);
                break;

            case "circulo":
                let txtRadio = document.getElementById("txtRadio");
                let radio = parseInt(txtRadio.value);
                ctx.beginPath();
                ctx.arc(evt.clientX, evt.clientY, radio, 0, Math.PI * 2, false);
                ctx.fill();
                break;

            case "linea1":
                let x2= evt.clientX;
                let y2=evt.clientY;
                if (modoLineaRecta)
                {
                    ctx.beginPath();
                    ctx.moveTo(x1, y1);
                    ctx.lineTo(x2, y2);
                    ctx.stroke();
                }
                else
                {
                    modoLineaRecta = true;
                }

                x1 = x2;
                y1 = y2;
                break;

            case "linea2":
                modoLineaContinua = true;
                x1= evt.clientX;
                y1= evt.clientY;
                break;
    
        }
    }
}

function pintarLineaContinua(evt)
{
    if (modoLineaContinua)
    {
        //Crear un contexto para pintar
        let canvas = document.getElementById("canvas");
        let ctx = canvas.getContext("2d");

        let cmbColores = document.getElementById("cmbColores");
        let color = cmbColores.value;
        ctx.fillStyle = color;
        ctx.strokeStyle = color;

        let x2= evt.clientX;
        let y2=evt.clientY;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        x1 = x2;
        y1 = y2;
    }
}