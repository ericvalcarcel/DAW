//Zona global
window.addEventListener("load", pintar); //Añade ebento onload a la página

var btnActivar = document.getElementById("btnActivar");
btnActivar.addEventListener("click",activar);

function pintar()
{
    //Pintar el canvas
    
    //Preparar el pincel-contexto
    var canEjemplo = document.getElementById("canEjemplo");
    var ctx = canEjemplo.getContext("2d");

    //Dibujando
    /*
    ctx.fillRect(10, 10, 100, 75);
    ctx.strokeRect(120, 10, 100, 75);
    ctx.clearRect(20, 20, 80, 55);
    */

    //Pintar un tablero de damas o ajedrez
    for (var i=0; i<8; i++) //Pinta las 8 filas
    {
        for (var j=0; j<8; j++) //Pinta las 8 celdas de cada fila
        {
            if (i % 2 == 0)
            {
                //Fila par
                //Se pintan las celdas pares
                if (j % 2 == 0) ctx.fillRect(80 * j, 80 * i, 80, 80);
            }
            else
            {
                //Fila impar
                //Se pintas las celdas impares
                if (j % 2 != 0) ctx.fillRect(80 * j, 80 * i, 80, 80);
            }
        }
    }

    //colores
    ctx.fillStyle = "#aaaaaa";
    ctx.fillRect(10, 10, 60, 60);
    ctx.strokeStyle = "#990000";
    ctx.strokeRect(90, 10, 60, 60);

    ctx.globalAlpha = 0.5;
    ctx.fillStyle = "#ff0000";
    ctx.fillRect(200, 10, 60, 60);

    //Gradientes
    var gradiente = ctx.createLinearGradient(100, 100, 200, 200);
    gradiente.addColorStop(0.5, "#00AAFF");
    gradiente.addColorStop(1, "#000000");
    ctx.fillStyle = gradiente;
    ctx.fillRect(100, 100, 200, 200);

    //Trazado
    ctx.clearRect(400,400,240,240);
    ctx.beginPath();
    ctx.moveTo(450, 450);
    ctx.lineTo(550, 480);
    ctx.lineTo(500, 500);
    ctx.fill();

    //Cara
    ctx.beginPath();
    ctx.arc(200, 150, 50, 0, Math.PI * 2, false);
    ctx.stroke();
    ctx.lineWidth = 10;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(230, 150);
    ctx.arc(200, 150, 30, 0, Math.PI, false);
    ctx.stroke();
    ctx.lineWidth = 5;
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(195, 135);
    ctx.lineTo(215, 155);
    ctx.lineTo(195, 155);
    ctx.stroke();
    
    //texto
    ctx.clearRect(0,0,640,200);
    ctx.font = "bold 40px verdana, sans-serif";
    ctx.textAlign = "start";
    ctx.fillStyle = "#ff0000";
    ctx.fillText("Mi Mensaje", 0, 45);
    ctx.strokeStyle = "#00ff00";
    ctx.lineWidth = 1;
    ctx.strokeText("Mi Mensaje", 0, 90);

    var tamano = ctx.measureText("Mi Mensaje");
    ctx.strokeStyle = "#0000ff";
    ctx.strokeText("Mi Mensaje", 640-tamano.width, 135);


}

function activar()
{
      //Preparar el pincel-contexto
    var canPelota = document.getElementById("canPelota");
    var ctx = canPelota.getContext("2d");  

    //Pelota
    moverPelota(ctx);

}

var posicionX = 20;
var incremento = 1;
function moverPelota(ctx)
{
    //Borrar el lienzo

    //Poner el escenario
    ctx.fillStyle = "#00ff00";
    ctx.fillRect(0,0,640,200);

    //POner los decorados

    //Pintar los enemigos

    //Pintar las balas de todos

    //Pintar explosiones

    //Pintar la pelota (heroe)
    ctx.beginPath();
    ctx.fillStyle = "#000000";
    ctx.arc(posicionX, 100, 20, 0, Math.PI * 2, false);
    ctx.fill();

    //Pintar el score

    //Animación
    //Mover la posición
    posicionX += incremento;

    //Volver a pintar
    if (posicionX>=620 || posicionX<=20)
    {
        incremento = -incremento;
    } 
    setTimeout(moverPelota, 25, ctx);
    //moverPelota(ctx);
}