function resolverCaso1()
{
    //Buscar en la colección, cuantas veces está el número indicado

    //Crear el objeto del input donde está el array
    var txtArray = document.getElementById("txtArray");

    //Leer el valor de la caja
    var texto = txtArray.value;

    //Convertir la cadena de la caja en un array
    var lista = texto.split(",");

    //Crear el objeto del input donde está el número buscado
    var txtCaso1 = document.getElementById("txtCaso1");

    //Leer el numero buscado
    var numero = txtCaso1.value;

    //Buscar el número de ocurrencias de lo buscado en la lista
    var ocurrencias = 0;
    for (var i=0 ; i < lista.length ; i++)   
    {
        if (numero == lista[i])
        {
            ocurrencias++;
        }
    }

    //Mostrar el resultado en la capa correspondiente
    var divCaso1 = document.getElementById("divCaso1");
    divCaso1.style.border="1px solid red";
    divCaso1.style.padding="10px";

    var veces = (ocurrencias==1) ? "vez" : "veces"; //if ternario
    divCaso1.innerHTML = "<b>Ocurrencias = </b>" + ocurrencias + " " + veces;

}

function resolverCaso2()
{
    //Buscar en la colección, cuantas veces está el número indicado

    //Crear el objeto del input donde está el array
    var txtArray = document.getElementById("txtArray");

    //Leer el valor de la caja
    var texto = txtArray.value;

    //Convertir la cadena de la caja en un array
    var lista = texto.split(",");

    //Crear el objeto del input donde está el número buscado
    var txtCaso2 = document.getElementById("txtCaso2");

    //Leer el numero buscado
    var numero = txtCaso2.value;

    //Buscar si el número existe en la colección
    var existe = false;
    for (var i=0 ; i < lista.length ; i++)
    {
        if (lista[i] == numero)
        {
            existe = true;
            break;
        }
    }
 
    //Mostrar el resultado en la capa correspondiente
    var divCaso2 = document.getElementById("divCaso2");
    divCaso2.style.border="1px solid red";
    divCaso2.style.padding="10px";

    divCaso2.innerHTML = (existe) ? "Existe el elemento" : "No existe el  elemento";

}

function resolverCaso3()
{
    //Pintar el contenedor del caso 3 de cuadritos de 3x3 de colores aleatorios

    //Crear el objeto divCaso3
    var divCaso3 = document.getElementById("divCaso3");

    //Crear 1000 cuadrados de colores aleatorios
    /*
    for (var i=0; i < 2000; i++)
    {
        //Color aleatorio
        var rojo = Math.floor(Math.random()* 256);
        var verde = Math.floor(Math.random()* 256);
        var azul = Math.floor(Math.random()* 256);

        var cuadro = "<div style='float:left;width:10px; height:10px; background-color: rgb("+rojo+","+verde+","+azul+");'></div>";

        //Meter el cuadrado dentro del divCaso3
        divCaso3.innerHTML += cuadro;

    }*/
    
    var i=0;
    while ( i < 2000)
    {
        //Color aleatorio
        var rojo = Math.floor(Math.random()* 256);
        var verde = Math.floor(Math.random()* 256);
        var azul = Math.floor(Math.random()* 256);

        var cuadro = "<div style='float:left;width:10px; height:10px; background-color: rgb("+rojo+","+verde+","+azul+");'></div>";

        //Meter el cuadrado dentro del divCaso3
        divCaso3.innerHTML += cuadro;

        i++;
    }    


}

function resolverCaso4()
{
    //Contar cuantos 6 salen al tirar un dado 1000 veces

    //Crear el objeto divCaso4
    var divCaso4 = document.getElementById("divCaso4");

    var contador=0;
    for (var i=0; i < 1000; i++)
    {
        //Dado
        var dado = Math.floor(Math.random()* 6 + 1);
        if (dado==6)
        {
            contador++;
        }
    }

    divCaso4.innerHTML ="Veces: "+contador + " veces<br/>" +
                        "Porcentaje: " + (contador/10) + "%";

    divCaso4.innerHTML +="<div class='progress mb-3'>" +
                "<div class='progress-bar bg-warning' style='width:"+(contador/10)+"%'>" +
                (contador/10) + "%" +
                "</div>" +
                "</div>";


}