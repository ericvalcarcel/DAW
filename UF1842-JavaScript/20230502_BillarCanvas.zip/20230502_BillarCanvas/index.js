//Obtener canvas
const c = document.getElementById("c");
var ctx = c.getContext("2d");

//Dimensiones canvas
c.width = 475;
c.height = 260;

//cualidades y posicion de la bola
var x = 100;
var y = 100;
var WIDTH = 25;
var HEIGHT = 20;
var dx = 2;
var dy = -2;

//Carga de las imágenes
const mesa = new Image();
mesa.src = "img/MesaPoll.jpg";
var bola = new Image();
bola.src = "img/Bola.png";

mesa.onload = function() 
{
    setInterval(() => {
    
        //Dibuja la mesa
        ctx.drawImage(mesa, -30, -30);
    
        //Dibuja la bola
        ctx.drawImage(bola, x, y, WIDTH, HEIGHT);
    
        //Inicio de trayectoria de la bola
        x += dx;
        y += dy;
        
        //colision down - top
        if(y + HEIGHT >= 235 ||
        y - HEIGHT <= 8 )
        {
            dy = -dy
        }

        //colision right - left
        if(x + WIDTH >= 455 || 
        x - WIDTH <= 0)
        {
            dx = -dx
        }
    },25);
}






        




