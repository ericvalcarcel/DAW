class Socio 
{
    //Atributos
    nombre = "";
    email = "";
    telefono = "";
    numPrestamos = 0;
    estado = true;
    
    //Constructor
    constructor(nombre, email, telefono) 
    {
        //Atributos
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    };

    //Métodos-comportamientos
    prestar = function (libro) 
    {
        if (this.numPrestamos >= 5 || !libro.estado || !this.estado) 
        {
            //Mensaje de no prestar
            alert("No se puede prestar el libro " + libro.titulo);
        }
        else 
        {
            //Incrementar número de prestamos
            this.numPrestamos++;

            //Poner libro a false
            libro.estado = false;

            //Mostrar mensaje del libro prestado
            alert("Se prestó el libro " + libro.titulo);
            libro.mostrar();
        }
    };

    devolver = function (libro) 
    {
        //Poner libro a true
        libro.estado = true;

        //Restar del numero de prestamos
        this.numPrestamos--;

        //Mostrar la ficha del libro
        alert("Se devolvió el libro " + libro.titulo);
    };

    darBaja = function () 
    {
        //Dar de baja
        this.estado = false;

        //Mostrar mensaje de baja
        alert("Se dio de baja el socio " + this.nombre + "\r\n" +
            "Número de préstamos activos: " + this.numPrestamos);

    };

    mostrar = function () 
    {
        //Mostrar el contenido del objeto
        alert("Nombre: " + this.nombre + "\r\n" +
            "Email: " + this.email + "\r\n" +
            "Teléfono: " + this.telefono + "\r\n" +
            "Numero de préstamos: " + this.numPrestamos + "\r\n" +
            "Estado: " + ((this.estado) ? "Activo" : "Dado de baja"));
    };
}

class Libro 
{
    //Atributos
    titulo = "";
    isbn = "";
    estado = true;

    //Contructor
    constructor(titulo, isbn) 
    {
        this.titulo = titulo;
        this.isbn = isbn;
    };

    //Metodos
    mostrar = function () 
    {
        //Mostrar el contenido del objeto
        alert("Titulo: " + this.titulo + "\r\n" +
            "ISBN: " + this.isbn + "\r\n" +
            "Estado: " + ((this.estado) ? "Disponible" : "Prestado"));
    };
}