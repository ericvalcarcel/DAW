function test()
{
    //Libros comprados para la biblioteca
    var elQuijote = new Libro("El Quijote","12345678");
    var otelo = new Libro("Otelo","98765432");
    var rebelion = new Libro("Rebelión en la granja","12121212");

    //Crear socios de la biblioteca
    var socio1 = new Socio("Pedro Picapiedra","ppica@test.com","555123456");
    var socio2 = new Socio("Pablo Mármol","pmarmol@test.com","5559876543");

    //Prestar libro
    socio1.prestar(elQuijote);
    socio1.mostrar();

    //Devuelve el libro
    socio1.devolver(elQuijote);
    elQuijote.mostrar();
    socio1.mostrar();

    //Inconsistencia por defecto de diseño
    //socio1.devolver(otelo);
    //socio1.mostrar();

    //Dar de baja al socio
    socio1.darBaja();

    //INtesta prestar otelo
    socio1.prestar(otelo);


}