var btnOrdenar = document.getElementById("btnOrdenar");
btnOrdenar.addEventListener("click",ordenacion);

function ordenacion()
{
    //obtener valores
    var txtArray= document.getElementById("txtArray").value;
    //ordenar
    var resultado = ordenar(txtArray);
    //mostrar valores
    var divResultado=document.getElementById("divResultado");
    divResultado.innerHTML+=resultado+"</br>";  
}

function ordenar(txtArray)
{
    var array= txtArray.split(",");
    
    var resultado="["
    
    for (var i=0;i<array.length;i++)
    {
        for(var j=i+1;j<array.length;j++)
            {
                if(parseFloat(array[i])>parseFloat(array[j]))
                {
                    var temp=array[j];
                    array[j]=array[i];
                    array[i]=temp; 
                }
            }
        resultado +=(i<array.length-1)?array[i]+",": array[i]+"]" ;
    }
    return(resultado);
}