function concatenar()
{
    //Leer la frase 1
    var txtFrase1 = document.getElementById("txtFrase1");
    var frase1 = txtFrase1.value;

    //Leer la frase 2
    var txtFrase2 = document.getElementById("txtFrase2");
    var frase2 = txtFrase2.value;

    //Concatenar
    var frase = frase1 + " " + frase2;

    //Mostrar
    alert(frase);

    //Borrar el contenido de las cajas
    txtFrase1.value = "";
    txtFrase2.value = "";
    
    txtFrase1.style.backgroundColor = "yellow";
    
    var colorFondo = txtFrase1.style.backgroundColor;
}

function concatenarDiv()
{
    //Leer la frase 1
    var txtFrase1 = document.getElementById("txtFrase1");
    var frase1 = txtFrase1.value;

    //Leer la frase 2
    var txtFrase2 = document.getElementById("txtFrase2");
    var frase2 = txtFrase2.value;

    //Concatenar
    var frase = frase1 + " " + frase2;

    //Mostrar en el div lateral
    var divLateral = document.getElementById("divLateral");

    //Preparo un alert danger
    var texto ="<div class='alert alert-danger' onmouseover='borrarAlert();'>" + frase + "</div>";

    divLateral.innerHTML = texto;
    

    //Borrar el contenido de las cajas
    txtFrase1.value = "";
    txtFrase2.value = "";
    //txtFrase1.style.backgroundColor="yellow";
}

function borrarAlert()
{
    //Leer el div
    var divLateral = document.getElementById("divLateral");

    //Borrar el contenido del div
    divLateral.innerHTML = "";
}

function sumar()
{
    //Leer num1
    var txtNum1 = document.getElementById("txtNum1");
    var num1= parseFloat(txtNum1.value);

    //Leer num2
    var txtNum2 = document.getElementById("txtNum2");
    var num2= parseFloat(txtNum2.value);

    //Sumar
    var suma = num1 + num2;

    //Mostrar en el div
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML = suma;

    //Borrar las cajas para la próxima operación
    txtNum1.value="";
    txtNum2.value="";

}

function limpiar()
{
    //Borrar num1
    var txtNum1 = document.getElementById("txtNum1");
    txtNum1.value="";
 
    //Borrar num2
    var txtNum2 = document.getElementById("txtNum2");
    txtNum2.value="";

    //Borrar resultado
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML = "0";

}