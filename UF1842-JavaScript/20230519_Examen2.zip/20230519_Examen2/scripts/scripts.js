$(function()
{
    $("#boton1").click(function() 
    {
        //Añadir el color que se indique en el #txtInput
        var color = $("#txtInput").val();
        var ancho = $("#txtInput2").val();
        
        $("#divResultado").append("<div class='col-"+ancho+"' style='height:50px;background-color:"+color+";'></div>");

        $("#txtInput").val("");
        $("#txtInput2").val("");

        $("#divResultado div").dblclick(function()
        {
            $(this).remove();
        });
    });

    $("#boton2").click(function() 
    {
        //Mostrar en un alert el numero de elementos que se van a eliminar
        alert(($("#divResultado > div").length));

        //Borrar todos los bloques del #divResultado
        $("#divResultado").empty();

    });

    $("#boton3").click(function() 
    {
        //Añadir 3 bloques de ancho 4 al row el primero sera de color rojo el segundo verde y el tercero azul
        $("#divResultado").append("<div class='col-4'style='background-color:red;'>ROJO</div>");
        $("#divResultado").append("<div class='col-4'style='background-color:green;'>VERDE</div>");
        $("#divResultado").append("<div class='col-4'style='background-color:blue;'>AZUL</div>");



    });

    //Eliminar unicamente un div con doble click dentro de #divResultado
    $("#divResultado div").dblclick(function()
    {
        $(this).remove();
    });
});