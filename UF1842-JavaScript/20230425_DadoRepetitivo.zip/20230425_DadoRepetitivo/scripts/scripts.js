var total=0;
var numTiradas=0;

function tirarDado()
{
    //Crear el aleatorio
    var aleatorio = Math.floor(Math.random() * 6 + 1);

    //Incrementar total
    total += aleatorio;

    //Incrementar el numero de tiradas
    numTiradas++;

    //Mostrar el total
    var acum = document.getElementById("acum");
    acum.innerHTML = total;

    //Mostrar el numero de tiradas
    var tiradas = document.getElementById("tiradas");
    tiradas.innerHTML = numTiradas;

    //Mostrar el promedio
    var promedio = document.getElementById("promedio");
    promedio.innerHTML = total/numTiradas;
    
    //Evaluar si hemos llegado al final
    if (total >=50)
    {
        var msgFinal = document.getElementById("msgFinal");
        msgFinal.innerHTML = "FINAL";

        var btnDado = document.getElementById("btnDado");
        btnDado.style.display="none";
    }
}
