
window.addEventListener("load",cargar);

function cargar()
{
    //Materias
    let matematicas = new Materia ("Matematicas",5);
    let fisica = new Materia ("Física",6);
    let filosofia = new Materia ("Filosofia",5);

    //profesores
    let profesor1 = new Profesor ("Pedro Carvajal",35,1,true,"", matematicas);
    let profesor2 = new Profesor ("Sebastian Ruiz",57,1,true,"", fisica);
    let profesor3 = new Profesor ("Carmen González",45,2,true,"", filosofia);

    //Mostrar datos de profesor 1
    profesor1.show();

    //alumnos
    let alumno1 = new Alumno("Juanma",18,1,true,"");
    let alumno2 = new Alumno("David",19,1,true,"");
    let alumno3 = new Alumno("Andres",21,1,true,"");
    let alumno4 = new Alumno("Lucia",22,2,true,"");
    let alumno5 = new Alumno("Paula",18,2,true,"");
    let alumno6 = new Alumno("Dolores",24,2,true,"");

    //Alumnos que pertenecen a una clase
    let alumnos = [alumno1,alumno2,alumno3,alumno4,alumno5,alumno6];

    //aula
    let aula1 = new Aula(1, 10, matematicas);

    //clase
    let clase1 = new Clase(matematicas, aula1, profesor1, alumnos);

    //Alumnos que asisten o no a la clase
    alumno1.asistir(clase1, "Novillos");
    alumno2.asistir(clase1, "");
    alumno3.asistir(clase1, "");
    alumno4.asistir(clase1, "");
    alumno5.asistir(clase1, "");
    alumno6.asistir(clase1, "");
 
    //Miramos si se puede dar clase
    let posible = clase1.verificarClase();

    if (posible)
    {
        //Empieza a impartir la clase
        profesor1.impartir(clase1);

        //Dar notas
        profesor1.calificar(alumno1, 6);
        profesor1.calificar(alumno2, 4);
        profesor1.calificar(alumno3, 3);
        profesor1.calificar(alumno4, 9);
        profesor1.calificar(alumno5, 8);
        profesor1.calificar(alumno6, 2);

        //Mostrar listados
        clase1.showList();

    }
    else
    {
        alert("No se puede dar clase");
    }
}

