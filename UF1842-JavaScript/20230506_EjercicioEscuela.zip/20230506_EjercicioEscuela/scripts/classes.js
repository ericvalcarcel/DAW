//Global
var divResultado = document.getElementById("divResultado");

class Persona
{
    //atributos
    nombre = "";
    edad = 0;
    sexo = 0; 
    estado = true;
    motivoAusencia = "";

    //constructores
    constructor(nombre,edad,sexo,estado,motivoAusencia)
    {
        this.nombre = nombre;
        this.edad = (edad>=100) ? 0 : edad;
        this.sexo = sexo;
        this.estado = estado;
        this.motivoAusencia = motivoAusencia;
    }

    //metodos
    show() 
    { 
        divResultado.innerHTML +="PROFESOR<br/>"+
            "Nombre: "+ this.nombre + "<br/>" +
            "Edad: "+ this.edad + "<br/>" +
            "Sexo: "+ this.sexo + "<br/>" +
            "Estado: "+ this.estado + "<br/>" +
            "Motivo ausencia: "+ this.motivoAusencia +"<br/>";

    }
    
    asistir(clase, motivoAusencia)
    {
        if (motivoAusencia!="")
        {
            this.estado = false;
            this.motivoAusencia = motivoAusencia;
        }
        else
        {
            this.estado = true;
        }

    }  
   
}

class Profesor extends Persona
{
    //atributos
    materia = null;
    
    //constructores
    constructor(nombre,edad,sexo,estado,motivoAusencia, materia)
    {
        super (nombre,edad,sexo,estado,motivoAusencia)
        this.materia = materia;
    }

    //metodos
    show()
    {
        super.show();
        divResultado.innerHTML += "Materia: " + this.materia.nombre +"<br/>";
    }
    
    impartir(clase)
    {
        divResultado.innerHTML += "Se empieza a impartir la clase: " + clase.materia.nombre +"<br/>";
    }
    
    calificar(alumno, nota)
    {
        alumno.calificacion = nota;
        divResultado.innerHTML += "Se ha calificado a  " + alumno.nombre +" con una calificación de " + nota + "<br/>";
    }


}

class Alumno extends Persona
{
    //atributos
    calificacion = 0;
 
    //constructores
    constructor(nombre,edad,sexo,estado,motivoAusencia)
    {
        super(nombre,edad,sexo,estado,motivoAusencia)
    }
    //metodos
    show()
    {
        super.show();
        divResultado.innerHTML += "Calificación: " + this.calificacion +"<br/>";
    }
}

class Aula 
{
    //atributos
    id = 0;
    aforo = 0;
    materia = null;

    //constructores
    constructor(id, aforo, materia)
    {
        this.id = id;
        this.aforo = aforo;
        this.materia = materia;
    }

    //metodos
    show()
    {
        //TO_DO
    }

}

class Clase 
{
    //atributos
    materia = null;
    aula = null;
    profesor = null;
    alumnos = null;
    
    //constructores
    constructor(materia,aula,profesor,alumnos)
    {
        this.materia = materia;
        this.aula = aula;
        this.profesor = profesor;
        this.alumnos = alumnos;
    }

    //metodos
    show()
    {
        //TO_DO
    }
    
    showList()
    {
        //Mostrar listab de aprobados por sexo
        let aprobadosMujeres =0; 
        let totalMujeres = 0;       
        let listadoMujeres ="";
        let aprobadosHombres =0; 
        let totalHombres = 0;
        let listadoHombres ="";
        for (let i=0;i<this.alumnos.length;i++)
        {
            if (this.alumnos[i].sexo == 1)
            {
                totalHombres++;
                if (this.alumnos[i].calificacion >= this.materia.notaMinima)
                {
                    aprobadosHombres++;
                    listadoHombres += this.alumnos[i].nombre + " ("+this.alumnos[i].calificacion +")<br/>";
                }
            }
            else
            {
                totalMujeres++;
                if (this.alumnos[i].calificacion >= this.materia.notaMinima)
                {
                    aprobadosMujeres++;
                    listadoMujeres += this.alumnos[i].nombre + " ("+this.alumnos[i].calificacion +")<br/>";
                }
            }
        }

        //Imprimir resultados
        divResultado.innerHTML +="MUJERES APROBADAS<br/>" +
                listadoMujeres +
                "Porcentaje=" + (aprobadosMujeres/totalMujeres*100) + "<br/>" +
                "HOMBRES APROBADOS<br/>" +
                listadoHombres +
                "Porcentaje=" + (aprobadosHombres/totalHombres*100) + "<br/>";
    }
    
    verificarClase()
    {
        //Verificar si se puede dar la clase
        //Se puede dar la clase si hay más del 50%
        let numAlumnosAsistentes = 0;
        for (let i=0;i<this.alumnos.length;i++)
        {
            if (this.alumnos[i].estado)
            {
                numAlumnosAsistentes++;
            }
        }
        if (numAlumnosAsistentes/this.alumnos.length > 0.5)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

class Materia 
{
    //atributos
    nombre = "";
    notaMinima = 0;

    //constructores
    constructor(nombre,notaMinima)
    {
        this.nombre = nombre;
        this.notaMinima = notaMinima;
    }
    
    //metodos
    show()
    {

    }
}
