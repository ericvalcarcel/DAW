$(function()
{
	//Empieza la ejecución de jquery
	$("#boton1").click(function()
	{
		alert("Se presionó el botón");
        $("#boton1").css("background-color","#ff0000");

        console.log("Color=" + $("#boton1").css("background-color"));
	});

    //Arreglos para la tabla
    let trs = $("tr");
    trs.click(function()
    {
        //let trSeleccionado = $(this);
        //trSeleccionado.css("background-color", "#eeeeee");

        trs.css("background-color", "#eeeeee");
    });

    /*
    trs.mouseover(function()
    {
        $(this).css("background-color", "#eeeeee");
    });
    trs.mouseout(function()
    {
        $(this).css("background-color", "#ffffff");
    });
    */

    trs.hover(function()
    {
        $(this).css("background-color", "#eeeeee");
    },
    function()
    {
        $(this).css("background-color", "#ffffff");
    });

    //Listas
    $("#h21").click(function()
    {
        $("#lista1 li").toggle(500);
    });
    $("#h22").click(function()
    {
        $("#lista2 li").hide(1000, function()
        {
            $("#prueba").html("Se ha escondido la lista 2");
        });
        
    });

    $("#boton2").click(function()
    {
        alert($("#parrafo2").text().toUpperCase());       // .innerText
        alert($("#parrafo2").html());       // .innerHTML   lectura
    });

    $("#boton3").click(function()
    {
        $("#parrafo2").html("<strong>Texto</strong> cambiado");   //escritura
    });

    $("#btnPrueba").click(function()
    {
        alert($("#txtPrueba").val());   
    });

    $("#imgTest").mouseover(function()
    {
        $("#imgTest").prop("src","source/img/deportivo.jpg");
        $("#imgTest").prop("title","un deportivo!!!");
    })
    $("#imgTest").mouseout(function()
    {
        $("#imgTest").prop("src","source/img/utilitario.jpg");
        $("#imgTest").prop("title","un utilitario!!!");
    })

    $("#boton-1").click(function()
	{
	  $("#descripcion").addClass("recuadro");
      $("#container").removeClass("container");
      $("#container").addClass("container-fluid");
	});
	
	$("#boton-2").click(function()
	{
	  $("#descripcion").removeClass("recuadro");
      $("#container").removeClass("container-fluid");
      $("#container").addClass("container");
	});
    
    //Evento mousemove a todo el documento
    //$("body").mousemove(function(evt)
    //$(document).mousemove(function(evt)
    $(".container .row .col").mousemove(function(evt)
    {
        $("#corx").html("coordenada x=" + evt.clientX);
        $("#cory").html("coordenada y=" + evt.clientY);
    });

    $("#buscar").focus(function()
    {
        $("#buscar").val("");
    })

});