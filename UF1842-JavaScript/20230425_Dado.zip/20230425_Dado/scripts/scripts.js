var trampa = false;

function tirarDado()
{
    //Tirar el dado aleatoriamente
    var aleatorio = Math.floor(Math.random() * 6 + 1);

    //alert(aleatorio);

    //Mostrar el resultado
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML = "<img src='source/img/"+aleatorio+".png' width='100' alt='dado' />";

}

function tirarDadoTrampa()
{
    //Tirar el dado aleatoriamente
    var aleatorio = Math.floor(Math.random() * 6 + 1);
    //var aleatorio2 = Math.floor(Math.random() * 6 + 1);
    var msgTrampa="";

    if (aleatorio==6)
    {
        if (!trampa)
        {
            //Trampa
            aleatorio=3;
            trampa=true;
            msgTrampa="TRAMPA!!!!";
        }
        else
        {
            //No le hacemos trampa
            trampa=false;
            msgTrampa="";
        }
    }
    else
    {
        msgTrampa="";
    }

    //Mostrar el resultado
    var divResultado = document.getElementById("divResultado");
    divResultado.innerHTML = "<img src='source/img/"+aleatorio+".png' width='100' alt='dado' /> " + msgTrampa;

}

function generarLetra()
{
    var aleatorio = Math.floor(Math.random() * 26 + 65);

   //Mostrar el resultado
   var divResultado = document.getElementById("divResultado");
   divResultado.innerHTML = "<span style='font-size:80px;'>"+ String.fromCharCode(aleatorio) +"</span>";

}