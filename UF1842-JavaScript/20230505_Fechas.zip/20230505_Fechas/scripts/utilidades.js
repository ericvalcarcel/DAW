function getFecha(fecha, tipo)
{
    //Formato 1: dd/mm/yyyy
    //Formato 2: dd/mes/yyyy
    //Formato 3: d de mescompleto de yyyy
    //Formato 4: diasemana, d de mescompleto de yyyy
    //Formato 5: dd/mescompleto/yyyy

    var resultado = "";
    
    switch(tipo)
    {
        case 1:
            resultado = fecha.getDate().toString().padStart(2,"0") + "/" +
                        (fecha.getMonth()+1).toString().padStart(2,"0") + "/" +
                        fecha.getFullYear();
            break;

        case 2:
            resultado = fecha.getDate().toString().padStart(2,"0") + "/" +
                        getMes(fecha.getMonth(),2) + "/" +
                        fecha.getFullYear();
            break;

        case 3:
            resultado = fecha.getDate() + " de " +
                        getMes(fecha.getMonth(),1) + " de " +
                        fecha.getFullYear();
            break;

        case 4:
            resultado = getDiaSemana(fecha.getDay(),1) + ", " + 
                        fecha.getDate () + " de " +
                        getMes(fecha.getMonth(),1) + " de " +
                        fecha.getFullYear();
            break;
    }
 
    return resultado;
}

function getMes(mes,tipo)       // 2, 1
{
    var meses = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio",
                    "Agosto","Septiembre","Octubre","Noviembre","Diciembre"];
    var resultado = "";

    resultado = (tipo==1) ? meses[mes] : meses[mes].substring(0,3);

    return resultado;
}

function getDiaSemana(dia,tipo)
{
    //1 - Día completo
    //2 - Día con 3 letras
    //3 - Día con 1 letra  OJO Miércoles

    var dias = ["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];
    var resultado = "";

    switch(tipo)
    {
        case 1:
            resultado = dias[dia];
            break;

        case 2:
            resultado = dias[dia].substring(0,3);
            break;

        case 3:
            resultado = (dia==2) ? "X" : dias[dia].substring(0,1);
            break;
    }

    return resultado;
}