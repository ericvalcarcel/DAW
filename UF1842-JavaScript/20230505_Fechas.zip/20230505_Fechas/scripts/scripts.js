function mostrar()
{
    var hoy = new Date();

    alert(getFecha(hoy,1));

    alert(getFecha(hoy,2));

    alert(getFecha(hoy,3));

    alert(getFecha(hoy,4));
    




}