//Zona global de variables

//Posición inicial del heroe
var vTop = 348;
var vLeft = 274;

var desplazamiento = 50; //velocidad de desplazamiento


function mover(direccion)
{
    //Zonba local de las funciones
    switch (direccion)
    {
        case "up":
            posicionar(-desplazamiento,0);
            break;
        
        case "down":
            posicionar(desplazamiento,0);
            break;
        
        case "left":
            posicionar(0,-desplazamiento);
            break;

        case "right":
            posicionar(0,desplazamiento);
            break;

        default:
            alert("Algo raro ha pasado");
            break;
    }
}

function posicionar(despTop, despLeft)
{
    //Obtener el objeto del heroe
    var divHeroe = document.getElementById("divHeroe");

    //Mover el objeto en el despTop
    if (vTop + despTop < 0 || vTop + despTop > 348)
    {
        //Ajustar el muñeco
        //Controlando los límites de arriba y abajo
        if (vTop + despTop < 0)
        {
            //Control por arriba
            vTop = 0;
        }
        else
        {
            //Control por abajo
            vTop = 348;
        }
        //Ajustar los estilos con nuestra variable vTop
        divHeroe.style.top = vTop+"px";
    }
    else
    {
        //Control del muñeco cuando no estamos en los límites
        vTop = vTop + despTop;
        divHeroe.style.top = vTop+"px";
    }

    //Mover el objeto en el despLeft
    if (vLeft + despLeft < 0 || vLeft + despLeft > 548)
    {
        //Ajustar el muñeco
        if (vLeft + despLeft < 0)
        {
            vLeft = 0;
        }
        else
        {
            vLeft = 548;
        }
        divHeroe.style.left = vLeft+"px";
    }
    else
    {
        vLeft = vLeft + despLeft;
        divHeroe.style.left = vLeft+"px";
    }

    //Mostrar la posicion del elemento
    var posicion = document.getElementById("posicion");
    posicion.innerHTML = vTop + "," + vLeft;

}
