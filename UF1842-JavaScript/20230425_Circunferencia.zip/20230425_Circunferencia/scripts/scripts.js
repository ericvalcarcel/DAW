function calcular()
{
    //Obtener el objeto del radio
    var txtRadio = document.getElementById("txtRadio");

    //Leer el radio
    var radio = 0;
    if (txtRadio.value!="")
    {
        radio = parseFloat(txtRadio.value);

        //Calcular el perímetro
        var perimetro = 2 * Math.PI * radio;

        //Calcular la superficie
        var superficie = Math.PI * radio * radio;

        //Mostrar el resultado
        var divResultado = document.getElementById("divResultado");
        divResultado.innerHTML = "Perímetro => " + perimetro + "<br/>" +
                                "Superficie => " + superficie;

    }
    else
    {
        var divResultado = document.getElementById("divResultado");
        divResultado.innerHTML = "Falta especificar el radio";
    }
    /*var radio = parseFloat(txtRadio.value);
    if (isNaN(radio))
    {
        radio = 0;
    }*/



}