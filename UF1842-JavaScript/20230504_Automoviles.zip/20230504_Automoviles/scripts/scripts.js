function cargar()
{
    //Cargar ficha Utilitario
    var format = new Format("1px solid black", "2px 2px 4px black", "25px", "skyblue");
    
    var imagenUtilitario = new Image("source/img/utilitario.jpg", 325, 250, "Mercedes - M1", "Mercedes - M1", format, false);

    var utilitario = new Utilitario("Mercedes","M1",23000,82345,"Gasolina",2015,imagenUtilitario,false,true,4,800);

    utilitario.mostrar();


    //Cargar ficha CocheDeportivo
    var imagenDeportivo = new Image("source/img/deportivo.jpg", 325, 250, "Porsche - Carrera", "Porsche - Carrera", format, false);

    var deportivo = new CocheDeportivo("Porsche","Carrera",48500,64000,"Gasolina",2002,imagenDeportivo,false,true,300,5.5);

    deportivo.mostrar();


    //Cargar ficha Motocicleta
    var imagenMotocicleta = new Image("source/img/motocicleta.jpg", 325, 250, "Yamaha X-Max", "Yamaha X-Max", format, false);

    var motocicleta = new Motocicleta("Yamaha","X-Max",3800,23000,"Gasolina",2010,imagenMotocicleta,125,"Urbana","B1");

    motocicleta.mostrar();

}