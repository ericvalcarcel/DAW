class Vehiculo
{
    //Atributos
    marca="";
    modelo="";
    precio=0;
    kms=0;
    tecnologia ="";
    anno=0;
    imagen = null;
    disponible = true;
    //...

    //Atributo interno
    capa="";

    //Constructor
    constructor(marca, modelo, precio, kms, tecnologia, anno, imagen)
    {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.kms = kms;
        this.tecnologia = tecnologia;
        this.anno = anno;
        this.imagen = imagen;
    }

    //Métodos
    comprar() { }

    mostrar() 
    { 
        if (this instanceof Utilitario)
        {
            this.capa ="divResultado1";
        }
        else if (this instanceof CocheDeportivo)
        {
            this.capa ="divResultado2";
        }
        else
        {
            this.capa ="divResultado3";
        }

        //Imagen
        this.imagen.draw(this.capa);
        
        //Resto de atributos
        var obj = document.getElementById(this.capa);
        obj.innerHTML +="<ul class='list-group'>" +
                "<li class='list-group-item'>" + this.marca + "</li>" +
                "<li class='list-group-item'>" + this.modelo + "</li>" +
                "<li class='list-group-item text-danger'><b>" + this.precio + " €</b></li>" +
                "<li class='list-group-item'>" + this.kms + " km</li>" +
                "<li class='list-group-item'>" + this.tecnologia + "</li>" +
                "<li class='list-group-item'>" + this.anno + "</li>" +
                "</ul>";

    }
}

class Coche extends Vehiculo
{
    //Atributos
    descapotable=false;
    ubicacionVolante = true;    //Volante a la izquierda

    //Constructor
    constructor(marca, modelo, precio, kms, tecnologia, anno, imagen, descapotable, ubicacionVolante)
    {
        super(marca, modelo, precio, kms, tecnologia, anno, imagen);
        
        this.descapotable = descapotable;
        this.ubicacionVolante = ubicacionVolante;
    }

    //Métodos
    financiar() { }

    mostrar() 
    { 
        super.mostrar();

        //Particular
        var obj = document.getElementById(this.capa);
        obj.innerHTML +="<div>" +
                "<h4>Descapotable: " + ((this.descapotable) ? "Descapotable" :"No descapotable") + "</h4>" +
                "<h4>Ubicacion Volante: " + ((this.ubicacionVolante) ? "Izquierda" : "Derecha (raro)") + "</h4>" +
                "</div>";
    }



}

class Utilitario extends Coche
{
    //Atributos
    puertas=0;
    maletero=0;

    //Constructor
    constructor(marca, modelo, precio, kms, tecnologia, anno, imagen, descapotable, ubicacionVolante, puertas, maletero)
    {
        super(marca, modelo, precio, kms, tecnologia, anno, imagen, descapotable, ubicacionVolante);
        
        this.puertas = puertas;
        this.maletero = maletero;
    }

    //Métodos
    probar() { }

    mostrar() 
    {
        super.mostrar();

        //Particular
        var obj = document.getElementById(this.capa);
        obj.innerHTML +="<div>" +
                "<h5>Puertas: " + this.puertas + "</h5>" +
                "<h5>Maletero: " + this.maletero + " L</h5>" +
                "</div>";


    }

}

class CocheDeportivo extends Coche
{
    //Atributos
    caballos=0;
    tiempoAceleracion=0;
    //...
    
    //Constructor
    constructor(marca, modelo, precio, kms, tecnologia, anno, imagen, descapotable, ubicacionVolante, caballos, tiempoAceleracion)
    {
        super(marca, modelo, precio, kms, tecnologia, anno, imagen, descapotable, ubicacionVolante);
        
        this.caballos = caballos;
        this.tiempoAceleracion = tiempoAceleracion;
    }

    //Métodos
    alquilar()
    {

    }  

    mostrar() 
    { 
        super.mostrar();

        //Particular
        var obj = document.getElementById(this.capa);
        obj.innerHTML +="<div>" +
                "<h5>Caballos: " + this.caballos + "</h5>" +
                "<h5>Aceleración (0 a 100): " + this.tiempoAceleracion + " s</h5>" +
                "</div>";

    }

}

class Motocicleta extends Vehiculo
{
    //Atributos
    cilindrada = 0;
    tipo = "";
    permiso = "";

    //Constructor
    constructor(marca, modelo, precio, kms, tecnologia, anno, imagen, cilindrada, tipo, permiso )
    {
        super(marca, modelo, precio, kms, tecnologia, anno, imagen);
        
        this.cilindrada = cilindrada;
        this.tipo = tipo;
        this.permiso = permiso;
    }    

    //Métodos
    revisar() { }

    mostrar() 
    { 
        super.mostrar();

        //Particular
        var obj = document.getElementById(this.capa);
        obj.innerHTML +="<div>" +
                "<h5>Cilindrada: " + this.cilindrada + " cc</h5>" +
                "<h5>Tipo: " + this.tipo + "</h5>" +
                "<h5>Permiso: " + this.permiso + "</h5>" +
                "</div>";

    }

}

