class Image
{
    //Atributos
    src="";
    width=0;
    height=0;
    alt="";
    caption="";
    format=null;
    overwrite=false;

    //Constructor
    constructor(src, width, height, alt, caption, format, overwrite)
    {
        this.src=src;
        this.width=width;
        this.height=height;
        this.alt=alt;
        this.caption=caption;
        this.format=format;
        this.overwrite = overwrite;
    }

    //Métodos
    /*
    draw = function(obj)
    {
        obj.innerHTML += "<img ..... />"; 
    };
    */
    draw = function(id)
    {
        var obj = document.getElementById(id);
        var htmlImagen = 
            "<figure>"+
                "<img src='"+this.src+"' " +
                    "width='"+this.width+"' " + 
                    "height='"+this.height+"' " + 
                    "alt='"+this.alt+"' " + 
                    "style='border:"+this.format.border+"; " + 
                    "border-radius:"+this.format.borderRadius+"; " + 
                    "box-shadow:"+this.format.shadow+";' " + 
                "/>" +
                "<figcaption style='text-align:center; background:"+this.format.background+";'>" + this.caption +"</figcaption>" +
            "</figure>"; 

        if (this.overwrite)
        {
            //Borra todo 
            obj.innerHTML = htmlImagen;
        }
        else
        {
            //Añade
            obj.innerHTML += htmlImagen;
        }
    };


    show = function()
    {

    };

}

class Format
{
    //Atributos
    border=""; //("1px solid black")
    shadow="";  //("2px 2px 4px black")
    borderRadius="";    //("25px")
    background="";  //(formato de color)

    //Constructor
    constructor(border, shadow, borderRadius, background)
    {
        this.border=border;
        this.shadow=shadow;
        this.borderRadius=borderRadius;
        this.background=background;
    }

    //Métodos
    show = function()
    {

    };

}
