function drawImageBorrando()
{
    var format = new Format("1px solid red",
                            "2px 2px 4px silver",
                            "25px",
                            "skyblue");
    var image = new Image("source/img/paisaje.jpg", 400, 355, 
                            "paisaje muy bonito", 
                            "Paisaje de los Pirineos en primavera", format,true);
    image.draw("divResultado");    

}

function drawImageAnadiendo()
{
    var image = new Image("source/img/paisaje.jpg", 400, 355, 
                            "paisaje muy bonito", 
                            "Paisaje de los Pirineos en primavera", null,false);
    image.draw("divResultado");    

}