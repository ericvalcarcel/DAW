<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Intranet de Neptuno</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur officia modi at rem iure! Error doloremque eveniet voluptatem laudantium! Qui similique modi explicabo ratione error enim nostrum fugiat sapiente blanditiis.</p>
            </div>
            
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
