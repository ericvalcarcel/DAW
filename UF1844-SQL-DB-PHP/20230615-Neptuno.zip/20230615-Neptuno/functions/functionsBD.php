<?php
function conectar($host=null, $userName=null, $password=null, $database=null)
{
    if (func_num_args() < 3)
    {
        //Conexión por defecto
        //TO_DO
        exit("Parámetros incorrectos");
    }
    else
    {
        $conexion = mysqli_connect($host, $userName, $password, $database);
        if (!$conexion)
        {
            //Conexión ERROR
            echo "Error de conexión - " . mysqli_connect_errno() . " - " .mysqli_connect_error();
            exit("No se ha podido conectar con la base de datos.");
        }
        else
        {
            //echo "Conexión OK - " . mysqli_get_host_info($conexion) . " - " . mysqli_get_server_info($conexion) . "<br/>";
        }
    }    

    return $conexion;

}

function desconectar($conexion)
{
    if ($conexion)
    {
        $ok = mysqli_close($conexion);
        if ($ok)
        {
            //echo "Desconexión con éxito<br/>";
        }
        else
        {
            //echo "Error al desconectar<br/>";
        }
    }
}

?>