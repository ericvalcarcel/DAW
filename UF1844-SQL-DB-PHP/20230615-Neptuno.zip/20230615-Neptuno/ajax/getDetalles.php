<?php
require("../functions/functionsBD.php");

//Recuperar parámetros
$idPedido = $_GET["idPedido"];

$sql = "SELECT  dp.Cantidad,
                pr.NombreProducto,
                ROUND(dp.PrecioUnidad,2) AS PrecioUnidad,
                ROUND(pr.PrecioUnidad,2) AS PrecioCatalogo,
                dp.Descuento,
                ROUND(dp.Cantidad*dp.PrecioUnidad*(1-dp.Descuento),2) as Importe
        FROM detalles_de_pedido AS dp
            INNER JOIN producto AS pr
                ON dp.IdProducto = pr.IdProducto
        WHERE dp.IdPedido=$idPedido
        ORDER BY pr.NombreProducto";

//Crear la conexión
$conexion = conectar("localhost","root","","neptuno");

//Lanzar SQL y recuperar datos
$resultSet = mysqli_query($conexion,$sql);

//Template de cada fila
$fila ="<tr>
        <td>[Cantidad]</td>
        <td>[Producto]</td>
        <td>[Precio]</td>
        <td>[Descuento]</td>
        <td>[Importe]</td>
    </tr>";

//Recorrer el resultSet
$html="";
while (true)
{
    $linea = mysqli_fetch_object($resultSet);
    if ($linea==null) break;

    $html .= $fila;
    $html = str_replace("[Cantidad]",$linea->Cantidad,$html);
    $html = str_replace("[Producto]",$linea->NombreProducto,$html);

    //Precio
    $precio = ($linea->PrecioUnidad == $linea->PrecioCatalogo) 
        ? $linea->PrecioUnidad
        : $linea->PrecioUnidad . " <span class='text-danger'>(".$linea->PrecioCatalogo.")</span>";
    $html = str_replace("[Precio]",$precio,$html);
    
    $html = str_replace("[Descuento]",$linea->Descuento,$html);
    $html = str_replace("[Importe]",$linea->Importe,$html);

}

//Cerrar la conexión
desconectar($conexion);

echo $html;

?>