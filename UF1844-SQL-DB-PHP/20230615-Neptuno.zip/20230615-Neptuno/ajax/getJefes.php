<?php
require("../functions/functionsBD.php");

$sql = "SELECT  IdEmpleado,
                CONCAT(Nombre,' ',Apellidos) as Empleado
        FROM empleado
        ORDER BY 2";

//Crear la conexión
$conexion = conectar("localhost","root","","neptuno");

//Lanzar SQL y recuperar datos
$resultSet = mysqli_query($conexion,$sql);

//Template de cada fila
$fila ="<option value='[IdEmpleado]'>[Empleado]</option>";

//Recorrer el resultSet
$html="<option value='0'>Seleccionar</option>";
while (true)
{
    $linea = mysqli_fetch_object($resultSet);
    if ($linea==null) break;

    $html .= $fila;
    $html = str_replace("[IdEmpleado]",$linea->IdEmpleado,$html);
    $html = str_replace("[Empleado]",$linea->Empleado,$html);

}

//Cerrar la conexión
desconectar($conexion);

echo $html;

?>