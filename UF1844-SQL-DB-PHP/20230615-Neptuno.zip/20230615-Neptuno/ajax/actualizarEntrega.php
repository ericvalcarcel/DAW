<?php
require("../functions/functionsBD.php");

sleep(0.5);

//Recuperar parámetros
$idPedido = $_GET["idPedido"];

//Calcular fecha de hoy
$fecha_actual = date("Y-m-d"); 

$sql = "UPDATE pedido
        SET FechaEnvio='$fecha_actual' 
        WHERE idPedido=$idPedido";

//Crear la conexión
$conexion = conectar("localhost","root","","neptuno");

//Lanzar SQL y recuperar registros afectados
$numRegistros = mysqli_query($conexion,$sql);

//Cerrar la conexión
desconectar($conexion);

//Devolución de AJAX
if ($numRegistros>0)
{
    echo $fecha_actual;
}
else
{
    echo "KO";
}

?>