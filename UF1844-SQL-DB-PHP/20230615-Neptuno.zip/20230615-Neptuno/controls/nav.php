<!-- enlaces -->
<nav>
    <div class="container">
        <ul class="nav navbar-dark bg-dark">
            <li class="nav-item">
                <a class="nav-link text-white" href="index.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="pedidos.php">Pedidos</a>
            </li>
        </ul>
    </div>
</nav>
