var idPedidoActivo = 0;
var cargoAnterior = 0;
$(function()
{
    $("#tblPedidos").DataTable({
        order: [[0, 'desc']],
        pageLength: 50
    });
    
    $(".tdCostes").dblclick(function()
    {
        if (idPedidoActivo==0)
        {
            console.log($(this).prop("id"));
            idPedidoActivo = parseInt($(this).prop("id").split("_")[1]);
            cargoAnterior = $(this).html();

            $(this).html("<input type='number' class='form-control' value='"+$(this).html()+"' onkeypress='actualizarCargo(event);' id='txt_"+idPedidoActivo+"' />");
        }
    });


});

function actualizarEntrega(idPedido)
{
    if (confirm("¿Está seguro que quiere cambiar el estado del pedido?"))
    {
        $.ajax({
            async: true,
            type: "GET",
            dataType: "html",
            contentType: "application/x-www-form-urlencoded",
            url: "ajax/actualizarEntrega.php",
            data: "idPedido=" + idPedido,
            beforeSend: function()
            {
                $("#tdEntrega_"+idPedido).html('<div class="spinner-border" role="status"><span class="visually-hidden"></span></div>');
            },
            success: function(data)
            {
                //UI
                if (data!="KO")
                {
                    $("#tdEntrega_"+idPedido).html(data);
                }
                else
                {
                    alert("No se pudo actualizar la fecha de entrega. Inténtelo más tarde.")
                }

            },
            timeout: 5000,
            error: function(error){
                console.log("Error en el servidor." + error);
            }
        });
    }
}

var dt;
function mostrarDetalles(idPedido)
{
    try
    {
        dt.destroy();
    }
    catch(e){}

    //Ajax
    $.ajax({
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: "ajax/getDetalles.php",
        data: "idPedido=" + idPedido,
        success: function(data)
        {
            $("#staticBackdrop").modal("show");

            //UI
            $("#bdyDetallesPedidos").html(data);

            //Datatable
            dt = $('#tblDetallesPedidos').DataTable();
        },
        timeout: 5000,
        error: function(error){
            console.log("Error en el servidor." + error);
        }
    });
    
}

function actualizarCargo(evt)
{
    if (evt.keyCode==13)
    {
        //Actualizar el Cargo
        let nuevo = $("#txt_"+idPedidoActivo).val();

        //Ajax
        $.ajax({
            async: true,
            type: "GET",
            dataType: "html",
            contentType: "application/x-www-form-urlencoded",
            url: "ajax/actualizarCargo.php",
            data: "idPedido=" + idPedidoActivo + "&cargo="+nuevo,
            success: function(data)
            {
                //UI
                if (data=="OK")
                {
                    $("#tdCostes_"+idPedidoActivo).html(nuevo);
                }
                else
                {
                    alert("No se ha podido actualizar");
                    $("#tdCostes_"+idPedidoActivo).html(cargoAnterior);
                }
                idPedidoActivo=0;
                cargoAnterior=0;

            },
            timeout: 5000,
            error: function(error){
                console.log("Error en el servidor." + error);
            }
        });
    }
}

function gestionarEmpleado(idEmpleado)
{
    //idEmpleado => 0,  dar de alta un nuevo empleado
    //idEmpleado => X,  editar un empleado
    $("#modalEmpleados").modal("show");

    //Ajax para rellenar el combo de Jefe
    $.ajax({
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: "ajax/getJefes.php",
        success: function(data)
        {
            console.log(data);
            //UI
            if (data!="")
            {
                //UI del combo de Jefes
                $("#cmbJefe").html(data);

               //Ajax para rellenar la ficha de empleado, si idEmpleado!=0
               if (idEmpleado!=0)
               {
                    //Ajax 

               }
            }
        },
        timeout: 5000,
        error: function(error){
            console.log("Error en el servidor." + error);
        }
    });

}