<?php 
    require("functions/functionsBD.php");//funcions d'acces a la BD

    //Tareas consultar BD para extraer Categorías y rellenar combo
    $combo="";
    $sql = "SELECT idCategoria, NombreCategoria 
            FROM categoria
            WHERE idCategoria > ?
            ORDER BY 2";

    $conexion = conectar("localhost","root","","neptuno");

    //Preparar consulta
    $consulta = mysqli_prepare($conexion, $sql);

    //Asociación parámetros
    $ok = mysqli_stmt_bind_param($consulta, "i", $id);

    //Vinculación del resultado
    $ok = mysqli_stmt_bind_result($consulta,$idCategoria,$nombreCategoria);

    //Ejecutar consulta
    $id = 0;
    $ok = mysqli_stmt_execute($consulta);

    //Lectura del resultado
    $fila = "<option value='[idCategoria]'>[NombreCategoria]</option>";
    while (mysqli_stmt_fetch($consulta)) 
    {
        $combo .= $fila;
        $combo = str_replace("[idCategoria]",$idCategoria,$combo);
        $combo = str_replace("[NombreCategoria]",$nombreCategoria,$combo);
    }
    desconectar($conexion);


    require("controls/head.php") ; //cargar head de pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col">
                    <h1>Productos</h1>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3 row">
                                <label for="cmbCategoria" class="col-sm-3 col-form-label">Categoría:</label>
                                <div class="col-sm-9">
                                    <select id="cmbCategoria" class="form-control">
                                        <option value="0" selected>Todas las categorías</option>
                                        <?= $combo ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3 row">
                                <label for="txtTexto" class="col-sm-3 col-form-label">Texto:</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="txtTexto" />
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <button type="button" class="btn btn-primary" id="btnSeleccionar">Seleccionar</button>
                        </div>
                    </div>
                    <div id="numResultadosHeader"></div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Precio</th>
                                <th>Stock</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody id="bdyResultado">

                        </tbody>
                    </table>
                    <div id="numResultadosFooter"></div>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    //include("controls/footer.php") ;
    require("controls/links.php") ;
?>