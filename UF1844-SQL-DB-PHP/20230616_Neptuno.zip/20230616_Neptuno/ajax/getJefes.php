<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//Preparar la consulta SQL
$sql = "SELECT 
            em.IdEmpleado,
            CONCAT(em.Nombre,' ',em.Apellidos) AS NombreEmpleado
        FROM empleado AS em 
        ORDER BY 2";
//i template de la fila
$fila="<option value='[IdEmpleado]'>[NombreEmpleado]</option>";
//inicialitzar sortida
$html="<option value='0'>Seleccionar</option>";

//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");
// y llançar la sql
$resultSet = mysqli_query($conexion,$sql);
//Fetch de les files del resultSet
while(true)
{
    $linea = mysqli_fetch_object($resultSet);
    if ($linea == null){break;}

    $html .= $fila;
    $html = str_replace("[IdEmpleado]",$linea->IdEmpleado,$html);
    $html = str_replace("[NombreEmpleado]",$linea->NombreEmpleado,$html);
}
//tancar la conexio mySQL localhost
desconectar($conexion);
echo $html;
?>