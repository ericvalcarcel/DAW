<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD
//recuperar parametres
$idPedido = $_GET["idPedido"];
$cargo = $_GET["cargo"];
$fecha_actual=date("Y-m-d");
//Preparar la consulta SQL
$sql = "UPDATE pedido
        SET cargo= $cargo
        WHERE idPedido=$idPedido";
//i template de la fila

//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");
// y llançar la sql i recuperar registres afectats
$numRegistros = mysqli_query($conexion,$sql);
//tancar la conexio mySQL localhost
desconectar($conexion);
//retornar dades
if ($numRegistros>0) {echo "OK";} else {echo "KO";}
?>