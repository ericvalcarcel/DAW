<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//recuperar parametres
$idCategoria = $_POST["idCategoria"];
$texto = $_POST["texto"];

//Preparar la consulta SQL
//WHERE idCategoria = ? AND (NombreProducto LIKE '%?%' OR CantidadPorUnidad LIKE '%?%')
$where="";
$numParametros=0;
if ($idCategoria !="0")
{
    $where = "idCategoria = ? ";
    
    $numParametros++;
}
if ($texto != "")
{
    if ($where!="") $where .="AND ";

    $where .= "(NombreProducto LIKE ? OR CantidadPorUnidad LIKE ?)";
    
    $numParametros +=2;
}

$sql = "SELECT NombreProducto, CantidadPorUnidad, PrecioUnidad, UnidadesEnExistencia, Suspendido
        FROM producto
        WHERE $where
        ORDER BY 1";

$conexion = conectar("localhost","root","","neptuno");

//Preparar consulta
$consulta = mysqli_prepare($conexion, $sql);

//Asociación parámetros
switch ($numParametros)
{
    case 1:
        $ok = mysqli_stmt_bind_param($consulta, "i", $id);
        break;

    case 2:
        $ok = mysqli_stmt_bind_param($consulta, "ss", $s1, $s2);
        break;

    case 3:
        $ok = mysqli_stmt_bind_param($consulta, "iss", $id, $s1, $s2);
        break;
}

//Vinculación del resultado
$ok = mysqli_stmt_bind_result($consulta, $nombreProducto, $cantidadPorUnidad, $precioUnidad, $unidadesEnExistencia, $suspendido);

//Ejecutar consulta
$id = $idCategoria;
$s1 = "%$texto%";
$s2 = "%$texto%";
$ok = mysqli_stmt_execute($consulta);

$fila = "<tr>
            <td>[Nombre]</td>
            <td>[Descripcion]</td>
            <td>[Precio]</td>
            <td>[Stock]</td>
            <td>[Estado]</td>
            </tr>";

$html="";
$counter = 0;
while (mysqli_stmt_fetch($consulta)) 
{
    $counter++;

    $html .= $fila;
    $html = str_replace("[Nombre]", $nombreProducto, $html);
    $html = str_replace("[Descripcion]", $cantidadPorUnidad, $html);
    $html = str_replace("[Precio]", $precioUnidad, $html);
    $html = str_replace("[Stock]", $unidadesEnExistencia, $html);
    $html = str_replace("[Estado]", $suspendido, $html);
}
desconectar($conexion);

//Preparación JSON
$array = [];

//numero de resultados
$array["numResultados"] = $counter;

//grid
$array["grid"] = $html;

$JSON=json_encode($array);
echo $JSON;

?>