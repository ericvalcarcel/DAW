<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//recuperar parametres
$idEmpleado = $_GET["idEmpleado"];
//Preparar la consulta SQL
$sql = "SELECT 
            em.Tratamiento,
            em.Nombre,
            em.Apellidos,
            em.Cargo,
            em.Jefe,
            em.FechaContratación
        FROM empleado AS em 
        WHERE em.IdEmpleado=$idEmpleado";
//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");
// y llançar la sql
$resultSet = mysqli_query($conexion,$sql);
//Fetch de les files del resultSet

$fila=[];
while(true)
{
    $linea = mysqli_fetch_object($resultSet);
    if ($linea == null){break;}
    
    //Carga de datos en el array
    $fila["tratamiento"] = $linea->Tratamiento;
    $fila["nombre"] = $linea->Nombre;
    $fila["apellidos"] = $linea->Apellidos;
    $fila["cargo"] = $linea->Cargo;
    $fila["jefe"] = $linea->Jefe;
    $fila["fechaContratacion"] = $linea->FechaContratación;
}
//tancar la conexio mySQL localhost
desconectar($conexion);

//serializar sortida
$JSON=json_encode($fila);

echo $JSON;
?>