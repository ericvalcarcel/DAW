<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//recuperar parametres
$sql = $_POST["sql"];

//inicialitzar sortida
$html="";
$numResultados=0;

//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");

//llançar la sql
$resultSet = mysqli_query($conexion,$sql);

$numResultados = mysqli_num_rows($resultSet);

$resultado = mysqli_fetch_all($resultSet);

//tancar la conexio mySQL localhost
desconectar($conexion);

$html = mostrarMatriz($resultado);



//Preparar salida
$fila = [];

//numero de resultados
$fila["numResultados"] = $numResultados;

//grid
$fila["grid"] = $html;

$JSON=json_encode($fila);
echo $JSON;


?>