<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//recuperar parametres
//Json del empleado
$empleado = $_POST["empleado"];

//Deserializa
$empleado=json_decode($empleado);


$jefe = ($empleado->jefe==0)?'NULL':$empleado->jefe;

if($empleado->idEmpleado !="")
{
    //Update de la ficha empleado
    $sql = "UPDATE empleado
            SET Apellidos= '$empleado->apellidos',
                Nombre= '$empleado->nombre', 
                Cargo= '$empleado->cargo', 
                Tratamiento= '$empleado->tratamiento',
                FechaContratación= '$empleado->fechaContratacion', 
                Jefe= $jefe
            WHERE idEmpleado= $empleado->idEmpleado";
}
else
{
    //Inserción de una empleado nuevo
    $sql =  "INSERT INTO empleado 
                (Apellidos, Nombre, Cargo, Tratamiento, FechaContratación, Jefe )
            VALUES
                ('$empleado->apellidos', '$empleado->nombre', '$empleado->cargo', '$empleado->tratamiento','$empleado->fechaContratacion',$jefe)";
}
//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");
// y llançar la sql i recuperar registres afectats
$numRegistros = mysqli_query($conexion,$sql);
//tancar la conexio mySQL localhost
desconectar($conexion);
//retornar dades
if ($numRegistros>0) {echo "OK";} else {echo "KO";}
?>