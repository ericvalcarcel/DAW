<?php
require("../functions/functionsBD.php");//funcions d'acces a la BD

//recuperar parametres
$idPedido = $_GET["idPedido"];
//Preparar la consulta SQL
$sql = "SELECT  dp.Cantidad,
                pr.NombreProducto,
                dp.PrecioUnidad,
                pr.PrecioUnidad AS PrecioCatalogo,
                dp.Descuento,
                ROUND(dp.Cantidad*dp.PrecioUnidad*(1-dp.Descuento),2) as Importe
        FROM detalles_de_pedido AS dp
            INNER JOIN producto AS pr
                ON dp.IdProducto = pr.IdProducto
        WHERE dp.IdPedido = $idPedido
        ORDER BY pr.NombreProducto";
//i template de la fila
$fila = "<tr>
            <td>[Cantidad]</td>
            <td nowrap>[NombreProducto]</td>
            <td>[PrecioUnidad]</td>
            <td>[Descuento]</td>
            <td>[Importe]</td>
        </tr>";
//inicialitzar sortida
$html="";

//crear conexio mySQL localhost i conectem a la bd
$conexion = conectar("localhost","root","","neptuno");
// y llançar la sql
$resultSet = mysqli_query($conexion,$sql);
//Fetch de les files del resultSet
while(true)
{
    $linea = mysqli_fetch_object($resultSet);
    if ($linea == null){break;}

    $html .= $fila;
    $html = str_replace("[Cantidad]",$linea->Cantidad,$html);
    $html = str_replace("[NombreProducto]",$linea->NombreProducto,$html);
    ($linea->PrecioUnidad==$linea->PrecioCatalogo)?
        $html = str_replace("[PrecioUnidad]",$linea->PrecioUnidad,$html):
        $html = str_replace("[PrecioUnidad]",$linea->PrecioUnidad." <span style='color:red;'>($linea->PrecioCatalogo)</span>",$html);
    $descuento=($linea->Descuento==0)?"":($linea->Descuento*100)."%";
    $html = str_replace("[Descuento]",$descuento,$html);
    $html = str_replace("[Importe]",$linea->Importe,$html);
}
//tancar la conexio mySQL localhost
desconectar($conexion);
echo $html;
?>