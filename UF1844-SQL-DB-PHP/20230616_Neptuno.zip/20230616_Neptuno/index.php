<?php 
    require("functions/functionsBD.php");//funcions d'acces a la BD
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col">
                    <p><a class="btn btn-dark cmpnyColor" value='0' href='javascript:gestionarEmpleado(0);'>Crear-empleado</a></p>
                </div>
            </div>
            <div class="row mt-2">
                <div class="col">
                    <table id='tblResutados' class='table compact hover'>
                        <thead>
                            <tr>
                                <th>IdPedido</th>
                                <th>FechaPedido</th>
                                <th>NombreEmpresa</th>
                                <th>NombreEmpleado</th>
                                <th>TotalPedido</th>
                                <th>Cargo</th>
                                <th>FechaEntrega</th>
                                <th>Detalles</th>
                            </tr>
                        </thead>
                        <tbody>
                    <?php 
                    //Preparar la consulta SQL
                    $sql = "SELECT 	pe.IdPedido,
                    pe.FechaPedido,
                    cl.NombreEmpresa,
                    CONCAT(em.Nombre,' ',em.Apellidos) AS NombreEmpleado,
                    em.IdEmpleado,
                    ROUND(SUM(dp.PrecioUnidad*dp.Cantidad*(1-dp.Descuento)),2) AS TotalPedido,
                    pe.Cargo,
                    pe.FechaEnvio
            FROM cliente as cl
                INNER JOIN pedido AS pe 
                ON cl.IdCliente = pe.IdCliente
                INNER JOIN empleado AS em 
                ON pe.IdEmpleado = em.IdEmpleado
                INNER JOIN detalles_de_pedido AS dp
                ON pe.IdPedido = dp.IdPedido
            GROUP BY pe.IdPedido
            ORDER BY pe.FechaPedido DESC, pe.IdPedido DESC";

                    //crear conexion mySQL localhost y Conectamos a la bd
                    $conexion = conectar("localhost","root","","neptuno");

                    // y lanzar la sql
                    $resultSet = mysqli_query($conexion,$sql);

                    //template de la fila
                    $fila = "<tr>
                                <td>[IdPedido]</td>
                                <td nowrap>[FechaPedido]</td>
                                <td>[NombreEmpresa]</td>
                                <td>[NombreEmpleado]</td>
                                <td>[TotalPedido]</td>
                                <td id='cargo_[IdPedido]' class='cargo' title='Doble click para actualizar'>[Cargo]</td>
                                <td id='fe_[IdPedido]' nowrap>[FechaEntrega]</td>
                                <td>[Detalles]</td>
                            </tr>";

                    //Fetch de las filas del resultSet
                    while(true)
                    {
                        $linea = mysqli_fetch_object($resultSet);

                        if ($linea == null){break;}
                        $html = $fila;
                        $html = str_replace("[IdPedido]",$linea->IdPedido,$html);
                        $html = str_replace("[FechaPedido]",$linea->FechaPedido,$html);
                        $html = str_replace("[NombreEmpresa]",$linea->NombreEmpresa,$html);
                        $acciones = "<a value='$linea->IdEmpleado' href='javascript:gestionarEmpleado($linea->IdEmpleado);' class='empleado'><i class='bi bi-person-lines-fill'> $linea->NombreEmpleado</a>";
                        $html = str_replace("[NombreEmpleado]","$acciones",$html);
                        $html = str_replace("[TotalPedido]",$linea->TotalPedido,$html);
                        $html = str_replace("[Cargo]",$linea->Cargo,$html);
                        //entregado
                        $entregado = ($linea->FechaEnvio=="")?"<a href='javascript:actualizarEntrega($linea->IdPedido)'><i class='bi bi-truck'></i> Sin Entregar</a>":$linea->FechaEnvio;
                        $html = str_replace("[FechaEntrega]",$entregado,$html);

                        $acciones = "<a id='dp$linea->IdPedido' href='#' class='boton' data-bs-toggle='modal' data-bs-target='#staticBackdrop'><i class='bi bi-plus-circle-fill'></i></a>";
                        $html = str_replace("[Detalles]","$acciones",$html);

                        echo $html;
                        
                    }
                    //cerrar la conexion mySQL localhost
                    desconectar($conexion);
                ?>
                    </tbody>
                        <tfoot>
                            <tr>
                                <th>IdPedido</th>
                                <th>FechaPedido</th>
                                <th>NombreEmpresa</th>
                                <th>NombreEmpleado</th>
                                <th>TotalPedido</th>
                                <th>Cargo</th>
                                <th>FechaEntrega</th>
                                <th>Detalles</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </main>
    <!-- Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Detalles Pedido</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table compact hover" id="detallesPedidos">
                    <thead>
                        <tr>
                            <th>Cantidad</th>
                            <th>Producto</th>
                            <th>Precio </th>
                            <th>Descuento</th>
                            <th>Importe</th>
                        </tr>   
                    </thead>
                    <tbody id="bdyDetallesPedidos"></tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
            </div>
        </div>
    </div>
    <!-- Modal Empleados-->
    <div class="modal fade" id="modalEmpleados" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalEmpleadosLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEmpleadosLabel">Detalles Empeado</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="bdyDetallesEmpleado" class="modal-body">
                    <form>
                        <div class="mb-3 row">
                                <label for="txtTratamiento" class="col-sm-3 col-form-label text-end">Tratamiento:</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="txtTratamiento" name="txtTratamiento">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="txtNombre" class="col-sm-3 col-form-label text-end">Nombre Empleado:</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="txtNombre" name="txtNombre">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="txtApellidos" class="col-sm-3 col-form-label text-end">Apellido:</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="txtApellidos" name="txtApellidos">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="txtCargo" class="col-sm-3 col-form-label text-end">Cargo:</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="txtCargo" name="txtCargo">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="datContratacion" class="col-sm-3 col-form-label text-end">Fecha contratacion:</label>
                                <div class="col-sm-9">
                                <input type="date" class="form-control" id="datContratacion" name="datContratacion">
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="cmbJefe" class="col-sm-3 col-form-label text-end">Jefe:</label>
                                <div class="col-sm-9">
                                    <select class="form-control" id="cmbJefe" name="cmbJefe">
                                    </select>
                                </div>
                            </div>
                    </form>
            </div>
            <div class="modal-footer">
                <button id=btnGuardarEmpleado type="button" class="btn btn-success">Guardar</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
            </div>
        </div>
    </div>

<?php 
    include("controls/aside.php") ;
    //include("controls/footer.php") ;
    require("controls/links.php") ;
?>