//Variables globales
var idPedidoActivo=0;
var cargoAnterior=0;
var table = null;

//datatables.net
$(function()
{
    table = new DataTable('#tblResutados', 
    {
        "pageLength": 10,
        order: [0, 'desc'],
        stateSave: true,
        columnDefs: 
        [
            {
                targets: [4,5,6,7],
                className: 'dt-center'
            }
        ],
        "footerCallback": function( tfoot, data, start, end, display ) 
        {
            var api = this.api();
            $(api.column( 4 ).footer()).html("Total</br>" +
                api.column( 4 ).data().reduce( function ( a, b ) 
                    {
                        return (parseFloat(a) + parseFloat(b)).toFixed(2);
                    }, 0 )
            );
            $(api.column( 5 ).footer()).html("Total</br>" +
                api.column( 5 ).data().reduce( function ( a, b ) 
                    {
                        return (parseFloat(a) + parseFloat(b)).toFixed(2)
                    }, 0 )
            );
        }
    });
});

function actualizarEntrega(idPedido)
{
    if(confirm("Segur que voleu canviar l'estat de la comanda?"))
    {
        $.ajax(
        {
            async: true,
            type: "GET",
            dataType: "html",
            contentType: "application/x-www-form-urlencoded",
            url: "ajax/actualizarEntrega.php",
            data: "idPedido=" + idPedido,
            beforeSend: function()
            {
                let spiner =    "<div class='spinner-border text-primary text-center'>"+
                                    "<span class='visually-hidden'>Loading...</span>"+
                                "</div>";
                $("#fe_"+idPedido).html(spiner);
            },
            success: function(data)
            {
                if(data!="KO"){ $("#fe_"+idPedido).html(data);}else{swal("No se pudo actualizar");}
            },
            timeout: 1000,
            error: function(error)
            {
                console.log(error);
                $("#txtError").html(error);
            }
        });
    }
}

function gestionarEmpleado(idEmpleado)
{
    //idEmpleado=0 crear empleado idEmpleado > 0 editar empleado
    //Ajax cmbJefe
    $.ajax(
    {
        async: true,
        type: "GET",
        dataType: "html",
        contentType: "application/x-www-form-urlencoded",
        url: "ajax/getJefes.php",
        beforeSend: function(){},
        success: function(data)
        {
            $("#modalEmpleados").modal("show");
            if(data!="")
            {
                //Updata cmbJefe
                $("#cmbJefe").html(data);
                if(idEmpleado!=0)
                {
                    //Ajax rellenar ficha empleado
                    $.ajax(
                    {
                        async: true,
                        type: "GET",
                        dataType: "json",
                        contentType: "application/x-www-form-urlencoded",
                        url: "ajax/getEmpleados.php",
                        data: "idEmpleado=" + idEmpleado,
                        beforeSend: function(){},
                        success: function(data)
                        {
                            //eliminamos al empleado del cmbJefe
                            $("#cmbJefe option[value="+idEmpleado+"]").remove();
                            //Label del modal
                            $("#modalEmpleadosLabel").html("Empleado #"+idEmpleado);
                            //Rellenar el form
                            $("#txtTratamiento").val(data.tratamiento);
                            $("#txtNombre").val(data.nombre);
                            $("#txtApellidos").val(data.apellidos);
                            $("#txtCargo").val(data.cargo);
                            $("#datContratacion").val(data.fechaContratacion);
                            $("#cmbJefe").val(data.jefe);
                        },
                        timeout: 1000,
                        error: function(error)
                        {
                            console.log(error);
                            $("#txtError").html(error);
                        }
                    });
                }
                else
                {
                    //Label del modal
                    $("#modalEmpleadosLabel").html("Nuevo Empleado");
                    //Rellenar el form
                    $("#txtTratamiento").val("");
                    $("#txtNombre").val("");
                    $("#txtApellidos").val("");
                    $("#txtCargo").val("");
                    $("#datContratacion").val("");
                    $("#cmbJefe").val("");
                }
            }
        },
        timeout: 1000,
        error: function(error)
        {
            console.log(error);
        }
    });
}
//listener boton Guardar Empleado
$("#btnGuardarEmpleado").on("mousedown",function()
{
    
    
    
    if(confirm("¿Seguro que quiere guardar los datos?"))
    {
        let idEmpleado = $("#modalEmpleadosLabel").html().split("#")[1];
        //Capturar el form
        let empleado = {
            idEmpleado: idEmpleado?idEmpleado:"",
            tratamiento: $("#txtTratamiento").val(),
            nombre: $("#txtNombre").val(),
            apellidos: $("#txtApellidos").val(), 
            cargo : $("#txtCargo").val() , 
            fechaContratacion: $("#datContratacion").val(),
            jefe: $("#cmbJefe").val()
        };
        //Ajax actualizar ficha empleado
        $.ajax(
        {
            async: true,
            type: "POST",
            dataType: "html",
            //dataType: "json",
            contentType: "application/x-www-form-urlencoded",
            url: "ajax/actualizarEmpleado.php",
            data: "empleado="+JSON.stringify(empleado),
            beforeSend: function(){},
            success: function(data)
            {
                if (data=="OK")
                {
                    
                    
                    text = "Empleado: "+empleado.nombre+" "+empleado.apellidos+"\r\n"+
                            ((idEmpleado)?"Modificado ":"Dado de alta ")+"correctamente";
                    swal(empleado.nombre+" "+empleado.apellidos,((idEmpleado)?"Modificado ":"Dado de alta ")+"correctamente","success").then((value) => {location.reload();});
                }
                else
                {console.log(data);}
            },
            timeout: 1000,
            error: function(error)
            {
                console.log(error);
            }
        });
    }
});

//Listener de les lupes
$(".boton").on('click', function (e) 
{
    $("#staticBackdropLabel").html("Pedido nº: " + e.currentTarget.id.substr(2));
    mostrarDetalles(parseInt(e.currentTarget.id.substr(2)));
});

function mostrarDetalles(idPedido)
{
    let table2=null;
    $.ajax(
        {
            async: true,
            type: "GET",
            dataType: "html",
            contentType: "application/x-www-form-urlencoded",
            url: "ajax/getDetalles.php",
            data: "idPedido=" + idPedido,
            beforeSend: function(){},
            success: function(data)
            {
                $("#bdyDetallesPedidos").html(data);
                //datatable
                table2 = new DataTable('#detallesPedidos',
                {
                    columnDefs: 
                    [
                        {
                            targets: [2,3,4],
                            className: 'dt-center'
                        }
                    ]
                });
            },
            timeout: 1000,
            error: function(error)
            {
                console.log(error);
                $("#txtError").html(error);
            }
        });
    //Listener tancar modal
    $("#staticBackdrop").on('hidden.bs.modal', function (event) 
    {
        table2.destroy();
    });
}

//Cambiar el valor de un cargo al dbl click del mismo

$(".cargo").dblclick(function()
{
    if(idPedidoActivo==0)
    {
        idPedidoActivo = parseInt($(this).prop("id").split("_")[1]);
        cargoAnterior = $(this).html();
        console.log(cargoAnterior);
        $(this).html("<input id='txt_"+ idPedidoActivo +"' type='number' step='0.1' class='form-control form-control-sm cargo' value='"+$(this).html()+"' onkeypress='actualizarCargo(event);'/>");
    }
    
});

function actualizarCargo(e)
{
    if(e.keyCode==13)
    {
        if(confirm("Segur que voleu canviar les dades?"))
        {
            //actualizar cargo
            nuevoCargo = $("#txt_"+idPedidoActivo).val()

            $.ajax(
            {
                async: true,
                type: "GET",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "ajax/actualizarCargo.php",
                data: "idPedido=" + idPedidoActivo + "&cargo="+nuevoCargo,
                beforeSend: function(){},
                success: function(data)
                {
                    if(data="OK") 
                    {
                        $("#cargo_"+idPedidoActivo).html(nuevoCargo);
                        idPedidoActivo=0;
                        cargoAnterior=0;
                    } 
                    else 
                    {
                        swal('No se pudo modificar el pedido');
                        $("#cargo_"+idPedidoActivo).html(cargoAnterior);
                    }
                },
                timeout: 1000,
                error: function(error)
                {
                    console.log(error);
                    $("#txtError").html(error);
                }
            });
        }
        else
        {
            $("#cargo_"+idPedidoActivo).html(cargoAnterior);
            idPedidoActivo=0;
            cargoAnterior=0;
        }
    }
}

