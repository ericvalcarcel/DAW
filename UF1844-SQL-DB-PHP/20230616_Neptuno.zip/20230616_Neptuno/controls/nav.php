<nav class="navbar navbar-expand-sm navbar-dark sticky-top p-0">
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#opciones">
    <span class="navbar-toggler-icon"></span>
  </button>
  <!-- enlaces -->
  <div class="collapse navbar-collapse" id="opciones">   
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" href="index.php">Neptuno 1</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="productos.php">Productos</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="sql.php">SQL</a>
        </li>            
    </ul>
  </div>
  </nav>