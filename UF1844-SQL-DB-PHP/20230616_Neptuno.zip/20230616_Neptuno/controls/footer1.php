<footer>
    <div class="container">
        <div class="row"  style="background-color: black;color: white">
            <div class="col-md-12">
                otro footer
            </div>
        </div>
    </div>
</footer>