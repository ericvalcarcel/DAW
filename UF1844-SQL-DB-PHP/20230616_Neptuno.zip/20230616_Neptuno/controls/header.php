<header>
    <div class="container">
        <div class="row py-1">
            <div class="col-md-12 text-center">
                <h1 class="m-0">Base Datos <img id="logoEmpresa" src="source/img/neptuno.png" height=60/> Neptuno</h1>
            </div>
        </div>
    </div>
</header>

        