<style>
    #divResultados, #divNumResultados
    {
        height:auto;
        min-height:25px;
        border:1px solid silver;
    }
</style>
<?php 
    require("functions/functionsBD.php");//funcions d'acces a la BD
    require("controls/head.php") ; //cargar head de pa pagina
    require("controls/header.php") ;
    require("controls/nav.php") ;
?>
    <main>
        <div class="container">
            <div class="row mt-2">
                <div class="col">
                    <h1>Editor SQL</h1>
                    <textarea class="form-control" id="txtEditor" name="txtEditor" rows="10"></textarea>
                    <button type="button" class="btn btn-primary mb-2" id="btnEjecutar" style="float:right;">Ejecutar</button>
                    <div id="divNumResultados" class="mb-2" style="clear:both;">
                
                
                    </div>
                    <div id="divResultados" class="mb-2">


                    </div>
                </div>
            </div>
        </div>
    </main>

<?php 
    include("controls/aside.php") ;
    //include("controls/footer.php") ;
    require("controls/links.php") ;
?>