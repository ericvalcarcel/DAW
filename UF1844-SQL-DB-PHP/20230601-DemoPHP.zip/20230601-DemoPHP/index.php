<?php
    //TO_DO a la BD
    $nombreProducto="Botas blancas";
    $precio=125.0;
    $stock=9;
    $strStock="";
    if ($stock < 10)
    {
        $strStock="Nivel bajo";
    }
    else if ($stock < 20)
    {
        $strStock="Nivel medio";
    }
    else
    {
        $strStock="Nivel alto";
    }

    $categoria="Complementos de mujer";
    $imagen="<img src='source/img/botas-blancas.jpg' width='100%' alt='$nombreProducto' />";

    //Nombre del producto. Categoría | Empresa
    $title="$nombreProducto. $categoria. | Empresa demo";

    //Nombre del producto. Los mejores categoria, a los mejores precios. Envíos gratis
    $description="$nombreProducto. Los mejores '$categoria', a los mejores precios. Envíos gratis.";

?>
<!doctype html>
<html lang="es">
    <head>
        <title><?=$title?></title>
        <meta description="<?=$description?>" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">        
        
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    
        <link rel="stylesheet" href="styles/styles.css" />
        
    </head>
    <body>
        <header>
            
        </header>
        <nav>

        </nav>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <?=$imagen?>
                    </div>
                    <div class="col-md-8">
                        <h2><em><?=$categoria?></em></h2>
                        <h1><?=$nombreProducto?></h1>
                        <p><b>Precio: </b><?=$precio?>
                        <p><b>Stock: </b><?=$strStock?>

                        <form>
                            <input type="number" id="txtCantidad" name="txtCantidad" />
                            <button class="btn btn-primary">Agregar al carrito</button>
                        </form>

                    </div>
                </div>
            </div>
        </main>
        <aside>

        </aside>
        <footer>

        </footer>

        <!-- Si utilizamos componentes de Bootstrap que requieran Javascript agregar el siguiente archivo -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

		<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

        <script src="scripts/scripts.js"></script>
    </body>
</html>