<!-- enlaces -->
<nav>
    <div class="container">
        <ul class="nav navbar-dark bg-dark">
            <li class="nav-item">
                <a class="nav-link text-white" href="index.php">Inicio</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="tipos.php">Tipos de datos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="matrices.php">Matrices</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="numeros.php">Números</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="cadenas.php">Cadenas</a>
            </li>
        </ul>
    </div>
</nav>
