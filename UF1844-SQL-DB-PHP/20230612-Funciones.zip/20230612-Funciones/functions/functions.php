<?php

function calcularIVA($tipo, $importe)
{
    $total= ($tipo / 100 + 1) * $importe;
    return $total;
}

function formatoMoneda($total)
{
    return number_format($total, 2, '.', ' ')  . "€";
}

function calcularMaximo($array)
{
    return max($array);
}

function calcularMinimo($array)
{
    return min($array);
}

function calcularMedia($array)
{
    return array_sum($array)/count($array);
}

function calcularMediana($array)
{
    sort($array);
    if (count($array) % 2==0)
    {
        //Par
        $mitad = floor(count($array) / 2);
        return ($array[$mitad]+$array[$mitad+1])/2;
    }
    else
    {
        //Impar
        $mitad = count($array) / 2;
        return $array[$mitad];
    }
}

function generarAcronimo($frase)
{
    $acronimo = "";
   
    //Hacer explode 
    $lista = explode(" ",$frase);

    //Recorrer array
    foreach ($lista as $item)
    {
        //Sacar la primera letra de cada palabra
        $acronimo .=substr($item,0,1);
    }

    //pasarlo a mayúscula
    $acronimo = strtoupper($acronimo);

    return $acronimo;
}

function generarSlug($frase, $id)
{
    $slug="";

    //Convertir todo a minúsculas
    $slug = strtolower($frase);

    //Reemplazar espacios por guiones
    $slug = str_replace(" ", "-", $slug);

    //Reemplazar caracteres que no queremos perder en la expresión regular
    //á, é, í, ó, ú, ñ
    //TO_DO

    //Quitar caracteres que no sean letras, numeros o guiones
    $slug = preg_replace("/[^a-z0-9\-]/i", "", $slug);

    //eliminar stopwords
    //TO_DO

    //añade id
    $slug .= "-" . $id;

    return $slug;
}


?>