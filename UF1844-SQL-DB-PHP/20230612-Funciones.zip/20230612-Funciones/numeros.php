<?php
    require('functions/functions.php'); 

    //Captura del tipo de iva y del importe
    $tipoDeIva=0;
    $importe=0;
    $output="";
    if (isset($_POST["cmbTipoIVA"]))
    {
        //Venimos de submit

        //Recuperar valores
        $tipoDeIva = $_POST["cmbTipoIVA"];
        $importe = $_POST["txtImporte"];

        //Calculamos y formateamos
        $total = calcularIVA($tipoDeIva, $importe);
        $output = formatoMoneda($total);
    }

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Calculadora IVA</h1>
                
                <form method="post" action="" id="frmCalculadora">

                    <div class="mb-3 row">
                    <label for="cmbTipoIVA" class="form-label col-sm-3">Tipo de IVA</label>
                    <div class="col-sm-9">
                        <select class="form-control" id="cmbTipoIVA" name="cmbTipoIVA">
                            <option value="0">Seleccionar</option>
                            <option value="10">10 %</option>
                            <option value="21">21 %</option>
                            <option value="24">24 %</option>
                        </select>
                        <script>
                            document.getElementById("cmbTipoIVA").value='<?= $tipoDeIva ?>';
                        </script>
                    </div>
                    </div>
                    <div class="mb-3 row">
                    <label for="txtImporte" class="form-label col-sm-3">Importe</label>
                    <div class="col-sm-9">
                        <input type="text" id="txtImporte" name="txtImporte" class="form-control" value="<?= $importe ?>" />
                    </div>
                    </div>
                    <div class="mb-3 row">
                    <div class="offset-md-3 col-sm-9">
                        <button type="button" class="btn btn-primary" id="btnCalcular">Calcular</button>
                    </div>
                    </div>
                </form>
                <div id="divResultado">
                    <?= $output ?>
                </div>
            </div>
            <div class="col-md-6">
                <h1>Cálculos estadísticos</h1>
                
                <div class="mb-3 row">
                    <label for="txtNumeros" class="form-label col-sm-3">Números</label>
                    <div class="col-sm-9">
                        <input type="text" id="txtNumeros" class="form-control" />
                    </div>
                </div>
                <div class="mb-3 row">
                    <div class="offset-md-3 col-sm-9">
                        <button type="button" class="btn btn-primary" id="btnEstadisticas">Calcular estadísticas</button>
                    </div>
                </div>
                <div id="divResultadoEstadisticas">
                </div>
            </diV>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
