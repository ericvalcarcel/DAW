<?php
$entrada = $_POST["texto"];
$lista = explode(",",$entrada);

$html ="";
foreach ($lista as $item)
{
    $html .="Item: $item<br/>";
}

echo $html;
?>