<?php
require('../functions/functions.php'); 

$numeros = $_POST["numeros"];
$lista = explode(",",$numeros);

$html ="";
$html .="Máximo: " . calcularMaximo($lista) . "<br/>";
$html .="Mínimo: " . calcularMinimo($lista) . "<br/>";
$html .="Media: " . calcularMedia($lista) . "<br/>";
$html .="Mediana: " . calcularMediana($lista) . "<br/>";

echo $html;
?>