$(function()
{
    $("#btnEnviar").click(function()
    {
        let texto = $("#txtEntradaAjax").val();
        if (texto!="")
        {
            $.ajax({
                async: true,
                type: "POST",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "ajax/entrada.php",
                data: "texto=" + texto,
                success: function(data)
                {
                    $("#divResultado").html(data);
                },
                timeout: 5000,
                error: function(error){
                    console.log("Error en el servidor." + error);
                }
              });
        }
        else
        {
            alert("Introduce algo en la caja.");
        }

    });

    $("#btnCalcular").click(function()
    {
        let tipoIva = $("#cmbTipoIVA").val();
        if (tipoIva=="0")
        {
            alert("Falta tipo de iva");
            return;
        }

        let txtImporte = $("#txtImporte").val();
        if (txtImporte=="")
        {
            alert("Falta importe");
            return;
        }

        //Validación correcta
        $("#frmCalculadora").submit();

    });

    $("#btnEstadisticas").click(function()
    {
        let numeros = $("#txtNumeros").val();
        if (numeros!="")
        {
            $.ajax({
                async: true,
                type: "POST",
                dataType: "html",
                contentType: "application/x-www-form-urlencoded",
                url: "ajax/estadisticas.php",
                data: "numeros=" + numeros,
                success: function(data)
                {
                    $("#divResultadoEstadisticas").html(data);
                    $("#txtNumeros").val("");
                },
                timeout: 5000,
                error: function(error){
                    console.log("Error en el servidor." + error);
                }
              });
        }
        else
        {
            alert("Introduce algo en la caja.");
        }

    });

    $("#btnGenerar").click(function()
    {
        let txtFrase = $("#txtFrase").val();
        if (txtFrase=="")
        {
            alert("Falta la frase");
            return;
        }

        //Validación correcta
        $("#frmAcronimos").submit();

    });
});
