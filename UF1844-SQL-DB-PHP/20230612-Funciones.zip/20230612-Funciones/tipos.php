<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Manipular las constantes, las variables y los tipos de datos</h1>
                
                <?php
                    const PI =3.1416;

                    $v = constant("PI");
                    $valor = empty($v);

                    if ($valor)
                    {
                        echo "<p>Variable vacía</p>";
                    }
                    else
                    {
                        echo "<p>Variable no vacía</p>";
                    }

                    var_dump($v);
                    echo "<br/>";
                    var_dump($valor);

                    echo "<hr/>";

                    $valor1 = isset($prueba);
                    var_dump($valor1);
                    echo "<br/>";
                    $prueba = "Valor de prueba";
                    $valor1 = isset($prueba);
                    var_dump($valor1);
                    echo "<br/>";
                    $valor1 = empty($prueba);
                    var_dump($valor1);
                    echo "<br/>";
                    var_dump($prueba);
                    echo "<br/>";



                ?>

            </div>
            <div class="col-md-6">

            </diV>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
