<?php
    require('functions/functions.php'); 

    //Captura la frase
    $frase="";
    $output="";
    if (isset($_POST["txtFrase"]))
    {
        //Venimos de submit

        //Recuperar valores
        $frase = $_POST["txtFrase"];

        //Calculamos
        $output = generarAcronimo($frase);
    }

    //Slug
    $fraseNoticia = "Pacto entre ERC y PSC para las diputación de Tarragona y Lleida";
    $idNoticia = 123456;
    $slug = generarSlug($fraseNoticia, $idNoticia);



    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Generador de acrónimos</h1>
                    
                <form method="post" action="" id="frmAcronimos">

                    <div class="mb-3 row">
                        <label for="txtFrase" class="form-label col-sm-3">Frase</label>
                        <div class="col-sm-9">
                            <input type="text" id="txtFrase" name="txtFrase" class="form-control" />
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <div class="offset-md-3 col-sm-9">
                            <button type="button" class="btn btn-primary" id="btnGenerar">Generar acrónimo</button>
                        </div>
                    </div>
                </form>
                <div id="divResultado">
                    <?= $output ?>
                </div>

            </div>
            <div class="col-md-6">
                <?=$slug ?>
            </diV>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
