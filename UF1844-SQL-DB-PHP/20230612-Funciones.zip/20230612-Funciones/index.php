<?php
    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <h1>Funciones de PHP</h1>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Odio consectetur adipisci fuga nesciunt suscipit ex doloribus odit, cum, dolore aut quasi earum numquam vitae dignissimos eligendi sit autem atque culpa?</p>
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
