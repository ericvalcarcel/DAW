<?php

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Manipular matrices</h1>
            
                <?php
                    if (isset($_POST["txtEntrada"]))
                    {
                        //Venimos de submit
                        $entrada = $_POST["txtEntrada"];
                        $lista = explode(",",$entrada);

                        foreach ($lista as $item)
                        {
                            echo "Item: $item<br/>";
                        }
                    }
                    else
                    {
                        //Venimos de inicio
                ?>
                    <form method="POST" action="">
                        Entrada:
                        <input type="text" id="txtEntrada" name="txtEntrada" class="form-control" />
                        <button type="submit" class="btn btn-primary">Enviar</button> 
                    </form>
                
                <?php
                    }
                ?>    
            </div>
            <div class="col-md-6" id="divResultado">
                Entrada:
                <input type="text" id="txtEntradaAjax" class="form-control" />
                <button type="button" class="btn btn-primary" id="btnEnviar">Enviar</button> 
            </diV>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
