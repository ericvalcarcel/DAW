<!doctype html>
<html lang="es">
    <head>
        <title></title>
        <meta description="" />
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">        
        
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    
        <link rel="stylesheet" href="styles/styles.css" />
        
    </head>
    <body>
        <header>
            
        </header>
        <nav>

        </nav>
        <main>
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h1>Datos de países</h1>
                        <select id="cmbPais" class="form-control">
                            <option value="0">Seleccionar</option>
                            <option value="Italia">Italia</option>
                            <option value="Francia">Francia</option>
                            <option value="Alemania">Alemania</option>
                            <option value="Holanda">Holanda</option>
                        </select>
                    </div>
                    <div class="col" id="divResultado">

                    </div>
                </div>
            </div>
        </main>
        <aside>

        </aside>
        <footer>

        </footer>

        <!-- Si utilizamos componentes de Bootstrap que requieran Javascript agregar el siguiente archivo -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

		<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

        <script src="scripts/scripts.js"></script>
    </body>
</html>