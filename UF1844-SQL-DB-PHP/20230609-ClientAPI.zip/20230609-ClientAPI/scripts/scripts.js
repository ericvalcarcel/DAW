$(function()
{
    $("#cmbPais").change(function()
    {
        var pais = $(this).val();
        if (pais!="0")
        {
            var url="http://192.168.1.105/UF1844/APIPaises/GetData.php?pais=[pais]";
            url = url.replace("[pais]",pais);

            $.ajax({
                async: true,
                type: "GET",
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                url: url,
                success: function(data)
                {
                    //Update UI
                    console.log(data);
                    if (data.error=="Sin datos")
                    {
                        $("#divResultado").html("Sin datos");
                    }
                    else
                    {
                        $("#divResultado").html("País: "+ data.generales.pais + "<br />" +
                        "Capital: "+ data.generales.capital + "<br />" + 
                        "País: "+ data.generales.pais + "<br />"+ 
                        "Superficie: "+ data.adicionales.superficie + "<br />"+ 
                        "Renta: "+ data.adicionales.renta+ "<br />");
                    }
                },
                timeout: 5000,
                error: function(error)
                {
                    console.log("Error en el servidor." + error);
                }
            });


        }
        else
        {
            $("#divResultado").html("Por favor ,seleccione un país.");
        }
    });

});