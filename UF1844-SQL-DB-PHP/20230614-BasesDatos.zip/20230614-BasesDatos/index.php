<?php
    //Biblioteca de funciones para acceder a BDs
    require('functions/functionsBD.php'); 

    //Head de la página
    require('controls/head.php'); 

    //Header
    require('controls/header.php'); 

    //Nav
    require('controls/nav.php'); 
?>

<main>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php
                    //Crear la conexión con parámetros por defecto
                    //$conexion = conectar();

                    //Crear la conexión al MySQL de localhost
                    $conexion = conectar("localhost","root","");

                    //Conectar a la BD que queramos
                    $ok = mysqli_select_db($conexion, "neptuno");
                    if(!$ok)
                    {
                        echo "No se ha podido conectar a esta base de datos<br/>";
                        exit("Base de datos inexistente");
                    }

                    //Preparar la SQL
                    $sql = "SELECT NombreProducto, PrecioUnidad,
                                    UnidadesEnExistencia
                            FROM producto 
                            WHERE idCategoria = 1
                            ORDER BY NombreProducto";
                    
                    //Lanzar la consulta
                    $resultSet = mysqli_query($conexion, $sql);
                    if (!$resultSet)
                    {
                        echo "No se ha podido lanzar la SQL<br/>";
                        exit("No SQL ejecutada");
                    }

                    //Número de registros de la consulta
                    echo "Registros: " . mysqli_num_rows($resultSet) . "<br/>";

                    //Fetch de las filas del resultSet
                    while (true)
                    {
                        $linea = mysqli_fetch_object($resultSet);

                        if ($linea == null){ break; };
                        
                        echo $linea->NombreProducto . "\t" .
                            $linea->PrecioUnidad . "\t" .
                            $linea->UnidadesEnExistencia . "<br/>";
                    }

                    //Cerrar la conexión
                    desconectar($conexion);

                ?>
            </div>
            <div class="col">
                <?php
                    //Crear la conexión con parámetros por defecto
                    //$conexion = conectar();

                    //Crear la conexión al MySQL de localhost
                    $conexion = conectar("localhost","root","");

                    //Conectar a la BD que queramos
                    $ok = mysqli_select_db($conexion, "neptuno");
                    if(!$ok)
                    {
                        echo "No se ha podido conectar a esta base de datos<br/>";
                        exit("Base de datos inexistente");
                    }

                    //Preparar la SQL
                    $sql = "SELECT NombreProducto, PrecioUnidad,
                                    UnidadesEnExistencia, Suspendido
                            FROM producto 
                            WHERE idCategoria IN (1,2)
                            ORDER BY NombreProducto";
                    
                    //Lanzar la consulta
                    $resultSet = mysqli_query($conexion, $sql);

                    //Fetch de las filas del resultSet
                    $counter=0;
                    while (true)
                    {
                        $linea = mysqli_fetch_object($resultSet);

                        if ($linea == null) { break; };

                        $counter++;

                        //Cabecera de la tabla
                        if ($counter==1)
                        {
                            //Cabecera de la tabla
                            echo "<table class='table'>
                            <tr><th>Producto</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Estado</th></tr>";
                        }

                        //Las diferentes filas de la tabla
                        echo "<tr><td>" . $linea->NombreProducto . "</td>" .
                            "<td>" . $linea->PrecioUnidad . "</td>" .
                            "<td>" . $linea->UnidadesEnExistencia . "</td>" .
                            "<td>" . (($linea->Suspendido == 0) ? "Activo" : "Descatalogado") . "</td></tr>";

                        //Footer de la tabla
                        if ($counter == mysqli_num_rows($resultSet))
                        {
                            echo "</table>";
                        }
                    }
                    
                    //Número de registros de la consulta
                    echo "Registros: " . mysqli_num_rows($resultSet) . "<br/>";

                    //Cerrar la conexión
                    desconectar($conexion);

                ?>

            </div>
        </div>
        <div class="row">
            <div class="col">
            <?php
                    //Crear la conexión con parámetros por defecto
                    //$conexion = conectar();

                    //Crear la conexión al MySQL de localhost
                    $conexion = conectar("localhost","root","");

                    //Conectar a la BD que queramos
                    $ok = mysqli_select_db($conexion, "neptuno");
                    if(!$ok)
                    {
                        echo "No se ha podido conectar a esta base de datos<br/>";
                        exit("Base de datos inexistente");
                    }

                    //Preparar la SQL
                    $sql = "SELECT NombreProducto, PrecioUnidad,
                                    UnidadesEnExistencia, Suspendido
                            FROM producto 
                            WHERE idCategoria IN (1,2)
                            ORDER BY NombreProducto";
                    
                    //Lanzar la consulta
                    $resultSet = mysqli_query($conexion, $sql);

                    //Fetch de las filas del resultSet
                    $counter=0;
                    while (true)
                    {
                        $linea = mysqli_fetch_row($resultSet);

                        if ($linea == null) { break; };

                        $counter++;

                        //Cabecera de la tabla
                        if ($counter==1)
                        {
                            //Cabecera de la tabla
                            echo "<table class='table'>
                            <tr><th>Producto</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Estado</th></tr>";
                        }

                        //Las diferentes filas de la tabla
                        

                        echo "<tr>";
                        for ($i=0;$i<count($linea);$i++)
                        {
                            echo "<td>" . $linea[$i] . "</td>";
                        }                        
                        echo "</tr>";

                        //Footer de la tabla
                        if ($counter == mysqli_num_rows($resultSet))
                        {
                            echo "</table>";
                        }
                    }
                    
                    //Número de registros de la consulta
                    echo "Registros: " . mysqli_num_rows($resultSet) . "<br/>";

                    //Cerrar la conexión
                    desconectar($conexion);

                ?>                
            </div>
        </div>
    </div>
</main>

<?php
    //Nav
    include('controls/aside.php'); 

    //Footer
    require('controls/footer.php'); 

    //Links
    require('controls/links.php'); 
?>
