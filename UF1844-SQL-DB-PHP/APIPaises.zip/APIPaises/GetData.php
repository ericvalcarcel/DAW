<?php
    //Recuperar datos de entrada
    $pais = $_GET["pais"];

    //Algoritmo de lógica de negocio
    //Italia, Francia, Alemania
    sleep(1);
    
    switch ($pais)
    {
        case "Italia":
            $datos = ["generales" => ["pais"=>"Italia","capital"=>"Roma","habitantes"=>59.11],
            "adicionales" => ["superficie"=>302.73, "renta"=>35657] ];
            break;

        case "Francia":
            $datos = ["generales" => ["pais"=>"Francia","capital"=>"París","habitantes"=>82.50],
            "adicionales" => ["superficie"=>421.00, "renta"=>38243] ];
            break;

        case "Alemania":
            $datos = ["generales" => ["pais"=>"Alemania","capital"=>"Berlin","habitantes"=>87.10],
            "adicionales" => ["superficie"=>512.00, "renta"=>41243] ];
            break;
        
        default:
            $datos = ["error" => "Sin datos"];
            break;
    }

    //Preparar la salida JSON
    $salidaJson = json_encode($datos);
    echo $salidaJson;

?>