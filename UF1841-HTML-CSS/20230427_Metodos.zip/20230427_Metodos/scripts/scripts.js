function imprimirFicha()
{
    var titulo="Coca cola 2L";
    var descripcion = "Botella de 2 L de Coca Cola."
    var precio = 3.25;
    var estado = true;

    imprimirProducto(titulo,descripcion,precio,estado);

    //...

    imprimirProducto("Pan bimbo","Pan muy bueno",1.75,false);

}

function imprimirProducto(titulo,descripcion,precio,estado)
{
    //Componer la ficha
    var ficha ="<div class='ficha'>" 
    ficha +="<h3>"+titulo+"</h3>";
    ficha += "<p>"+descripcion+"</p>";
    ficha += "<p style='color:red; font-size:1.25rem;'>"+precio+" €</p>";
    ficha += "<p>"+ ((estado) ? "Disponible" : "No disponible")  + "</p>";
    ficha += "</div>";

    //Crear el objeto de la capa donde mostraremos la ficha
    var divResultado = document.getElementById("divResultado");

    //Mostrar la ficha
    divResultado.innerHTML += ficha;
    

}

function formatearFecha()
{
    var fecha = "10/12/2023";

    //tipo=1 => 10 de enero de 2023
    //tipo=2 => october 10th, 2023
    //tipo=3 => 20231010
    var fechaFormateada = formatFecha(fecha,1);

    //Crear el objeto de la capa donde mostraremos la ficha
    var divResultado = document.getElementById("divResultado");

    //Mostrar la ficha
    divResultado.innerHTML += fechaFormateada;

}

function formatFecha(fecha,tipo)
{
    var resultado = "";
    
    //Algoritmo
    switch (tipo)
    {
        case 1:
            var partes = fecha.split("/");
            var mes = obtenerMes(partes[1]);    //Traducción de número a texto
            resultado = partes[0] + " de " + mes + " de " + partes[2];
            break;

        case 2:
            //TO_DO
            break;

        case 3:
            //TO_DO
            break;

    }

    return resultado;
}

function obtenerMes(numMes)
{
    var resultado ="";

    //Unificación del formato del mes
    var mes = parseInt(numMes);

    //Algoritmo
    switch (mes)
    {
        case 1:
            resultado ="enero";
            break;
        case 2:
            resultado ="febrero";
            break;
        case 3:
            resultado ="marzo";
            break;
        case 4:
            resultado ="abril";
            break;
        case 5:
            resultado ="mayo";
            break;
        case 6:
            resultado ="junio";
            break;
        case 7:
            resultado ="julio";
            break;
        case 8:
            resultado ="agosto";
            break;
        case 9:
            resultado ="septiembre";
            break;
        case 10:
            resultado ="octubre";
            break;
        case 11:
            resultado ="noviembre";
            break;
        case 12:
            resultado ="diciembre";
            break;
        
        default:
            resultado ="xxxx";
            break;

    }

    return resultado;
}

function obtenerCadenaReversa()
{
    var cadena = "El mundo de javascript";

    var cadenaRevertida = revertir(cadena);

    //Crear el objeto de la capa donde mostraremos la ficha
    var divResultado = document.getElementById("divResultado");

    //Mostrar la ficha
    divResultado.innerHTML += cadena + "<br/>" + cadenaRevertida;
}

function revertir(texto)
{
    var resultado = "";

    //Algoritmo
    for ( var i = texto.length - 1; i >= 0 ; i--)
    {
        resultado += texto[i];
    }

    return resultado;
}

function adivinarCadena()
{
    var cadena = "Javascript y los bucles son fantasticos";

    var html = enmarcar(cadena);

    //Crear el objeto de la capa donde mostraremos la ficha
    var divResultado = document.getElementById("divResultado");

    //Mostrar la ficha
    divResultado.innerHTML += html;

    //Parte avanzada
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="mensaje"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })

}

function enmarcar(texto)
{
    var resultado = "";

    //UNificación a mayúsculas
    texto = texto.toUpperCase();

    //Algoritmo
    for ( var i = 0; i<texto.length; i++)
    {
        if (texto[i]=="A" || texto[i]=="E" || texto[i]=="I" || texto[i]=="O" || texto[i]=="U")
        {
            resultado += "<div class='letra' data-bs-toggle='mensaje' title='"+texto[i]+"'>_</div>";
        }
        else if (texto[i]==" ")
        {
            resultado += "<div class='letra'><span style='opacity:0;'>M</span></div>";
        }
        else
        {
            resultado += "<div class='letra'>" + texto[i] +"</div>";
        }
    }

    return resultado;
}
