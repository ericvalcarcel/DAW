function hacerAlgo()
{
 
    //Modificar el contenido del h1 del article
    //Poner el texto "Hacer alguna cosa"
    document.getElementById("titular").innerHTML="Hacer alguna cosa";

    alert("Hacer alguna cosa");

}